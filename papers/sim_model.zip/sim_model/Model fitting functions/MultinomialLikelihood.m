% returns LOG likelihood estimate from a multinomial distribution by comparing the
% number of responses in each category (Vector N) 
% to the probability predictions of a model (Vector p). Call once at each data
% point that needs evaluating, then sum (for total log likelihood)
% NOTE: This returns LOG likelihood, and is just the kernel of the whole
% multinomial distribution function (so suitable for evaluating ML fit but not a true estimate of
% likelihood as constant terms are ommitted).

function loglikelihood = MultinomialLikelihood(N, p)

loglikelihood = sum(N.*log(p));