function [FinalParams, LogLikelihood, Deviance, ThisData, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameter] = TwoAFCSimultaneity_2PEq_Multistart_rawdata(StartParams,StepParams, EndParams, Data,varargin)
% Launching function to make TwoAFCSimultaneity_2PEq_WapperForFmin
% start Simplex searches for a best fit from multiple points.
%
% Basically, this function fits an appropriate model to data from an experiment
% that demands a 2IFC between two pairs of events (e.g. two sets of a flash and a beep). 
% The model assumes that individual signals are prone to Gaussian latency noise,
% affecting when they arrive at a decision center. The observer is assumed
% to based their discrimination on which pair arrives with the smallest
% absolute aysnchrony. Note that stim levels are defined in ms.
%
% Model predictions follow the CDF of a doubly non-central F distribution (thanks to
% Josh Solomon for pointing this out). However, that is the slowest
% function in the whole wide world to evaluate, so the functions called
% here use a saddle-point approximation to this CDF based on:
% 
% Statistics and Computing (2002). Calculating the density and distribution 
% function for the singly and doubly noncentral F. Volume 12, Issue 1, pp 9-16.  
% Ronald W. Butler, Marc S. Paolella
%
% (see also Intermediate Probability: A Computational Approach by Marc,
% published by Wiley in 2007, where he expands on some of this stuff and
% provides some code snippets in chapter 10. Thanks to Marc for sending me the functions
% I use!)
%
% To get it going, you need a command like this: 
%
% [FinalParams, LogLikelihood] = TwoAFCSimultaneity_2PEq_Multistart_rawdata([-200 10],[200 150], [200 310], Data)
%
% The model has two parameters (PSE, average latency SD of signals).
%
% NOTE: The SD parameter returned here is not directly comparable to the SD
% parameter returned when fitting a cumulative Gaussian to a set of TOJ
% data. To make this comparison, the SD returned here should be multiplied
% by 2^0.5.
%
% When searching for best fitting parameters, it's possible to get trapped 
% at a "local maximum" best fit which is not always the global maximum. 
% Hence the function will initiate a Nelder-Mead search to find the best-fitting 
% model from multiple starting points. The first three arguments that are
% passed to the function specify the starting points to iterate through, in
% the format start:step:end for each of two parameters (e.g. for parameter 1
% the example above will test starting positions of -200, 0 and 200, because
% it starts at -200, moves up in steps of 200, and ends at 200). Hence this
% example actually sets in motion 3 x 3 = 9 fits. Finally, you get the best fit
% plotted from any of the starting positions. If you find with your data that
% you are not getting good fits, you may need to adjust these values to make
% sure one of the iterations starts reasonably close to where you believe the
% best fit actually lies.
%
% The fourth argument is the data you are fitting. This needs to be a matrix
% Containing your RAW TRIAL BY TRIAL DATA. This will get chopped up inside
% this function to create sets of data to fit, one for each standard within 
% your experiment (so only one if you just test simultaneous against
% various other values, but several if you have e.g. -20 vs +60 etc.) Each
% subset will then have three columns and as many rows as you have test values. The first column
% is the test value, the second column is the proportion of times they said it was
% more asynchronous than the standard, the third column is the number of trials presented
% at that test value. For example, your experiment might have trial by trial data
% looking like this:
%
% 1     0       50      2
% 2     -50     0       1
% 3     100     0       1
%
% etc. (where the columns are trial number, SOA in interval 1, SOA in
% interval 2, and decision about which is MOST SYNCHRONOUS). Note that you
% need the last three of these four columns, and you need to code them this way,
% but you don't need them in this order (see later). If your data includes
% trials that were bad or cancelled, you should place a zero in the
% decision column (or just remove these trials yourself).
%
% This function will then create at least one (perhaps more) subsets of
% data, one per standard you included. For the data above (which only seems
% to include a single standard: zero) it would create something like the
% following (assuming there were actually 10 tests presented at each of 9
% test values in a set of 90 trials): 
%
% -200  1       10
% -150  0.8     10
% -100  0.7     10
% -50   0.7     10
% 0     0.5     10
% 50    0.6     10
% 100   0.8     10
% 150   0.9     10
% 200   1       10
%
% Basically, it's been coverted to show the proportion of times each test
% was judged more asynchronous than the standard (which is equivalent to
% proportion correct for a zero standard, but not for other standards).
%
% To make this conversion work, this function assumes that your data has
% stimuli in paticular step sizes (e.g. 50 ms in the example above). It
% also needs to know what columns in your raw data refer to interval 1 SOA,
% interval 2 SOA and decision (1 or 2 is more synchronous). The defaults
% are based on my data at the time I wrote this, are are:
%
% interval 1 column = 3
% interval 2 column = 4
% decision column = 5
% SOA step size = 20 ms
% Consider standards up to +/- 200 ms
%
% (That last sentence implies that the function will create up to 21
% subsets, with standard from -100 to +100 ms in steps of 20 ms, but won't
% consider data beyond that, e.g. if it found a trial with SOAs of -160 ms
% and +200 ms, this wouldn't get included in the fit).
%
% All of those things are adjustable via optional arguments. use [] if you
% want to change some but not all of them.
%
% Optional argument #1 is a vector containing the columns where the
% important stuff (interval 1 SOA, interval 2 SOA, decision) can be found
% in your raw data. Default is [3 4 5].
%
% Optional argument #2 is the step size, and optional argument #3 is the
% max absolute value of standards to consider. Note that if the combination
% of step size and max standard value means that there are more than 25
% standards, the function will break, so if it looks that way for you,
% you'll just have to round your data. Take a similar approach if you have
% very high resolution data rather than discrete steps.
%
% The function can also accept additional input arguments and return more
% stuff, e.g.:
%
% [FinalParams, LogLikelihood, Deviance, ThisData, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameter] = TwoAFCSimultaneity_2PEq_Multistart_rawdata([-75 25],[75 50], [75 125], Data, [], [], [], 2, 1999, 1)
%
% Set these optional arguments to zero or use [] to keep default behaviour.
%
% The Hessian matrix, if requested, tells you interesting things about the curvature of
% the likelihood surface at the point of best fit, and allows an estimate
% of variances/covariances of the parameters.
%
% Set optional argument #4 to either a step size (such as 0.001) or
% 1 for Hessian based confidence intervals or 2
% for Bca bootstrap intervals (which will take ages of course, but are
% likely to have better coverage). For the hessian option, using 1 will call code
% which attempts to figure out the right step size to use when applying
% numerical differentiation on the likelihood surface. Alternatively, use some
% simpler code, which requires that you specify the step size
% (but I've found that a bit ropey here: Maybe try 0.1).
%
% Optional argument #5 lets you override the default (1999) number of bootstraps 
% if you've requested bootstrap confidence intervals.
%
% Optional argument #6 can be set to 1 if you would also like to fit a
% guessing model (in this case the proportion of times O guesses interval 2, which has one
% parameter). However, the models are not nested, so it's a bit tricky to
% see if the improvement in fit is significant (in which case your
% participant probably wasn't just guessing). You could base it on AIC or
% BIC, which are both closely related to -2 * log likelihood.

    Step = 20;
    MaxStims = 200;
    Columns = [3 4 5];

    if nargin >= 6 && ~isempty(varargin{1})%optional arg 1 passed
        Columns = varargin{1};
    end
    
    if nargin >= 6 && ~isempty(varargin{2})%optional arg 1 passed
        Step = varargin{2};
    end

    if nargin >= 7 && ~isempty(varargin{3})%op arg 2 passed
        MaxStims = varargin{3};
    end
    
    if nargin >= 8 && ~isempty(varargin{4})
        ConfidenceIntervals = varargin{4};
        Bootstraps = 1999;
        LowCI = 0.025;
        HighCI = 0.975;
    else
        ConfidenceIntervals = 0;
    end 
        
    if nargin >= 9 && ~isempty(varargin{5})
        
        Bootstraps = varargin{5};
            
    end 
    
    if nargin >= 10 && ~isempty(varargin{6})
        
        TestGuessingModel = varargin{6};
        Power = 10000;
        
    else
        TestGuessingModel = 0;
        
    end 
        
    GuessLogLikelihood = [];
    GuessParameter = [];
    FinalParams = [0 0];
    CIFinalParams = [0 0; 0 0]; 
    LogLikelihood = -1.*realmax;
    Deviance = realmax;
    
     RemainingData = Data;
     counter = 0;
     Standard = zeros(26,1);
       
       for j = 0:Step:MaxStims 
           for k = 1:-2:-1
               counter = counter + 1;
               Standard(counter) = j * k; %note that second time through will be same as first, generating empty data
               subset = ((RemainingData(:,Columns(1)) == Standard(counter) | RemainingData(:,Columns(2)) == Standard(counter)) ...
                   & RemainingData(:,Columns(1)) ~= RemainingData(:,Columns(2)) & RemainingData(:,Columns(3)) > 0);
               exclude = ~subset;
               subset = RemainingData(subset,:);
               RemainingData = RemainingData(exclude,:);
               
               if ~isempty(subset)
               
                   subsubsetcounter = 0;

                   for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                       if l ~= Standard(counter)
                            subsubset = (subset(:,Columns(1)) == l | subset(:,Columns(2)) == l);
                            subsubset = subset(subsubset,:);
                            if ~isempty(subsubset)
                                subsubsetcounter = subsubsetcounter + 1;
                                NotSimultaneous = (subsubset(:,Columns(2))==l)+1; %1 or two for interval that is not sim
                                ThisData.(char(counter+64))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))~=NotSimultaneous)./size(subsubset,1)) size(subsubset,1)];
                                if TestGuessingModel
                                   ThisDataG.(char(counter+64))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))~=NotSimultaneous)./size(subsubset,1)) size(subsubset,1) sum(2-NotSimultaneous)./size(subsubset,1)]; 
                                end
                            end
                       end
                   end
               else
                   ThisData.(char(counter+64)) = [];
                   if TestGuessingModel
                       ThisDataG.(char(counter+64)) = [];
                   end
               end
           end
       end
       
       if counter < 26
           for i = counter:26
               ThisData.(char(i+64)) = [];
               if TestGuessingModel
                   ThisDataG.(char(i+64)) = [];
               end
           end
       end
       
       
       ThisData.Leftovers = RemainingData;
       ThisData.ButtonBias = mean(RemainingData(((RemainingData(:,Columns(1)) == RemainingData(:,Columns(2)))& RemainingData(:,Columns(3)) > 0),Columns(3)))-1;
       ThisData.ButtonBiasN = sum((RemainingData(:,Columns(1)) == RemainingData(:,Columns(2)))& RemainingData(:,Columns(3)) > 0);
 
    if TestGuessingModel
        fprintf('One parameter Guess model tested first\r')
        [GuessParameter, GuessLogLikelihood, ~] = TwoAFCSimultaneity_1P_WrapperForFmin(0.5,ThisDataG.A,Power,Standard(3),ThisDataG.C...
           ,Standard(4),ThisDataG.D,Standard(5),ThisDataG.E,Standard(6),ThisDataG.F...
           ,Standard(7),ThisDataG.G,Standard(8),ThisDataG.H,Standard(9),ThisDataG.I...
           ,Standard(10),ThisDataG.J,Standard(11),ThisDataG.K,Standard(12),ThisDataG.L...
           ,Standard(13),ThisDataG.M,Standard(14),ThisDataG.N,Standard(15),ThisDataG.O...
           ,Standard(16),ThisDataG.P,Standard(17),ThisDataG.Q,Standard(18),ThisDataG.R...
           ,Standard(19),ThisDataG.S,Standard(20),ThisDataG.T,Standard(21),ThisDataG.U...
           ,Standard(22),ThisDataG.V,Standard(23),ThisDataG.W,Standard(24),ThisDataG.X...
           ,Standard(25),ThisDataG.Y,Standard(26),ThisDataG.Z);
       
        figure
        hold on
        whiteout = MaxStims + 20;
        bigwidth = 5;
        PointSize = 1;

        for i = 1:26

            if i ~= 2 && ~isempty(ThisDataG.(char(i+64)))

                ThisTarget = repmat(Standard(i),size(ThisDataG.(char(i+64)),1),1);  
                for j = 1:size(ThisDataG.(char(i+64)),1)
                    plot3(ThisDataG.(char(i+64))(j,1),ThisDataG.(char(i+64))(j,2),ThisTarget,'o','color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],...
                        'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth,'MarkerSize',ThisDataG.(char(i+64))(j,3)*PointSize)
                end

                Curve = TwoAFCSimultaneity_1P(GuessParameter,ThisDataG.(char(i+64))); %data Curve 
                plot3(ThisDataG.(char(i+64))(:,1),Curve,ThisTarget,'color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth)
            end
        end

        title('Best fit')
        %legend('Data','Fit')
        xlabel('SOA (ms)')
        ylabel('Proportion judged less simultaneous than target pair')
        zlabel('Target pair')
        view(30,60)
        grid on


        hold off
        pause(1);
                  
    end 

    counteri = 0;
    for i = StartParams(1):StepParams(1):EndParams(1)
        counteri = counteri + 1;

       counterj = 0;
       for j = StartParams(2):StepParams(2):EndParams(2)
           counterj = counterj + 1;

           
           Parameters = [i j];

           tic
           
           [TempParams This_MLE TempD, TempHess, TempCovar] = TwoAFCSimultaneity_2PEq_WrapperForFmin(Parameters,ThisData.A,ConfidenceIntervals,Standard(3),ThisData.C...
           ,Standard(4),ThisData.D,Standard(5),ThisData.E,Standard(6),ThisData.F...
           ,Standard(7),ThisData.G,Standard(8),ThisData.H,Standard(9),ThisData.I...
           ,Standard(10),ThisData.J,Standard(11),ThisData.K,Standard(12),ThisData.L...
           ,Standard(13),ThisData.M,Standard(14),ThisData.N,Standard(15),ThisData.O...
           ,Standard(16),ThisData.P,Standard(17),ThisData.Q,Standard(18),ThisData.R...
           ,Standard(19),ThisData.S,Standard(20),ThisData.T,Standard(21),ThisData.U...
           ,Standard(22),ThisData.V,Standard(23),ThisData.W,Standard(24),ThisData.X...
           ,Standard(25),ThisData.Y,Standard(26),ThisData.Z);

           if counteri == 1 && counterj == 1
               TimePerFunctionCall = toc
           end

           %ZPlot(counteri,counterj) = This_MLE;

           if This_MLE > LogLikelihood
               LogLikelihood = This_MLE;
               Deviance = TempD;
               FinalParams = TempParams;
               Hess = TempHess; 
               Covar = TempCovar; 
           end
               
           
       end

    end
    
    %last check starting from current best fit
    
    [TempParams This_MLE TempD] = TwoAFCSimultaneity_2PEq_WrapperForFmin(FinalParams,ThisData.A,ConfidenceIntervals,Standard(3),ThisData.C...
           ,Standard(4),ThisData.D,Standard(5),ThisData.E,Standard(6),ThisData.F...
           ,Standard(7),ThisData.G,Standard(8),ThisData.H,Standard(9),ThisData.I...
           ,Standard(10),ThisData.J,Standard(11),ThisData.K,Standard(12),ThisData.L...
           ,Standard(13),ThisData.M,Standard(14),ThisData.N,Standard(15),ThisData.O...
           ,Standard(16),ThisData.P,Standard(17),ThisData.Q,Standard(18),ThisData.R...
           ,Standard(19),ThisData.S,Standard(20),ThisData.T,Standard(21),ThisData.U...
           ,Standard(22),ThisData.V,Standard(23),ThisData.W,Standard(24),ThisData.X...
           ,Standard(25),ThisData.Y,Standard(26),ThisData.Z);       

   if This_MLE > LogLikelihood
       LogLikelihood = This_MLE;
       Deviance = TempD;
       FinalParams = TempParams;
       Hess = TempHess; %UPDATED!
       Covar = TempCovar; %UPDATED!
   end
   
    %create lookup for normal cumulative distribution function
    x = [-5:0.001:5];
    NCD = 0.5 + (erf(x./(sqrt(2)))./2);  
                            
    
    if ConfidenceIntervals %use Hessian matrix estimates
        for i = 1:length(FinalParams)
            CIFinalParams(i,1) = FinalParams(i)-((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
            CIFinalParams(i,2) = FinalParams(i)+((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
        end
    end
    if ConfidenceIntervals == 2 %bootstrap
        
        AllTrials = Data(Data(:,Columns(3)) > 0,:); %Data minus cancelled trials
        BootstrapParams = zeros(Bootstraps,length(FinalParams));
    
        for i = 1:Bootstraps

           tic
           
           %sample with replacement
           Positions = randi(length(AllTrials),length(AllTrials),1);
           %Positions = ceil(rand(length(AllTrials),1).*length(AllTrials));
           ThisBootstrap = AllTrials(Positions,:);

           %Sort down to a Data set
           
           RData = ThisBootstrap;
            counter = 0;
            S = zeros(26,1);
       
           for j = 0:Step:MaxStims 
               for k = 1:-2:-1
                   counter = counter + 1;
                   S(counter) = j * k; %note that second time through will be same as first, generating empty data
                   subset = ((RData(:,Columns(1)) == S(counter) | RData(:,Columns(2)) == S(counter)) ...
                       & RData(:,Columns(1)) ~= RData(:,Columns(2)) & RData(:,Columns(3)) > 0);
                   exclude = ~subset;
                   subset = RData(subset,:);
                   RData = RData(exclude,:);

                   if ~isempty(subset)

                       subsubsetcounter = 0;

                       for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                           if l ~= S(counter)
                                subsubset = (subset(:,Columns(1)) == l | subset(:,Columns(2)) == l);
                                subsubset = subset(subsubset,:);
                                if ~isempty(subsubset)
                                    subsubsetcounter = subsubsetcounter + 1;
                                    NotSimultaneous = (subsubset(:,Columns(2))==l)+1; %1 or two for interval that is not sim
                                    TData.(char(counter+64))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))~=NotSimultaneous)./size(subsubset,1)) size(subsubset,1)];
                                    
                                end
                           end
                       end
                   else
                       TData.(char(counter+64)) = [];                       
                   end
               end
           end
           
           if counter < 26
               for c = counter:26
                   TData.(char(c+64)) = [];                   
               end
           end
       
           [BootstrapParams(i,:), ~, ~, ~, ~] = TwoAFCSimultaneity_2PEq_WrapperForFmin(FinalParams,TData.A,0,Standard(3),TData.C...
           ,Standard(4),TData.D,Standard(5),TData.E,Standard(6),TData.F...
           ,Standard(7),TData.G,Standard(8),TData.H,Standard(9),TData.I...
           ,Standard(10),TData.J,Standard(11),TData.K,Standard(12),TData.L...
           ,Standard(13),TData.M,Standard(14),TData.N,Standard(15),TData.O...
           ,Standard(16),TData.P,Standard(17),TData.Q,Standard(18),TData.R...
           ,Standard(19),TData.S,Standard(20),TData.T,Standard(21),TData.U...
           ,Standard(22),TData.V,Standard(23),TData.W,Standard(24),TData.X...
           ,Standard(25),TData.Y,Standard(26),TData.Z);
       
           clear TData

           if i == 1
               Bootstraps
               TimePerBootstrap = toc
           end

        end
        
        BootstrapMeanParams = mean(BootstrapParams);    
        
        %For BCa intervals, we need some extra stuff. 
        %First, a jackknife on the data
        
        JackknifeParams = zeros(length(AllTrials),length(FinalParams));
    
        for i = 1:length(AllTrials)

           tic
           
           %remove one trial
           include = [1:length(AllTrials)];
           include = include(include ~= i);
           ThisJackknife = AllTrials(include,:);
           
           RData = ThisJackknife;
            counter = 0;
            S = zeros(26,1);
       
           for j = 0:Step:MaxStims 
               for k = 1:-2:-1
                   counter = counter + 1;
                   S(counter) = j * k; %note that second time through will be same as first, generating empty data
                   subset = ((RData(:,Columns(1)) == S(counter) | RData(:,Columns(2)) == S(counter)) ...
                       & RData(:,Columns(1)) ~= RData(:,Columns(2)) & RData(:,Columns(3)) > 0);
                   exclude = ~subset;
                   subset = RData(subset,:);
                   RData = RData(exclude,:);

                   if ~isempty(subset)

                       subsubsetcounter = 0;

                       for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                           if l ~= S(counter)
                                subsubset = (subset(:,Columns(1)) == l | subset(:,Columns(2)) == l);
                                subsubset = subset(subsubset,:);
                                if ~isempty(subsubset)
                                    subsubsetcounter = subsubsetcounter + 1;
                                    NotSimultaneous = (subsubset(:,Columns(2))==l)+1; %1 or two for interval that is not sim
                                    TData.(char(counter+64))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))~=NotSimultaneous)./size(subsubset,1)) size(subsubset,1)];
                                    
                                end
                           end
                       end
                   else
                       TData.(char(counter+64)) = [];                       
                   end
               end
           end
           
           if counter < 26
               for c = counter:26
                   TData.(char(c+64)) = [];                   
               end
           end
       
           [JackknifeParams(i,:), ~, ~, ~, ~] = TwoAFCSimultaneity_2PEq_WrapperForFmin(FinalParams,TData.A,0,Standard(3),TData.C...
           ,Standard(4),TData.D,Standard(5),TData.E,Standard(6),TData.F...
           ,Standard(7),TData.G,Standard(8),TData.H,Standard(9),TData.I...
           ,Standard(10),TData.J,Standard(11),TData.K,Standard(12),TData.L...
           ,Standard(13),TData.M,Standard(14),TData.N,Standard(15),TData.O...
           ,Standard(16),TData.P,Standard(17),TData.Q,Standard(18),TData.R...
           ,Standard(19),TData.S,Standard(20),TData.T,Standard(21),TData.U...
           ,Standard(22),TData.V,Standard(23),TData.W,Standard(24),TData.X...
           ,Standard(25),TData.Y,Standard(26),TData.Z);
           
           clear TData

           if i == 1
               NumberJackknifes = length(AllTrials)
               TimePerJackknife = toc
           end

        end
        
        JackknifeMeanParams = repmat(mean(JackknifeParams),NumberJackknifes,1);
        %find means and scale up for vectorised operations
        
        %bits for acceleration formula
        topeq = sum((JackknifeMeanParams-JackknifeParams).^3);
        bottomeq = 6.*(sum((JackknifeMeanParams-JackknifeParams).^2)).^(3/2);
        
        %bits for bias formula
        scaleup = repmat(FinalParams,Bootstraps,1);
        biascount = (BootstrapParams < scaleup);
        bias = sum(biascount)./Bootstraps;
        
        %LowCI = 0.025;
        %HighCI = 0.975;
        
                
        for i = 1:length(FinalParams)

            ThisDist = sort(BootstrapParams(:,i));
            
            %Percentile
            %CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCI));
            %CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCI));
            
            %Reverse limits as suggested by Howell            
            %CIFinalParams(i,1) = FinalParams(i) - (ThisDist(round((Bootstraps+1).*HighCI))-FinalParams(i));
            %CIFinalParams(i,2) = FinalParams(i) + (FinalParams(i)-ThisDist(round((Bootstraps+1).*LowCI)));
            
            %BCa
            Acceleration = topeq(i)./bottomeq(i);
            Thisbias = x(find(NCD<=bias(i), 1, 'last' ));
            if isempty(Thisbias)
                Thisbias = x(1);
                fprintf('Warning: Possible bootstrap issue \n')
            end
            
            LowCut = Thisbias + ( (Thisbias + x(find(NCD<=LowCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=LowCI, 1, 'last'))))) );
            LowCut = NCD(find(x<=LowCut, 1, 'last' ));
            if isempty(LowCut)
                LowCut = 0;
            end
            HighCut = Thisbias + ( (Thisbias + x(find(NCD<=HighCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=HighCI, 1, 'last'))))) );
            HighCut = NCD(find(x<=HighCut, 1, 'last' ));
            if isempty(HighCut)
                HighCut = 0;
            end
            
            if round((Bootstraps+1).*LowCut) < 1 
                CIFinalParams(i,1) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*LowCut) >= length(ThisDist)
                CIFinalParams(i,1) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCut));
            end
            
            if round((Bootstraps+1).*HighCut) < 1
                CIFinalParams(i,2) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*HighCut) >= length(ThisDist)
                CIFinalParams(i,2) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCut));
            end
            
        end
    
    end
    %/UPDATED!
    
    close all
    %RePlot best fit against data
    %Plot best fit against data
    
    for i = 1:26
        
        if i ~= 2 && ~isempty(ThisData.(char(i+64)))
        
            figure
            hold on
            
            %implement Wilson Score confidence interval for proportion data
    
%            T1 = 1./(1 + ((1./ThisData.(char(i+64+LittleLetter))(:,3)).*(1.96^2)));
%            T2 = ThisData.(char(i+64+LittleLetter))(:,2)  + (1./(2.*ThisData.(char(i+64+LittleLetter))(:,3))).*(1.96.^2) +  (1.96.*((((1./ThisData.(char(i+64+LittleLetter))(:,3)).*ThisData.(char(i+64+LittleLetter))(:,2).*(1-ThisData.(char(i+64+LittleLetter))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char(i+64+LittleLetter))(:,3).^2))))).^0.5));
%            T3 = ThisData.(char(i+64+LittleLetter))(:,2)  + (1./(2.*ThisData.(char(i+64+LittleLetter))(:,3))).*(1.96.^2) -  (1.96.*((((1./ThisData.(char(i+64+LittleLetter))(:,3)).*ThisData.(char(i+64+LittleLetter))(:,2).*(1-ThisData.(char(i+64+LittleLetter))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char(i+64+LittleLetter))(:,3).^2))))).^0.5));
% 
%            Upper = T1.*T2;
%            Lower = T1.*T3;

           %OR
            
            %implement Agresti-Coull corrected version of Wald error bars
            %for proportion data
            
            nHat = ThisData.(char(i+64))(:,3)+4;
            pHat = ((ThisData.(char(i+64))(:,2).*ThisData.(char(i+64))(:,3))+2)./nHat;
            Upper = pHat + (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
            Lower = pHat - (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
                        
            errorbar(ThisData.(char(i+64))(:,1),ThisData.(char(i+64))(:,2),ThisData.(char(i+64))(:,2)-Lower, Upper - ThisData.(char(i+64))(:,2),'ko')
            
            t = (min(ThisData.(char(i+64))(:,1)):max(ThisData.(char(i+64))(:,1)))';
            Curve = TwoAFCSimultaneity_2P_Equation(FinalParams,t,Standard(i)); %Expanded Curve to plot points every ms
            plot(t,Curve,'k-')
            
            title(['Best fit for target pair ',num2str(Standard(i))])
            legend('Data','Fit')
            xlabel('SOA (ms)')
            ylabel('Proportion judged less simultaneous than target pair')
    
            hold off
                        
        end
    end
       
    figure
    hold on
    whiteout = MaxStims + 20;
    bigwidth = 5;
    PointSize = 1;
    
    for i = 1:26
        
        if i ~= 2 && ~isempty(ThisData.(char(i+64)))
        
            ThisTarget = repmat(Standard(i),size(ThisData.(char(i+64)),1),1);  
            for j = 1:size(ThisData.(char(i+64)),1)
                plot3(ThisData.(char(i+64))(j,1),ThisData.(char(i+64))(j,2),ThisTarget,'o','color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],...
                    'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth,'MarkerSize',ThisData.(char(i+64))(j,3)*PointSize)
            end
            t = (min(ThisData.(char(i+64))(:,1)):max(ThisData.(char(i+64))(:,1)))';
            ThisTarget = repmat(Standard(i),size(t,1),1);
            Curve = TwoAFCSimultaneity_2P_Equation(FinalParams,t,Standard(i)); %Expanded Curve to plot points every ms
            plot3(t,Curve,ThisTarget,'color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth)
        end
    end
    
    title('Best fit')
    %legend('Data','Fit')
    xlabel('SOA (ms)')
    ylabel('Proportion judged less simultaneous than target pair')
    zlabel('Target pair')
    view(30,60)
    grid on
    
    
    hold off

end

