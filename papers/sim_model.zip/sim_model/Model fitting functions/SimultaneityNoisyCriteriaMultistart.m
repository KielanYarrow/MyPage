function [FinalParams, LogLikelihood, Deviance, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameters] = SimultaneityNoisyCriteriaMultistart(StartParams,StepParams, EndParams, Data, varargin)
% Launching function to make SimultaneityNoisyCriteriaWapperForFmin
% start Simplex searches for a best fit from multiple points.
%
% This function fits a difference of two cumulative Gaussians to 
% simultaneity judgements (SJs) where the stim levels are defined in ms.
% For more details see:
%
% Yarrow, K., Jahn, N., Durant, S., & Arnold, D.H. (2011). Shifts of criteria or neural timing? 
% The assumptions underlying timing perception studies. Consciousness & Cognition, 20, 1518-31.
%
% To get it going, you need a command like this: 
%
% [FinalParams LogLikelihood] = SimultaneityNoisyCriteriaMultistart( [-400 0 10 10], [200 200 200 200], [0 400 410 410], Data)
%
% The model has four parameters (low boundary, high boundary, SD of cumulative
% Gaussian for low boundary, SD of Cumulative Gaussian for high boundary).
% When searching for best fitting parameters, it's possible to get trapped 
% at a "local maximum" best fit which is not always the global maximum. 
% Hence the function will initiate a Nelder-Mead search to find the best-fitting 
% model from multiple starting points. The first three arguments that are
% passed to the function specify the starting points to iterate through, in
% the format start:step:end for each of four parameters (e.g. for parameter 1
% the example above will test starting positions of -400, -200 and 0, because
% it starts at -400, moves up in steps of 200, and ends at 0). Hence this
% example actually sets in motion 3 x 3 x 3 x 3 = 81 fits. Finally, you get the best fit
% plotted from any of the starting positions. If you find with your data that
% you are not getting good fits, you may need to adjust these values to make
% sure one of the iterations starts reasonably close to where you believe the
% best fit actually lies.
%
% The fourth argument is the data you are fitting. This needs to be a matrix
% with three columns and as many rows as you have test values. The first column
% is the test value, the second column is the proportion of times they said it was
% simultaneous, the third column is the number of trials presented
% at that test value. For example, an experiment using the method of constant
% stimuli with 90 trials might yield idealised data that looks like this:
%
% -200  0       10
% -150  0.1     10
% -100  0.5     10
% -50   0.8     10
% 0     1       10
% 50    0.8     10
% 100   0.5     10
% 150   0.1     10
% 200   0       10
%
% The function can also accept additional input arguments and return more
% stuff, e.g.:
%
% [FinalParams, LogLikelihood, Deviance, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameters ] = SimultaneityNoisyCriteriaMultistart([-75 0 25 25],[75 75 50 50], [0 75 75 75], Data, 2, 0, 1999,1)
%
% Set optional arguments to zero or use [] to keep default behaviour.
%
% The Hessian matrix, if requested, tells you interesting things about the curvature of
% the likelihood surface at the point of best fit, and allows an estimate
% of variances/covariances of the parameters.
%
% Set optional argument #1 to either a step size (such as 0.001) or
% 1 for Hessian based confidence intervals or 2
% for Bca bootstrap intervals (which will take ages of course, but are
% likely to have better coverage). For the hessian option, using 1 will call code
% which attempts to figure out the right step size to use when applying
% numerical differentiation on the likelihood surface. However, this
% doesn't seem to work well for this particular fit, so I would recommend
% using the simpler code, which requires that you specify the step size
% (a small number like 0.001 or 0.01 has worked well for me).
%
% Optional argument #2 enables simulation (rather than equation) based model 
% predictions when the equations yield sub-zero predictions for reports of
% simultaneity (which can happen when the SDs of the two component
% Gaussians are very different, particularly if the boundaries are close
% together). This option will increase the time to find a fit quite a lot.
% Pass 1 to turn this on, or 2 to also get warnings when simulations are used.
%
% Optional argument #3 lets you override the default (1999) number of bootstraps 
% if you've requested bootstrap confidence intervals.
%
% Optional argument #4 can be set to 1 if you would also like to fit a
% guessing model (in this case a cumulative Gaussian, which has two
% parameters). You can then multiply the guessing model's log likelihood
% (GuessLogLikelihood) by -2, do likewise for the SJ model's 
% log likelihood (Loglikelihood) and compare them. The improvement for the
% more complex model will follow a chi-squared distribution with d.f. =
% difference in parameters, so in this case compare to chi-square(df=2) to
% see if the improvement in fit is significant (in which case your
% participant probably wasn't just guessing AND you sampled SOAs widely enough
% to capture both of their boundaries). It will take some extra time
% because the null model is fairly complex.

    if nargin >= 5 && ~isempty(varargin{1})
        ConfidenceIntervals = varargin{1};
        Bootstraps = 1999;
        LowCI = 0.025;
        HighCI = 0.975;
    else
        ConfidenceIntervals = 0;
    end 
    
    if nargin >= 6 && ~isempty(varargin{2})%use this optional parameter to decide if simulation 
        %rather than equation-based method will be used when prediction
        %from equations is dodgy. Pass 1 to switch on, or 2+ to also switch on messages
        %when simulations occur.
        GoToSim = varargin{2};
    else
        GoToSim = 0;
    end
    
    if nargin >= 7 && ~isempty(varargin{3})
        
        Bootstraps = varargin{3};
            
    end 
    
    if nargin >= 8 && ~isempty(varargin{4})
        
        TestGuessingModel = varargin{4};
        
    else
        TestGuessingModel = 0;
        
    end 
    
    GuessLogLikelihood = [];
    GuessParameters = [];
    
    if TestGuessingModel
        fprintf('Two parameter Guess model tested first\r')
        [GuessParameters1, GuessLogLikelihood1] = CumulativeGaussianMultistart(StartParams([1 3]),StepParams([1 3]), EndParams([1 3]), Data);
        pause(1)
        [GuessParameters2, GuessLogLikelihood2] = CumulativeGaussianMultistart([StartParams(2) StartParams(4).*-1],[StepParams(2) StepParams(4).*-1], [EndParams(2) EndParams(4).*-1], Data);
        pause(1)
        GuessParameters = min([GuessParameters1;GuessParameters2],[],1);
        GuessLogLikelihood = min([GuessLogLikelihood1;GuessLogLikelihood2],[],1);
    end 

    FinalParams = [0 0 0 0];
    CIFinalParams = [0 0; 0 0;0 0; 0 0]; 
    LogLikelihood = -1.*realmax;
    Deviance = realmax;

    counteri = 0;
    for i = StartParams(1):StepParams(1):EndParams(1)
        counteri = counteri + 1;

       counterj = 0;
       for j = StartParams(2):StepParams(2):EndParams(2)
           counterj = counterj + 1;

           counterk = 0;
           for k = StartParams(3):StepParams(3):EndParams(3)
               counterk = counterk + 1;

               counterl = 0;
               for l = StartParams(4):StepParams(4):EndParams(4)
                   counterl = counterl + 1;

                   Parameters = [i j k l];

                   tic
                                                
                   [TempParams, This_MLE, TempD, TempHess, TempCovar] = SimultaneityNoisyCriteriaWrapperForFmin(Parameters,Data,0,GoToSim,ConfidenceIntervals);

                   if counteri == 1 && counterj == 1 && counterk == 1 && counterl == 1
                       TimePerFunctionCall = toc
                   end

                   %ZPlot(counteri,counterj,counterk,counterl) = This_MLE;

                   if This_MLE > LogLikelihood
                       LogLikelihood = This_MLE;
                       Deviance = TempD;
                       FinalParams = TempParams;
                       Hess = TempHess; 
                       Covar = TempCovar; 
                   end
               end
           end
       end

    end
    
    % One last go 
   [TempParams, This_MLE, TempD, TempHess, TempCovar] = SimultaneityNoisyCriteriaWrapperForFmin(FinalParams,Data,0,GoToSim,ConfidenceIntervals);

   if This_MLE > LogLikelihood
       LogLikelihood = This_MLE;
       Deviance = TempD;
       FinalParams = TempParams;
       Hess = TempHess; 
       Covar = TempCovar; 
   end
        
   %implement Wilson Score confidence interval for proportion data
    
   T1 = 1./(1 + ((1./Data(:,3)).*(1.96^2)));
   T2 = Data(:,2)  + (1./(2.*Data(:,3))).*(1.96.^2) +  (1.96.*((((1./Data(:,3)).*Data(:,2).*(1-Data(:,2))) + ((1.96^2).*(1./(4.*(Data(:,3).^2))))).^0.5));
   T3 = Data(:,2)  + (1./(2.*Data(:,3))).*(1.96.^2) -  (1.96.*((((1./Data(:,3)).*Data(:,2).*(1-Data(:,2))) + ((1.96^2).*(1./(4.*(Data(:,3).^2))))).^0.5));
   
   Upper = T1.*T2;
   Lower = T1.*T3;
   
   %OR
   
    %implement Agresti-Coull corrected version of Wald error bars
    %for proportion data

%     nHat = Data(:,3)+4;
%     pHat = ((Data(:,2).*Data(:,3))+2)./nHat;
%     Upper = pHat + (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
%     Lower = pHat - (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
    
     %create lookup for normal cumulative distribution function
    x = [-5:0.001:5];
    NCD = 0.5 + (erf(x./(sqrt(2)))./2);             
                           
    
    if ConfidenceIntervals  %use Hessian matrix estimates
        for i = 1:length(FinalParams)
            CIFinalParams(i,1) = FinalParams(i)-((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
            CIFinalParams(i,2) = FinalParams(i)+((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
        end
    end
    if ConfidenceIntervals == 2 %bootstrap
        
        %create matrix of trials
        AllTrials = zeros(sum(Data(:,3)),2);
        counter = 0;
        for i = 1:length(Data)
            for j = 1:Data(i,3)
                counter = counter + 1;
                AllTrials(counter,1) = Data(i,1);
                if j <= round((Data(i,2) .* Data(i,3)))
                    AllTrials(counter,2) = 1;
                end
            end            
        end
        
        BootstrapParams = zeros(Bootstraps,length(FinalParams));
    
        for i = 1:Bootstraps

           tic
           
           %sample with replacement
           Positions = randi(length(AllTrials),length(AllTrials),1);
           %Positions = ceil(rand(length(AllTrials),1).*length(AllTrials));
           ThisBootstrap = AllTrials(Positions,:);

           %Sort down to a Data set
           counter = 0;
           ThisData = zeros(1,size(Data,2)); % just one down as we don't know 
           %how big this will end up being so difficult to preallocate

           for j = min(ThisBootstrap(:,1)):max(ThisBootstrap(:,1))
               subset = (ThisBootstrap(:,1) == j);
               subset = ThisBootstrap(subset,:);
               if ~isempty(subset)
                   counter = counter + 1;
                   ThisData(counter,:) = [j (sum(subset(:,2))./size(subset,1)) size(subset,1)]; 
               end
           end

           [BootstrapParams(i,:), ~, ~, ~, ~] = SimultaneityNoisyCriteriaWrapperForFmin(FinalParams,ThisData, 0, GoToSim,0);                     

           clear ThisData

           if i == 1
               Bootstraps
               TimePerBootstrap = toc
           end

        end
        
        BootstrapMeanParams = mean(BootstrapParams);    
        
        %For BCa intervals, we need some extra stuff. 
        %First, a jackknife on the data
        
        JackknifeParams = zeros(length(AllTrials),length(FinalParams));
    
        for i = 1:length(AllTrials)

           tic
           
           %remove one trial
           include = [1:length(AllTrials)];
           include = include(include ~= i);
           ThisJackknife = AllTrials(include,:);
           
           %Sort down to a Data set
           counter = 0;
           ThisData = zeros(round(size(Data,1)./2),size(Data,2)); % start off
           %at half size; with jackknife, likely to be close to original
           %size by the end

           for j = min(ThisJackknife(:,1)):max(ThisJackknife(:,1))
               subset = (ThisJackknife(:,1) == j);
               subset = ThisJackknife(subset,:);
               if ~isempty(subset)
                   counter = counter + 1;
                   ThisData(counter,:) = [j (sum(subset(:,2))./size(subset,1)) size(subset,1)]; 
               end
           end

           [JackknifeParams(i,:), ~, ~, ~, ~] = SimultaneityNoisyCriteriaWrapperForFmin(FinalParams,ThisData,0,GoToSim,0);                     

           clear ThisData

           if i == 1
               NumberJackknifes = length(AllTrials)
               TimePerJackknife = toc
           end

        end
        
        JackknifeMeanParams = repmat(mean(JackknifeParams),NumberJackknifes,1);
        %find means and scale up for vectorised operations
        
        %bits for acceleration formula
        topeq = sum((JackknifeMeanParams-JackknifeParams).^3);
        bottomeq = 6.*(sum((JackknifeMeanParams-JackknifeParams).^2)).^(3/2);
        
        %bits for bias formula
        scaleup = repmat(FinalParams,Bootstraps,1);
        biascount = (BootstrapParams < scaleup);
        bias = sum(biascount)./Bootstraps;
               
        %LowCI = 0.025;
        %HighCI = 0.975;        
                
        for i = 1:length(FinalParams)

            ThisDist = sort(BootstrapParams(:,i));
            
            %Percentile
            %CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCI));
            %CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCI));
            
            %Reverse limits as suggested by Howell            
            %CIFinalParams(i,1) = FinalParams(i) - (ThisDist(round((Bootstraps+1).*HighCI))-FinalParams(i));
            %CIFinalParams(i,2) = FinalParams(i) + (FinalParams(i)-ThisDist(round((Bootstraps+1).*LowCI)));
            
            %BCa
            Acceleration = topeq(i)./bottomeq(i);
            Thisbias = x(find(NCD<=bias(i), 1, 'last' ));
            if isempty(Thisbias)
                Thisbias = x(1);
                fprintf('Warning: Possible bootstrap issue \n')
            end
            
            LowCut = Thisbias + ( (Thisbias + x(find(NCD<=LowCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=LowCI, 1, 'last'))))) );
            LowCut = NCD(find(x<=LowCut, 1, 'last' ));
            if isempty(LowCut)
                LowCut = 0;
            end
            HighCut = Thisbias + ( (Thisbias + x(find(NCD<=HighCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=HighCI, 1, 'last'))))) );
            HighCut = NCD(find(x<=HighCut, 1, 'last' ));
            if isempty(HighCut)
                HighCut = 0;
            end
            
            if round((Bootstraps+1).*LowCut) < 1 
                CIFinalParams(i,1) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*LowCut) >= length(ThisDist)
                CIFinalParams(i,1) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCut));
            end
            
            if round((Bootstraps+1).*HighCut) < 1
                CIFinalParams(i,2) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*HighCut) >= length(ThisDist)
                CIFinalParams(i,2) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCut));
            end
            
        end
    
    end
        
    close all
    %RePlot best fit against data
    figure
    hold on
    %plot(Data(:,1),Data(:,2),'or') 
    errorbar(Data(:,1),Data(:,2),Data(:,2)-Lower, Upper - Data(:,2),'ro') %UPDATED!
    t = (min(Data(:,1)):max(Data(:,1)))';
    Curve = SimultaneityNoisyCriteria(FinalParams,t,GoToSim); %Expanded Curve to plot points every ms 
    plot(t,Curve)
    
    if ConfidenceIntervals >0 && FinalParams(1) > min(Data(:,1)) && FinalParams(2) < max(Data(:,1)) %UPDATED!
        
        plot([CIFinalParams(1,1) CIFinalParams(1,2)],[Curve(round(FinalParams(1))-min(t)+1) Curve(round(FinalParams(1))-min(t)+1)],'g')
        plot([CIFinalParams(2,1) CIFinalParams(2,2)],[Curve(round(FinalParams(2))-min(t)+1) Curve(round(FinalParams(2))-min(t)+1)],'g')
        plot([CIFinalParams(1,1) CIFinalParams(1,1)],[Curve(round(FinalParams(1))-min(t)+1)-0.01 Curve(round(FinalParams(1))-min(t)+1)+0.01],'g')
        plot([CIFinalParams(2,1) CIFinalParams(2,1)],[Curve(round(FinalParams(2))-min(t)+1)-0.01 Curve(round(FinalParams(2))-min(t)+1)+0.01],'g')
        plot([CIFinalParams(1,2) CIFinalParams(1,2)],[Curve(round(FinalParams(1))-min(t)+1)-0.01 Curve(round(FinalParams(1))-min(t)+1)+0.01],'g')
        plot([CIFinalParams(2,2) CIFinalParams(2,2)],[Curve(round(FinalParams(2))-min(t)+1)-0.01 Curve(round(FinalParams(2))-min(t)+1)+0.01],'g')
         
    end %/UPDATED!
    
    title('Best fit')
    legend('Data','Fit')
    xlabel('SOA (ms)')
    ylabel('Proportion')
    %for i = 1:length(Data)
     %   plot(Data(i,1),Data(i,2),'or','MarkerSize',round(Data(i,3)./sum(Data(:,3),1).*length(Data).*7))

    %end
    hold off
    
    FinalParams = FinalParams';
    

end

