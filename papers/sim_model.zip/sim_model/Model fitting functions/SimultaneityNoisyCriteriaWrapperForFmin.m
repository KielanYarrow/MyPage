% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a difference of two cumulative Gaussian model of 
% simultaneity judgements with four parameters: Mean of CG1, mean of CG2,
%  SD1, SD2. See Yarrow et al 2011 for more details. StartParams should be a
% vector with 4 values. Data should be a matrix, with column 1 as the
% tested values, column 2 as proportions judged simultaneous, and column three 
% as the number of
% presentations.

function [FinalParams, LogLikelihood, Deviance, Hess, Covar] = SimultaneityNoisyCriteriaWrapperForFmin(StartParams,Data,varargin)

    if nargin >= 3 && ~isempty(varargin{1})
        ploton = varargin{1};
    else
        ploton = 0;
    end
    
    if nargin >= 4 && ~isempty(varargin{2})%used to use a simulation based model function in place of equations
        %when slopes of cumulative Gaussians are very different so that
        %equations break down. Will add some time (and perhaps noise) to
        %computation. Pass 1 to switch on, or 2+ to also switch on messages
        %when simulations occur.
        GoToSim = varargin{2};
    else
        GoToSim = 0;
    end
    
    Deviance = [];
    Hess = [];
    Covar = [];
    
    if nargin >= 5 && ~isempty(varargin{3})
        FullDiagnostics = varargin{3};
    else
        FullDiagnostics = 0.001; %Defaults to returning Hessian Matrix and Covariance, but pass a 0 as final parameter to turn this off (e.g. during bootstraps)
    end

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams)
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin (@wrapped, 4, StartParams, ...
        100, [50 50 50 50], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    if FullDiagnostics
    
        Curve = SimultaneityNoisyCriteria(FinalParams,Data,GoToSim);
        [Deviance] = BinomialDeviance(Curve, Data, 0.0000000001, 0.01);
        if FullDiagnostics == 1
            [Hess,~] = hessian(@wrapped,FinalParams);
        else
            Hess = lnLhessian( @wrapped,FinalParams,FullDiagnostics );
            %Note, a final parameter of 0.001 works well here.
        end
        warning('off','MATLAB:illConditionedMatrix')
        warning('off','MATLAB:singularMatrix')
        Covar = inv(Hess);
        warning('on','MATLAB:illConditionedMatrix')
        warning('on','MATLAB:singularMatrix')
    end
        
    if ploton == 1
        %Plot best fit against data
        figure
        hold on
        plot(Data(:,1),Data(:,2),'o')
        t = (min(Data(:,1)):max(Data(:,1)))';
        Curve = SimultaneityNoisyCriteria(FinalParams,t,GoToSim); %Expanded Curve to plot points every ms
        plot(t,Curve)
        hold off
    end
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params(3) <= 0 | Params(4) <= 0
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            SimulatedProportions = SimultaneityNoisyCriteria(Params,Data,GoToSim); %Returns vector of Simulated data for these params
                   
            %parameters generating predicted probabilities below
            %zero should be rejected
            bigproblem = find(SimulatedProportions < 0);
            bigproblem = sum(bigproblem);
            
            %This bit adjusts predictions slightly: Prevents values of 0 and 1 as
            %these will ruin an MLE fit to the data
            %Does so by assuming keying error on 1% of trials
            Guess = 0.01;
            SimulatedProportions =  (SimulatedProportions.*(1-(2*Guess)))+(ones(size(SimulatedProportions,1),size(SimulatedProportions,2)).*Guess);
                            
            %This bit adjusts predictions slightly
            %Guess = 0.01;
            %problem = find(SimulatedProportions < Guess); %Prevents values of 0 and 1 as 
            %SimulatedProportions(problem) = Guess;          %these will ruin an MLE fit to the data
            %problem = find(SimulatedProportions > 1-Guess);    
            %SimulatedProportions(problem) = 1-Guess; 
            
            %The this bit applies the appropriate "data model", in this
            %case based on the binomial distributions as this is forced
            %choice data
            DataB = Data;
            DataB(:,2) = round(Data(:,2).*Data(:,3)); %change from proportions to numbers
            
            %for i = 1:length(Data(:,1))
            %    MLEperStimLevel(i) = BinomialLikelihood(DataB(i,2),DataB(i,3),SimulatedProportions(i));
            %end
                   
            %MLE = sum(log(MLEperStimLevel));
            
            %Vectorised approach with kernal LL; much quicker, but less clear what is
            %going on.
            %I think I got this from Wichmann & Hill. It uses a kernel
            %log likelihood function, so don't mix and match with the
            %approach above! (kernel = missing terms that only add
            %constants)
            MLEperStimLevel = (DataB(:,2).*log(SimulatedProportions))...
                + ((DataB(:,3)-DataB(:,2)).*log(1-SimulatedProportions));
            
            MLE = sum(MLEperStimLevel);                       
            
            InverseLikelihood = MLE .* -1;
            
            %Reject for any predicted probs < 0
            if bigproblem > 0
                InverseLikelihood = realmax; %This clause effectively sets likelihood to zero
            end
            
        end
        
    end

end