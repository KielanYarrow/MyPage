%Simulator for simple mean model of 
% ternary order judgements with two parameters: Mean L and Mean S. 
% parameters (Params) has two values (parameters for this fit)
%Data also needs to be supplied (five columns: test values, etc.,l, although only first column needed here)
%in order to return a matrix of simulated
%values at each tested value

function SimulatedData = MeanProbTernary(Params,Data)


SimulatedData(:,1) = ones(size(Data,1),1).*Params(1); 
SimulatedData(:,2) = ones(size(Data,1),1).*Params(2); %prob sim predicted by model
SimulatedData(:,3) = 1 - (SimulatedData(:,1)+SimulatedData(:,2));


