% Returns a single deviance score, based on a binomial data model (according to 
% papers by Wichmann & Hill). Requires
% the data, in three columns (test values, proportion, Number of trials)
% and also the model predictions (curve). Two further argments (Adjuster &
% Guess) are used to deal with log 0 issues; consider setting guess to 0.01
% implying a 1% lapse rate, and adjuster to 0.0000000001

function [Deviance] = MultinomialDeviance(Curves, Data, Adjuster, Guess)
   
DataB = Data;
DataB(:,2) = round(Data(:,2).*Data(:,5)); %change from proportions to numbers
DataB(:,3) = round(Data(:,3).*Data(:,5));
DataB(:,4) = round(Data(:,4).*Data(:,5)); 

Data = Data(:,2:4); %cut out  bits that aren't needed for saturated evaluation
LowNaughty = (Data < Adjuster);
HighNaughty = (Data > (1-Adjuster));

%This bit adjusts predictions slightly: Prevents values of 0 and 1 as
%these will ruin an MLE fit to the data
%Does so by assuming keying error on 1% of trials
Curves =  (Curves.*(1-(2*Guess)))+(ones(size(Curves,1),size(Curves,2)).*Guess);
     
%Alternative based on comparison with saturated model

LLperStimLevel = zeros(length(Data(:,1)),1);
SaturatedLLperStimLevel = zeros(length(Data(:,1)),1);
for i = 1:size(Data(:,1),1)
    LLperStimLevel(i) = MultinomialLikelihood(DataB(i,2:4),Curves(i,:));
    Data(i,LowNaughty(i,:)) = Adjuster;
    Data(i,HighNaughty(i,:)) = 1-Adjuster;
    SaturatedLLperStimLevel(i) = MultinomialLikelihood(DataB(i,2:4),Data(i,:));
end

MLE = sum(LLperStimLevel); 
SaturatedModel = sum(SaturatedLLperStimLevel);

Deviance = -2.*(MLE-SaturatedModel);