% returns likelihood estimate from a binomial distribution by comparing the
% number of "correct" responses (k) out of the total number of responses
% (N) to the probability prediction of a model (p). Call once at each data
% point that needs evaluating, then multiply together (for likelihood) or
% log and sum (for log likelihood)

function likelihood = BinomialLikelihood(k, N, p)

likelihood = nchoosek(N,k).*p.^k.*(1-p).^(N-k);