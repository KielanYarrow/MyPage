%Simulator for cumulative Gaussian model of 
% order judgements with two parameters: Mean of CG1,SD. 
% parameter (Params) has two values (the parameters for this fit)
%Data also needs to be supplied (three columns: test values, proportion
%longer/bigger/later, number of presentations, although only first column needed here)
%in order to return a vector of simulated
%values at each tested value

function SimulatedData = CumulativeGaussian(Params,Data)

erf_Input1 = (Data(:,1)-Params(1))./(sqrt(2).*Params(2));

erf_Output1 = erf(erf_Input1);

%Note: the root2 when estimating parameter2 reflects the relationship
%between the erf and the cumulative gaussian: the parameter will be an
%estimate of the SD of the difference distribution, not the
%distribution of each separate signal

SimulatedData = 0.5 + (erf_Output1./2); %prob sim predicted by model


