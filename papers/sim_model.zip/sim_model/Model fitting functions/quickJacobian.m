function [ Jac, JRank ] = quickJacobian( Params, Predictions, model, varargin )
%function taken from Lewandowsky & Farrell 2011 to find the Jacobian matrix
%from some model parameters, corresponding predictions, plus the models
%name and whatever else the generating model needs (e.g. data to predict
%values for). See page 210 for discussion

%Basically, the rand of the Jacobian should equal the number of parameters
%in your model if the model is "identifiable" (i.e. no parameters are
%degenerate/ prone to trade off).

%Generally, pass it the model's parameters as a vector (Params), the Predictions at
%that set of Parameters (Predictions), the address of the generating
%function for the model ('@...') and the stimulus/data values that correspond
%to the Predictions (e.g. stim value in an MCS experiment). So, for one of
%my models:

%[ Jac, JRank ] = quickJacobian( FinalParams, [], @SimultaneityNoisyCriteria, Output )

%would work nicely, and JRank should equal the number of parameters if the
%model is identifiable

if isempty(Predictions)
    Predictions = feval(model,Params,varargin{:});
end

Np = length(Params);
Nd = length(Predictions);
Jac = zeros(Nd,Np);
epsilon = sqrt(eps);

%Iterate over parameters to estimate columns of Jacobian by finite
%differences.

for i = 1:Np
    x_offset = Params;
    x_offset(i) = x_offset(i) + epsilon;
    
    %Get model predictions for offest parameter vector
    f_offset = feval(model,x_offset,varargin{:});
    Jac(:,i) = (f_offset-Predictions)/epsilon;
end

JRank = rank(Jac);

end

