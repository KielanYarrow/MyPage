function disc=spncf_(x,n1,n2,theta1,theta2,alpha)
% used to find x such that Pr(F<x)=alpha.
% CALLED BY ncf2cdfx.m which finds the cutoff value.

disc=abs(spncf(x,n1,n2,theta1,theta2,2) - alpha);
