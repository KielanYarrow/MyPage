function cdf = ncf(xvec,n1,n2,theta1,theta2)
% cdf = ncf(xvec,n1,n2,theta1,theta2)
%
% evaluates the cdf of the doubly noncentral F distribution
% allows vector x and scalar n1,n2,theta1,theta2
%tic

if nargin<5, theta2=0; end
if (theta2==0)
  cdf=ncf1(xvec,n1,n2,theta1,0); 
  return
elseif ((theta2>0) & (theta1==0))
  cdf=1-ncf1(1./xvec,n2,n1,theta2,0); 
  return
end

cdf=[]; tol=1e-17; xlen=length(xvec); atleast=20;
for xloop=1:xlen
  x=xvec(xloop); 
  tmp=n1*x / (n2+n1*x);
  done = 0; k = 0;
  c2=round(theta2/2);
  verteil= ppdf(c2,theta2/2) * ncf1(x,n1,n2,theta1,0,c2);
  while ~done
    k=k+1;
    oldv=verteil;
    
    m1=c2+k;
    nextv = ppdf(m1,theta2/2)*ncf1(x,n1,n2,theta1,0,m1);
    verteil= verteil + nextv;
    
    m2=c2-k;
    if m2>=0
      nextv = ppdf(m2,theta2/2)*ncf1(x,n1,n2,theta1,0,m2);
      verteil= verteil + nextv;
    end
    
    done=(verteil-oldv < tol) & (k>atleast);
    stop = isnan(verteil); stop = stop | isinf(verteil); 
    if stop, break, end
  end
  cdf=[cdf verteil];
end

%toc

function y=ppdf(x,lambda);
  % try to speed things up a bit by avoiding the series 
  % of matlab programs to eventually compute this.
  y = exp(-lambda + x .* log(lambda) - gammaln(x + 1));
