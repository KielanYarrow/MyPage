%Simulator for simple mean model of 
% order judgements with one parameter: Mean. 
% parameter (Params) has one values (the parameter for this fit)
%Data also needs to be supplied (three columns: test values, proportion
%longer/bigger/later, number of presentations, although only first column needed here)
%in order to return a vector of simulated
%values at each tested value

function SimulatedData = MeanProb(Params,Data)


SimulatedData = ones(size(Data,1),1).*Params; %prob sim predicted by model


