%Simulator for difference of two cumulative Gaussian model of 
% simultaneity judgements with three parameters: Mean of CG1, mean of CG2,
% SD. See Yarrow et al 2011 for more details. First input 
% parameter (Params) has three values (the parameters for this fit)
%Data also needs to be supplied (three columns: test values in ms, proportion
%simultaneous, number of presentations, although only first column needed here)
%in order to return a vector of simulated
%values at each tested value

function SimulatedData = SimultaneityDiffCumGauss(Params,Data)

erfc_Input1 = (Data(:,1)-Params(1))./(sqrt(2).*Params(3));
erfc_Input2 = (Data(:,1)-Params(2))./(sqrt(2).*Params(3));
erfc_Output1 = erfc(erfc_Input1);
erfc_Output2 = erfc(erfc_Input2);

%Note: the root2 when estimating parameters 3 & 4 reflects the relationship
%between the erf and the cumulative gaussian: the parameter will be an
%estimate of the SD of the difference in arrival time distribution, not the
%arrival time of each separate signal

SimulatedData = (erfc_Output2-erfc_Output1)./2; %prob sim predicted by model


