% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a difference of two cumulative Gaussian model of 
% ternary judgements with three parameters: Mean of CG1, mean of CG2,
% SD. See Yarrow et al 2011 for more details (ish). StartParams should be a
% vector with 3 values. Data should be a matrix, with column 1 as the
% tested values, column 2 as proportion judged sound first (if neg SOA = sound first),
% column 3 as proportion judged simultaneous, column 4 as proportion judged
% light first (if pos SOA = light first) and column five 
% as the number of
% presentations.

function [FinalParams, LogLikelihood, Deviance, Hess, Covar] = TernaryDiffCumGaussWrapperForFmin(StartParams,Data,varargin)

    if nargin >= 3 && ~isempty(varargin{1})
        ploton = varargin{1};
    else
        ploton = 0;
    end
            
    Deviance = [];
    Hess = [];
    Covar = [];
    
    if nargin >= 4 && ~isempty(varargin{2})
        FullDiagnostics = varargin{2};
    else
        FullDiagnostics = 0.001; %Defaults to returning Hessian Matrix and Covariance, but pass a 0 as final parameter to turn this off (e.g. during bootstraps)
    end

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams)
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin (@wrapped, 3, StartParams, ...
        100, [50 50 50], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    if FullDiagnostics
    
        Curve = TernaryDiffCumGauss(FinalParams,Data);
        [Deviance] = MultinomialDeviance(Curve, Data, 0.0000000001, 0.01); 
        
        if FullDiagnostics == 1
            [Hess,~] = hessian(@wrapped,FinalParams);
        else
            Hess = lnLhessian( @wrapped,FinalParams,FullDiagnostics );
            %Note, a final parameter of 0.001 works well here.
        end
        warning('off','MATLAB:illConditionedMatrix')
        warning('off','MATLAB:singularMatrix')
        Covar = inv(Hess);
        warning('on','MATLAB:illConditionedMatrix')
        warning('on','MATLAB:singularMatrix')
    end
        
    if ploton == 1
        %Plot best fit against data
        figure
        hold on
        plot(Data(:,1),Data(:,2),'bo',Data(:,1),Data(:,3),'ro',Data(:,1),Data(:,4),'go')
        t = (min(Data(:,1)):max(Data(:,1)))';
        Curves = TernaryDiffCumGauss(FinalParams,t); %Expanded Curve to plot points every ms
        plot(t,Curves(:,1),'b',t,Curves(:,2),'r',t,Curves(:,3),'g')
        legend('first','simultaneous','second')
        hold off
    end
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params(3) <= 0 || Params(1) > Params(2)
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            SimulatedProportions = TernaryDiffCumGauss(Params,Data); %Returns vector of Simulated data for these params
                   
                       
            %This bit adjusts predictions slightly: Prevents values of 0 and 1 as
            %these will ruin an MLE fit to the data
            %Does so by assuming keying error on 1% of trials
            Guess = 0.01;
            SimulatedProportions =  (SimulatedProportions.*(1-(2*Guess)))+(ones(size(SimulatedProportions,1),size(SimulatedProportions,2)).*Guess);
                        
            %The this bit applies the appropriate "data model", in this
            %case based on the multinomial distribution
            DataB = Data;
            DataB(:,2) = round(Data(:,2).*Data(:,5)); %change from proportions to numbers
            DataB(:,3) = round(Data(:,3).*Data(:,5));
            DataB(:,4) = round(Data(:,4).*Data(:,5));
            
            LLperStimLevel = zeros(length(Data(:,1)),1);
            for i = 1:size(Data(:,1),1)
                LLperStimLevel(i) = MultinomialLikelihood(DataB(i,2:4),SimulatedProportions(i,:));
                %BinomialLikelihood(DataB(i,2),DataB(i,3),SimulatedProportions(i));
            end
                   
            MLE = sum(LLperStimLevel);                                              
            
            InverseLikelihood = MLE .* -1;
            
            
        end
        
    end

end