function h = lnLhessian( lnLfun,params,delta,varargin )
%this function is copied from Lewandowsky and Farrell 2011 (page 159/160)
%it calculates the hessian matrix (the set of second partial derivatives
%around the maximum likelihood fit, which indicate curvature of the
%likelihood surface and therefore can be transformed to give a covariance
%matrix which will allow estimation of confidence intervals on parameter
%estimates. See the book more details!

%The argument lnLfun should be passed as a string e.g. 'wrapped' (if used
%within a nelder-mead container the way I ususally set things up

%The funciton expects the free parameters to be provided in a single vector
%params. Extra arguments (and/or data) can be passed in 
%varargin. delta is the step size in Hessian calculations.

%e is the identity matrix, and is used to implement their equation 5.1

e = eye(length(params)).*delta;
for i = 1:length(params)
    for j = 1:length(params)
        C(i,j) = feval(lnLfun,params+e(i,:)+e(j,:),varargin{:})-...
            feval(lnLfun,params+e(i,:)-e(j,:),varargin{:})-...
            feval(lnLfun,params-e(i,:)+e(j,:),varargin{:})+...
            feval(lnLfun,params-e(i,:)-e(j,:),varargin{:});
    end
end
h = C./(4.*(delta.^2));

end

