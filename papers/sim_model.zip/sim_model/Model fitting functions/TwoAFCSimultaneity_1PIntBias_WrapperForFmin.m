% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a chance model of 
% 2AFC simultaneity judgements. StartParams should be a
% vector with 1 value. Data should be a matrix, with column 1 as the
% SOAs tested against a zero SOA target, column 2 as proportions judged less simultaneous, column three 
% as the number of presentations. Optional arguments should be passed in
% triplets, with the first being a target value for a supplementary data set
% (e.g. trials with various comparisons against an SOA of -20). The second
% parameter should be a Data matrix set against these values. The third
% should be the interval of the target; 0 for second, 1 for first


function [FinalParams, LogLikelihood, Deviance] = TwoAFCSimultaneity_1PIntBias_WrapperForFmin(StartParams,Data,varargin)

    ploton = 0;

    Target(1) = 0;
    Interval(1) = 0;

    if nargin > 2 %extra data passed
        if mod(nargin,3) == 2 %extra triplets passed
            DataSets =  1 + ((nargin-2)./3);
            for i = 2:DataSets
                Target(i) = varargin{(i.*3)-5}; 
                Interval(i) = varargin{(i.*3)-3};
            end
        else
            YouArseYouDidntPassTriplets = 1
            DataSets = 1;
        end
    else
        DataSets = 1;
    end
            

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams)
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin (@wrapped, 1, StartParams, ...
        100, [0.2], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    Deviance = 0;
    
    
    for i = 1:DataSets                

        if i > 1
             ThisData = varargin{(i.*3)-4}; 
        else
            ThisData = Data;
        end

        if ~isempty(ThisData)

            Curve = MeanProb(FinalParams,ThisData);
            Deviance = Deviance + BinomialDeviance(Curve, ThisData, 0.0000000001, 0.01);

            if ploton

                %Plot best fit against data
                figure
                hold on
                plot(ThisData(:,1),ThisData(:,2),'o')
               
                plot(ThisData(:,1),Curve)
                xlabel('SOA')
                ylabel(strcat('Proportion judged less simultaneous than ',int2str(Target(i))))
                hold off

            end

        end

    end
        
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params(1) <= 0 || Params(1) > 1
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            
            MLE = 0;
            
            for i = 1:DataSets                
        
                if i > 1
                     ThisData = varargin{(i.*3)-4}; 
                else
                    ThisData = Data;
                end
                
                if Interval(i) ~= 0
                    Params = 1-Params;
                end
            
                if ~isempty(ThisData) %hopefully ignore empty data sets...
            
                    SimulatedProportions = MeanProb(Params,ThisData); %Returns vector of Simulated data for these params

                    %This bit adjusts predictions slightly: Prevents values of 0 and 1 as
                    %these will ruin an MLE fit to the data
                    %Does so by assuming keying error on 1% of trials
                    Guess = 0.01;
                    SimulatedProportions =  (SimulatedProportions.*(1-(2*Guess)))+(ones(size(SimulatedProportions,1),size(SimulatedProportions,2)).*Guess);
                    
                    %This bit adjusts predictions slightly
                    %Guess = 0.01;
                    %problem = find(SimulatedProportions < Guess); %Prevents values of 0 and 1 as 
                    %SimulatedProportions(problem) = Guess;          %these will ruin an MLE fit to the data
                    %problem = find(SimulatedProportions > 1-Guess);    
                    %SimulatedProportions(problem) = 1-Guess; 

                    %The this bit applies the appropriate "data model", in this
                    %case based on the binomial distributions as this is forced
                    %choice data
                    DataB = ThisData;
                    DataB(:,2) = round(ThisData(:,2).*ThisData(:,3)); %change from proportions to numbers

                    %for j = 1:length(ThisData(:,1))
                    %    MLEperStimLevel(j) = BinomialLikelihood(DataB(j,2),DataB(j,3),SimulatedProportions(j));
                    %end

                    %MLE = MLE + sum(log(MLEperStimLevel));

                    %Vectorised approach with kernal LL; much quicker, but less clear what is
                    %going on.
                    %I think I got this from Wichmann & Hill. It uses a kernel
                    %log likelihood function, so don't mix and match with the
                    %approach above! (kernel = missing terms that only add
                    %constants)
                    MLEperStimLevel = (DataB(:,2).*log(SimulatedProportions))...
                        + ((DataB(:,3)-DataB(:,2)).*log(1-SimulatedProportions));

                    MLE = MLE + sum(MLEperStimLevel); 

                    InverseLikelihood = MLE .* -1;
                    
                end
            
            end
            
            
        end
        
    end

end





