This set of functions will fit models described in papers by Yarrow to temporal judgement data (SJs, TOJs, etc.) The required data formats are outlined the function help information (see below) but in general, for plotting to work well, you should make sure stimulus onset asynchronies are expressed in milliseconds.

Unzip, put all the folders/files on your Matlab path and then type one of the following:

�help SimultaneityNoisyCriteriaMultistart� (to fit SJ data to a four-parameter model)
"help TernaryNoisyCriteriaMultistart" (the same model applied to ternary data)

�help SimultaneityDiffCumGaussMultistart� (for a simpler three-parameter model of SJs generating a symmetric psychometric function).
"help TernaryDiffCumGaussMultistart" (the same model applied to ternary data)

"help CumulativeGaussianMultistart" (for a two-parameter TOJ model)

"help TwoAFCSimultaneity_3PEq_Multistart_rawdata" (fits a 3P model to a task where the observer must decide which of two intervals is most simultaneous)
"help TwoAFCSimultaneity_2PEq_Multistart_rawdata" (as above, except that data are not broken down to fit an interval bias, so uses only two parameters)

Note that the files in the Derivest suite and F programs folders where written by other people and obtained from Matlab Central.

References:

Yarrow, K., Jahn, N., Durant, S., & Arnold, D.H. Shifts of criteria or neural timing? The assumptions underlying timing perception studies. Consciousness & Cognition, 20, 1518-31 (2011). 

Yarrow, K., Martin, S.E., Di Costa, S., Solomon, J.A., & Arnold, D.H. A roving dual-presentation simultaneity-judgment task to estimate the point of subjective simultaneity. Frontiers in Psychology, 7:416. (2016).

Yarrow, K. Collecting and Interpreting Judgments about Perceived Simultaneity: A Model-Fitting Tutorial. In A. Vatakis, F. Balci, M. Di Luca, �. Correa (Eds.) Timing and Time Perception: Procedures, Measures, and Applications. Leiden: Brill (2018).

