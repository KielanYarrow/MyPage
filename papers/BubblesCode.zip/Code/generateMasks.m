function framesSpatioTemporaltemp = generateMasks(tempIndices,tempExtent,tempMask)

framesSpatioTemporaltemp = zeros(size(tempExtent,2),size(tempMask,1), size(tempMask,2));
for i = tempIndices(1) : tempIndices(end)
    framesSpatioTemporaltemp(i,:,:) = tempExtent(i)*tempMask; 
end

return;
