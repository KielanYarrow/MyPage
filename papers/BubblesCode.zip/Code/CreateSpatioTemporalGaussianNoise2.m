
function [VidNoised, finalMasks] = CreateSpatioTemporalGaussianNoise(movieIn, numGaussianCenters, varianceMean ,SorR, DetectedObjects,startPoint, framesRange, maskFrameDuration)
%framesRange should either be empty or if it has a value should be like: [12,13,14,15,45,46,47,...]
widthAroundMotion = 5;% the range around the detected objects by motion tracking to consider for bubbles center
numFramesClearVideo = 25;
stdTemporal = 5;
if SorR =='S'
    startX = 180 - varianceMean;%261; HEIGHT
    endX = 420 + varianceMean;%460;
    startY = 380 - varianceMean;%391; WIDTH
    endY = 700 + varianceMean;%640;
else% For Returns
    startX = 240 - varianceMean;%261;
    endX = 440 +  varianceMean;%460;
    startY = 320 - varianceMean ;%391;
    endY = 760 + varianceMean;%640;
end
finalVid = movieIn;
clear movieIn;
%rng('shuffle');
BubbleExtend = 6 * varianceMean;  % bubble size

movie = finalVid(startX:endX,startY:endY,:); % DEFINING THE MEANINGFUL PART OF THE VIDEO
if nargin < 7
    framesRange = (1:size(movie,3));
end
if nargin < 8
    maskFrameDuration = 31; % the extension of temporal mask
end
%**************
%tic
VidFinalMotions = zeros(size(finalVid));
MotionFrames = zeros(1,size(finalVid,3));
%tic
for i = 1 : size(finalVid,3)
    frame = VidFinalMotions(:,:,i);
    temp = DetectedObjects{startPoint+i};
    tempBoxes = temp.boxes;
    if tempBoxes
        for j = 1 : size(tempBoxes,1)
            tempBoxestemp = tempBoxes(j,:);
            if ( tempBoxestemp(1) + tempBoxestemp(3) + widthAroundMotion > 1280)
                tempBoxestemp(1) = 1280 - tempBoxestemp(3) - widthAroundMotion;
            end
            if ( tempBoxestemp(1) - widthAroundMotion < 1)
                tempBoxestemp(1) =  widthAroundMotion + 1;
            end
            if (tempBoxestemp(2) + tempBoxestemp(4) + widthAroundMotion > 720)
                tempBoxestemp(2) = 720 - tempBoxestemp(4) - widthAroundMotion;
            end
            if (tempBoxestemp(2) - widthAroundMotion < 1)
                tempBoxestemp(2) = widthAroundMotion + 1;
            end
            frame(tempBoxestemp(2) - widthAroundMotion :tempBoxestemp(2)+tempBoxestemp(4) + widthAroundMotion, tempBoxestemp(1) - widthAroundMotion :tempBoxestemp(1) + tempBoxestemp(3) + widthAroundMotion) = 1;
        end
        if tempBoxestemp(1)  > startY && tempBoxestemp(1) < endY && tempBoxestemp(2) > startX && tempBoxestemp(2)  < endX
            MotionFrames(1,i) = 1;
        end
    end
    VidFinalMotions(:,:,i) = frame;
    clear frame;
end
%time1 = toc % ~ 0.6s
%tic
movieNoised = zeros(size(movie,1),size(movie,2),size(movie,3));
tempVid = single(movie);
vHeight = size(movie,1);
vWidth = size(movie,2);
vFrames = size(movie,3); % if ColorVideo, change to 4
if numel(framesRange) < size(movie,3)
    index = 1;
    for i = 1 : size(framesRange,2)
        for j = 1: numel(MotionFrames)
            if framesRange(i) == MotionFrames(j)
                NewMotionRange(index) = framesRange(i);
                break;
            end
        end
    end
    clear MotionFrames
    MotionFrames = NewMotionRange;
end

[tempRand, tempRandIndex] = find(MotionFrames);
%time2 = toc % ~ 0.09s
%tic
for i = 1 : numel(tempRandIndex)
%*******% having this if, helps having full bubble profiles. Commenting it
%results in as small as half length temporal bubbles
%     if tempRandIndex(i) > vFrames-ceil(maskFrameDuration/2) 
%         isValidRange = 1;
%         while isValidRange
%             %tempRandIndex(i) = randi([ceil(maskFrameDuration/2), vFrames-ceil(maskFrameDuration/2)]);
%             tempRandIndex(i) = randi([numFramesClearVideo+ floor(maskFrameDuration/2), vFrames-ceil(maskFrameDuration/2)]);
%             if  MotionFrames(tempRandIndex(i))
%                 isValidRange = 0;
%             end
%         end
%     end
%*****
    if tempRandIndex(i) < numFramesClearVideo + ceil(maskFrameDuration/2) -1
        isValidRange = 1;
        while isValidRange
            %tempRandIndex(i) = randi([ceil(maskFrameDuration/2), vFrames-ceil(maskFrameDuration/2)]);
            tempRandIndex(i) = randi([numFramesClearVideo + floor(maskFrameDuration/2), vFrames-ceil(maskFrameDuration/2)]);
            
            if  MotionFrames(tempRandIndex(i))
                isValidRange = 0;
            end
        end
    end
end
tempRandNum = randperm(numel(tempRandIndex));
%for  j = 1 : numGaussianCenters
masksTemporalRange(1:numGaussianCenters) = tempRandIndex(tempRandNum(1:numGaussianCenters));
%end
masksTemporalExtent = zeros(numGaussianCenters,vFrames);
x = [1:1:maskFrameDuration];
norm = normpdf(x,round(maskFrameDuration/2),stdTemporal); % the third parameter is the variance
norm = (norm - min(norm) ) / (max(norm) - min(norm));
% if no popping effect is needed, simply put norm = ones(1,maskFrameDuration);
for i = 1 : numGaussianCenters
    tempmasksTemporalExtent = zeros(1,vFrames);
    %***% having this if, helps with having half temporal profiles 
    if masksTemporalRange(i) > vFrames-ceil(maskFrameDuration/2) 
        sizetoEnd = vFrames - masksTemporalRange(i);
        maskSizeTemporaltemp = ceil(maskFrameDuration/2) + sizetoEnd;
        tempmasksTemporalExtent(masksTemporalRange(i)- floor(maskFrameDuration/2) : masksTemporalRange(i) + sizetoEnd) = norm(1:maskSizeTemporaltemp);
    else
        tempmasksTemporalExtent(masksTemporalRange(i)- floor(maskFrameDuration/2) : masksTemporalRange(i) + ceil(maskFrameDuration/2) - 1) = norm;
    end
    %***
    %tempmasksTemporalExtent(masksTemporalRange(i)- floor(maskFrameDuration/2) : masksTemporalRange(i) + ceil(maskFrameDuration/2) - 1) = norm;
    masksTemporalExtent(i,:) = tempmasksTemporalExtent;
end
%time3 = toc %~ 0.002s
%tic
%rng('shuffle');
%******************
%******************
BubbleExtendHalf = BubbleExtend/2;
%tic
for i = 1 : numGaussianCenters
    frame = reshape(VidFinalMotions(:,:,masksTemporalRange(i)),size(VidFinalMotions,1),size(VidFinalMotions,2));
    temp = DetectedObjects{startPoint+masksTemporalRange(i)};
    tempBoxes = temp.boxes;
    j = randi([1 , size(tempBoxes,1)]);
    tempBoxestemp = tempBoxes(j,:);
    meansHRand = randi([tempBoxestemp(2), tempBoxestemp(2) + tempBoxestemp(4)]) - startX;
    meansWRand = randi([tempBoxestemp(1), tempBoxestemp(1) + tempBoxestemp(3)]) - startY;
    meanRand(i,1) = meansHRand;
    meanRand(i,2) = meansWRand;
end

% Create the mask
%tic
hMask = fspecial('gaussian',[BubbleExtend BubbleExtend],varianceMean);
hMask = (hMask - min(min(hMask))) / (max(max(hMask)) - min(min(hMask)));

framesSpatioTemporalFinal2 = cell(1,numGaussianCenters);

bighMask = zeros(size(norm,2),size(hMask,1),size(hMask,2));
for i = 1 : size(norm,2)
    bighMask(i,:,:) = hMask * norm(i);
end

%tic
for k = 1 : numGaussianCenters
    %tempMask = reshape(tempMasks(k,:,:),size(tempMasks,2),size(tempMasks,3));
    %tempMask = tempMasks{k};
    %tempMask(:,:) = tempMasks(k,:,:);
    tempExtent = masksTemporalExtent(k,:);
    [tempVals, tempIndices] = find(tempExtent);
    
    centerpoint = meanRand(k,:);
    maskStartX = centerpoint(1) - BubbleExtendHalf + 1;
    maskEndX = centerpoint(1) + BubbleExtendHalf;
    maskStartY = centerpoint(2) - BubbleExtendHalf + 1;
    maskEndY = centerpoint(2) + BubbleExtendHalf;
    
    % the reason it is 1* 19 is -1 and +1 are zero. it is ok and 21.
    
    %framesSpatioTemporaltemp = generateMasksOriginal(tempIndices,tempExtent,tempMask,bighMask,maskStartX,maskEndX,maskStartY,maskEndY);
    framesSpatioTemporaltemp = zeros(size(tempExtent,2),vHeight+BubbleExtend,vWidth+BubbleExtend);
    for i = tempIndices(1) : tempIndices(end)
        temphMask(:,:) = bighMask(i - tempIndices(1) +2,:,:);
        framesSpatioTemporaltemp(i,maskStartX:maskEndX,maskStartY:maskEndY) = temphMask;
    end
    
    framesSpatioTemporalFinal2{k} = framesSpatioTemporaltemp;
    
    %clear tempMask;
end


%timeLoop = toc
%tic
clear tempMasks framesSpatioTemporaltemp;

finalMasks = zeros(vHeight+ BubbleExtend,vWidth+ BubbleExtend,vFrames);

for i = 1 : vFrames
    tempMasksSpatioTemporal = zeros(vHeight+BubbleExtend,vWidth+BubbleExtend);
    anyValsTemp = masksTemporalExtent(:,i);
    anyVals = sum(anyValsTemp);
    if anyVals > 0
        [indexValid, numValid] = find(anyValsTemp);
        for k = 1 : sum(numValid)
            tempframesSpatioT = framesSpatioTemporalFinal2{indexValid(k)};
            tempMasksSpatioTemporal = tempMasksSpatioTemporal + reshape(tempframesSpatioT(i,:,:),vHeight+BubbleExtend,vWidth+BubbleExtend);
            %tempMasksSpatioTemporal = tempMasksSpatioTemporal + reshape(framesSpatioTemporalFinal(indexValid(k),i,:,:),vHeight+BubbleExtend,vWidth+BubbleExtend);
        end
        maxtempMasksST = max(max(tempMasksSpatioTemporal));
        mintempMasksST = min(min(tempMasksSpatioTemporal));
        if (maxtempMasksST > mintempMasksST)
            tempMasksSpatioTemporal = (tempMasksSpatioTemporal - mintempMasksST) / (maxtempMasksST - mintempMasksST);
        end
        % normalised to zero and 1
    end
    finalMasks(:,:,i) = tempMasksSpatioTemporal;%reshape(tempMasksSpatioTemporal,1,vHeight,vWidth);
    clear tempMasksSpatioTemporal;
end
clear framesSpatioTemporalFinal;
%time5 = toc
%tic;
%movie2 =
tempVid2 = single(finalVid(startX-BubbleExtendHalf:endX+BubbleExtendHalf,startY-BubbleExtendHalf:endY+BubbleExtendHalf,:)); % DEFINING THE MEANINGFUL PART OF THE VIDEO);
%clear movie2;
%finalMask = zeros(vHeight+BubbleExtend,vWidth+BubbleExtend);
for i = 1 : numFramesClearVideo -1
    finalVid(startX-BubbleExtendHalf:endX+BubbleExtendHalf,startY-BubbleExtendHalf:endY+BubbleExtendHalf,i) = tempVid2(:,:,i);
end
for i = numFramesClearVideo : vFrames
    tempFrame = tempVid2(:,:,i);
    meanTempFrame = mean(mean(tempFrame));
    tempFramDeducted = tempFrame - meanTempFrame;
    finalMask = reshape(finalMasks(:,:,i),vHeight+BubbleExtend,vWidth+BubbleExtend);
    %finalMask(:,:) = finalMasks(i,:,:);
    tempFrame = (tempFramDeducted .* finalMask) + meanTempFrame;
    finalVid(:,:,i) = meanTempFrame;
    finalVid(startX-BubbleExtendHalf:endX+BubbleExtendHalf,startY-BubbleExtendHalf:endY+BubbleExtendHalf,i) = tempFrame;
    clear tempFrame;
end
VidNoised = uint8(finalVid);
clear finalMask  finalVid tempVid2;
%time6 = toc;
return;