function [score, reactionTime] = PracticeTemporal(ServiceOrReturn, ExperimentName,Initialization)
% this is the main Practice File
% We will use a set of videos for Services and Returns respectively.
% in this stage, there will be no bubbles added to reduce visibility.
% the goal is they respond as fast as possible to get 90% accuracy. for a
% start 300ms after bc. every time they manage to respond inside the deadline and get it right,
% we lower the deadline (the step size is something we will want to mess around with during piloting,
% but 10 ms seems a reasonable value to try first). On the other hand, every time they miss the deadline
% or get it wrong, we raise the deadline
% here are some initializations:
%format long;
timeThresholdHalfRange = 0.15;
%initialisations for data acquisition using pedals
d = daq.getDevices;
if isempty(d)
    UsePedals = 0;
else
    UsePedals = 1;
end

if UsePedals == 1
    daq.reset
    s = daq.createSession('ni');
    s.addAnalogInputChannel('dev1',0:1,'Voltage'); %use 0:1 for two channel, etc.
    s.Rate = 100000;
    %s.DurationInSeconds = 5;
    s.NotifyWhenDataAvailableExceeds = 2 .* round(Initialization.monitorFlipInterval.*s.Rate); %1667;
    s.IsContinuous = true;
    
    lh = s.addlistener('DataAvailable',@plotInline);
    prepare(s);
    
    absolutePedalStart = 0;
    pedalTime = 0;
    transferTimes = zeros(100000,1);
    transfercounter = 0;
    
end
pedalsInput = ones(1,2);


% end DAQ initialisation

reactionTimeOK = 'N'; % This is to repeat the trial in case the reaction time calculated by psignifit is not fine
reactionTimeOKCounter = 0; % to save the number of times the trial is repeated
numTrials = Initialization.numTrialsPractice;
timeThreshold = Initialization.timeThreshold;
numFramesBeforeBC = Initialization.numFramesBeforeBC;
numFramesAfterBC = Initialization.numFramesAfterBC;
monitorFlipInterval = Initialization.monitorFlipInterval;
FrameRate = Initialization.FrameRate;
esc = Initialization.esc;
right = Initialization.right;
left = Initialization.left;
theParticipantName = Initialization.theParticipantName;
contactPointsNames = Initialization.contactPointsNamesPractice; %Cell
wPtr = Initialization.wPtr;
ResultsPractice = Initialization.ResultsPractice; %Cell
PriorityMax = Initialization.PriorityMax;
Blue = Initialization.Blue;
Red = Initialization.Red;
Green = Initialization.Green;
White = Initialization.White;
Black = Initialization.Black;
Gray = Initialization.Gray;
PracticePlayerIndex = Initialization.PracticePlayerIndex;
practicePlayerPercentage = Initialization.practicePlayerPercentage;
%BetaValue = Initialization.BetaValue; %1
BetaValue = 7.5;
DeltaValue = 0.01;
%QuestCreateNormal(tGuess,tGuessSd,pThreshold,beta,delta,gamma,[grain],[range])

%qQuest = QuestCreateNormal(log(10),5,(3 - DeltaValue) / 4,BetaValue,DeltaValue,0.5,0.1,4);
qQuest = QuestCreateNormal(0.4,0.5,0.9,BetaValue,DeltaValue,0.5,0.01,1);

%contactPointsNames = contactPointsNameSelect.contactPointsNames;
%ResultsPractice = ResultsPractice.ResultsPractice;
%reactionTimeDataAll = []; % for storing all the values of reaction times in case of invalid pfit outputs
if (ServiceOrReturn == 'S' || ServiceOrReturn == 's')
    PracticeMode = 'Services';
else
    PracticeMode = 'Returns';
end
%theParticipantName = input('Please enter your name: ', 's');
DrawFormattedText(wPtr, ['Hi ' theParticipantName '! \n\n Welcome to the practice step of the experiment! \n\n You will be shown ' num2str(numTrials) ' clear videos of ' PracticeMode '. \n\n AS FAST AS YOU CAN, \n\n\nStep off the LEFT PEDAL if you think the shot is LINE (towards your left side) or  \n\n Step off the RIGHT PEDAL if you think it is a CROSS shot (towards your right side). \n\n\n Each time you answer correctly in the time limit (' num2str(timeThreshold*1000) ' Milliseconds to start with)\n\n , you gain 10 points. If you answer wrong in the time limit, you gain 2 points.\n\n If you answer correctly/wrong out of the time limit, you lose 5 points. \n\n\n  Try to maximize your score!!!! \n\n\n Press any key when you are ready! '], 'center', 150, 0);
Screen(wPtr, 'Flip');
KbStrokeWait;
% first find the Services / Returns :
% then find the player 4 for training:
while (reactionTimeOK ~= 'Y')
    practiceshots = zeros(1,size(contactPointsNames,2));
    trainingIndex = zeros(1,size(contactPointsNames,2));
    score = 0; % a score to encourage the participants for better responses.
    for i = 1 : size(contactPointsNames,2)
        temp = contactPointsNames{i};
        if (temp.filename(1) == ServiceOrReturn) % finding the service/return shots
            practiceshots(i) = 1;
            %            trainingIndex(i) = 1;
            if (temp.playerName == PracticePlayerIndex) % finding the player for training set
                trainingIndex(i) = 1;
            end
        end
    end
    clear temp ;
    indices = find(trainingIndex); % Indices saves the indecis of Player B Serving.
    % then show the videos for each participant. Record their response time and use a staircase to adjust their responses.
    % Find the 90% accuracy speed threshold for each participant.
    % punish them if they are slow and encourage them to be faster.
    rng('shuffle');
    numTrialsPracticePlayer = floor(numTrials*practicePlayerPercentage);
    trialRepeat = zeros(1,numTrialsPracticePlayer);
    randNums = randperm(size(indices,2)); % Create the indices in random order
    BBKron = ones(1,int8(floor(numTrialsPracticePlayer/size(randNums,2))));
    trialRepeatTemp = kron(randNums,BBKron); % Expand the matrix to the size needed
    leftOver = size(trialRepeat,2) - size(trialRepeatTemp,2);
    trialRepeat(1:size(trialRepeatTemp,2)) = trialRepeatTemp;
    trialRepeat(size(trialRepeatTemp,2)+1:size(trialRepeatTemp,2)+leftOver) = randperm(size(indices,2),leftOver);
    idx = randperm(length(trialRepeat));
    xperm = trialRepeat(idx);
    
    numTrialsRestofPlayers = numTrials - numTrialsPracticePlayer;
    indices2 = find(practiceshots);
    indices3 = indices2(size(indices,2) + 1 :end);
    trialRepeat = zeros(1,numTrialsRestofPlayers);
    randNums = randperm(size(indices3,2)); % Create the indices in random order
    BBKron = ones(1,int8(floor(numTrialsRestofPlayers/size(randNums,2))));
    trialRepeatTemp = kron(randNums,BBKron); % Expand the matrix to the size needed
    leftOver = size(trialRepeat,2) - size(trialRepeatTemp,2);
    trialRepeat(1:size(trialRepeatTemp,2)) = trialRepeatTemp;
    trialRepeat(size(trialRepeatTemp,2)+1:size(trialRepeatTemp,2)+leftOver) = randperm(size(indices3,2),leftOver);
    idx = randperm(length(trialRepeat));
    xperm2 = trialRepeat(idx) + size(indices,2);
    
    indices = [indices indices3];
    trialRepeatFinal = [xperm xperm2];
    idx = randperm(length(trialRepeatFinal));
    trialRepeatFinal = trialRepeatFinal(idx);
    numMissedFrame = 0;
    %trialRepeatFinal = ceil(randperm(numTrials) / size(indices,2)); This works
    %only with predefined numbers i.e. fixed numebr of trials, etc.
    missedFrameIndex = zeros(numFramesBeforeBC + numFramesAfterBC + 1,1);
    droppedIndicestoRepeat = 1;
    trialsWithDroppedFrames = zeros(numTrials,1);
    
    QuestCounterUpdated = 0;
    timeThreshold = QuestQuantile(qQuest);
    if (timeThreshold < 0.4 || timeThreshold > 0.6)
        timeThreshold  = 0.6;
    end
    
    for trialIndex = 1 : numTrials % Number of trials
        index = indices(trialRepeatFinal(trialIndex));
        temp = contactPointsNames{index};
        videoName = temp.filename; % find the video name
        VideoContactPoint = temp.Frame; % find the ball contact point frame
        VideoDirection = temp.filename(3); % find the direction of the serv L for Line, C for Cross
        if (ispc)
            videoName = strcat('C:\TennisVideosGray\',videoName,'Gray.mat');
            savePath = 'C:\TennisVideosGray\Results\Practice\';
        else
            videoName = strcat('/Users/sepehr/Desktop/TennisVideosGray/',videoName,'Gray.mat');
            savePath = '/Users/sepehr/Desktop/TennisVideosGray/Results/Practice/';
        end
        load(videoName); % the structure name is Vid
        nFrames = size(Vid,3);
        nHeight = size(Vid,1);
        nWidth = size(Vid,2);
        TrialResults = struct;
        VidResized = Vid(161:560,241:840,:); % to adjust to the screen size resolution
        clear Vid;
        j = VideoContactPoint - numFramesBeforeBC; % 800ms/96 frames before Ball Contact point.
        if( j < 1)
            j =1;
        end
        abortit = 0;
        responseFrameFlag = 0; % for saving responding frame
        matrixtemp = zeros(numFramesBeforeBC + numFramesAfterBC,1);
        matrixtempIndex = VideoContactPoint - numFramesBeforeBC;
        
        %NOTE FROM KIELAN Psychtoolbox was complaining about leftover
        %offscreen windows or textures, so I've added a line here to clean
        %these up before creating each new set
        Screen('Close');
        
        for kkkk = j : VideoContactPoint + numFramesAfterBC
            textureIndex(kkkk) =Screen('MakeTexture', wPtr, VidResized(:,:,kkkk)); %
        end
        if (VideoContactPoint + numFramesAfterBC + 1 > nFrames)
            textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, VidResized(:,:,kkkk)); %
        else
            textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, VidResized(:,:,kkkk+1)); %
        end
        
        %Another section of code relating to the DAQ
        if UsePedals == 1
            alreadyRT = false;
            s.startBackground();
        end
        pedalsInput = ones(1,2); % assumes feet are back on the pedals
        %end DAQ section
        
        try
            Priority(PriorityMax);
            vbltime = Screen('Flip', wPtr);
            PlaybackStart = GetSecs;
            Screen('DrawTexture', wPtr, textureIndex(j));
            while (abortit<1)
                vbltime = Screen('Flip', wPtr, vbltime+(0.5* monitorFlipInterval),2);
                [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
                matrixtemp(j - matrixtempIndex +1) = vbltime;
                Screen('DrawTexture', wPtr, textureIndex(j+1));
                if (j ==  VideoContactPoint)
                    contactTimeFlag = GetSecs;
                    
                    %Another section of code relating to the DAQ
                    if UsePedals == 1
                        timeZero = now;
                    end
                    %end DAQ section
                    
                end
                if (keyIsDown==1 && keyCode(esc))
                    abortit=3; % ESC key is pressed
                    break;
                end;
                %NEXT LINE MODIFIED TO WORK WITH DAQ
                if (((keyIsDown==1 && keyCode(right)) || ((pedalsInput(2) == 0) && (pedalsInput(1) == 1))))
                    responseTimeflag = GetSecs;
                    responseDirection = 'C';
                    responseFrameFlag = responseFrameFlag+j;
                    if (j < VideoContactPoint)
                        jtemp = j;
                        for k = jtemp :VideoContactPoint
                            vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                            if (j+1==VideoContactPoint)
                                contactTimeFlag = GetSecs;
                                
                                %Another section of code relating to the DAQ
                                if UsePedals == 1
                                    timeZero = now;
                                end
                                %end DAQ section
                                
                            end
                            Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                            matrixtemp(j - (VideoContactPoint - numFramesBeforeBC) +1) = vbltime;
                            j = j+1;
                        end
                    end
                    abortit = 1; % RIGHT Arrow Key is Pressed
                end;
                %NEXT LINE MODIFIED TO WORK WITH DAQ
                if (((keyIsDown==1 && keyCode(left)) || ((pedalsInput(1) == 0) && (pedalsInput(2) == 1)) ))
                    responseTimeflag = GetSecs;
                    responseDirection = 'L';
                    responseFrameFlag = responseFrameFlag+j;
                    if (j < VideoContactPoint)
                        jtemp = j;
                        for k = jtemp :VideoContactPoint
                            vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                            if (j+1==VideoContactPoint)
                                contactTimeFlag = GetSecs;
                                
                                %Another section of code relating to the DAQ
                                if UsePedals == 1
                                    timeZero = now;
                                end
                                %end DAQ section
                                
                            end
                            Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                            matrixtemp(j - (VideoContactPoint - numFramesBeforeBC) +1) = vbltime;
                            j = j+1;
                        end
                    end
                    abortit = 2; % LEFT Arrow Key is Pressed
                end;
                if (j < (VideoContactPoint + numFramesAfterBC)) % to show up to 24 frames after ball contact
                    j = j+1;
                    
                    %NOTE FROM KIELAN
                    %next line was incrementing this after the response by
                    %mistake, which was what was causing our > 120 fps
                    %reports when responses came after video. Have fixed.
                    
                    %else
                elseif (abortit == 0) %no response yet
                    responseFrameFlag = responseFrameFlag + 1;
                end
            end;
            Priority(0);
            %Screen('Close',wPtr2);
            
            if (abortit ==3)
                break;
            end
            vblstimes = diff(matrixtemp); % confirm it works when response is before contact
            endofvblstimes = j - (VideoContactPoint - numFramesBeforeBC);
            if (endofvblstimes > 0)
                vblstimes(endofvblstimes:end) = 0;
            end
            missedFramesIndices = find(vblstimes> 1.5* monitorFlipInterval) + 1;
            numMissedFrames = numel(missedFramesIndices);
            numCriticalMissedFrames = sum(missedFramesIndices > 72);
            
            responseTime = responseTimeflag - contactTimeFlag;
            responseFrame = responseFrameFlag - VideoContactPoint;
            
            %NOTE FROM KIELAN: I've modified this bit!
            responseTimeBinned = round(responseTime * FrameRate) / FrameRate;
            displayedFrameRate = responseFrame / responseTimeBinned;
            
            %Another section of code relating to the DAQ
            if UsePedals == 1
                FrameRT(trialIndex) = responseTime;
                if (sum(pedalsInput) < 2) %pedal response made on this trial
                    responseTime = pedalTime - ((timeZero - absolutePedalStart).*24.*60.*60);
                end
                AcRT(trialIndex) = responseTime;
            end
            %end DAQ
            
            if (responseTimeBinned == 0)
                displayedFrameRate = FrameRate;
            end
            if (responseTime > timeThreshold + timeThresholdHalfRange || responseTime < timeThreshold - timeThresholdHalfRange )
                respondWithinTimeLine = 0;
                if (responseDirection == VideoDirection)
                    score = score -5;
                else
                    score = score -5;
                end
            else
                respondWithinTimeLine = 1;
                if (responseDirection == VideoDirection)
                    score = score +10;
                else
                    score = score + 2;
                end
            end
            if (responseDirection == VideoDirection)
                directionCorrect = 1; % if the direction is correct
            else
                directionCorrect = 0;
            end
            Screen(wPtr, 'Flip');
            %save the response:
            TrialResults.directionCorrect = directionCorrect;  % This saves the results from this trial.
            TrialResults.respondWithinTimeLine = respondWithinTimeLine;
            TrialResults.responseTimeBinned =responseTimeBinned;
            TrialResults.responseTime = responseTime;
            TrialResults.respondFrame = responseFrame;
            TrialResults.directionReal = VideoDirection;
            TrialResults.ballContactFrame = VideoContactPoint;
            TrialResults.Type = ServiceOrReturn;
            TrialResults.VideoName = videoName;
            TrialResults.Threshold = timeThreshold;
            TrialResults.score = score;
            TrialResults.missedFramesIndices = missedFramesIndices;
            TrialResults.numMissedFrames = numMissedFrames;
            TrialResults.numCriticalMissedFrames = numCriticalMissedFrames;
            TrialResults.displayedFrameRate = displayedFrameRate;
            
            ResultsPractice{trialIndex} = TrialResults;
            if (numCriticalMissedFrames > 0)
                trialsWithDroppedFrames(droppedIndicestoRepeat) = trialIndex;
                droppedIndicestoRepeat = droppedIndicestoRepeat + 1;
            end
            %analyse the response: Use a staircase to optimize the time pressure
            if trialIndex > 5
                if (responseTime < timeThreshold + timeThresholdHalfRange && responseTime > timeThreshold - timeThresholdHalfRange)
                    QuestCounterUpdated = QuestCounterUpdated + 1;
                    if (directionCorrect)
                        qQuest = QuestUpdate(qQuest,timeThreshold,1);
                        %
                        %                 gaussianCounter = gaussianCounter +1;
                        %                 if (gaussianCounter >2)
                        %                     numGaussianCenters = numGaussianCenters - 1; % deduct 1
                        %                     gaussianCounter = 0;
                        %                 end
                    else  %
                        %numGaussianCenters = numGaussianCenters + 1;  % add 1
                        qQuest = QuestUpdate(qQuest,timeThreshold,0);
                    end
                    %else %make modifications ONLY if they have responded in time
                    %NumGaussianCenters = NumGaussianCenters + 3;  % add 3
                end
            end
            
            %             if (directionCorrect)
            %                 if (respondWithinTimeLine)
            %                     timeThreshold = timeThreshold - 0.01;  % deduct 10ms
            %                 else
            %                     timeThreshold = timeThreshold + 0.01;  % add 30 ms
            %                 end
            %             else
            %                 timeThreshold = timeThreshold + 0.01;  % add 30 ms
            %             end
            
            timeThreshold = QuestQuantile(qQuest);
            
            if (timeThreshold < 0.001 && timeThreshold > -0.001 )
                timeThreshold = 0;
            end
            if (responseDirection == 'L')
                responseText = 'Line';
            else
                responseText = 'Cross';
            end
            if (responseDirection == VideoDirection)
                responseText = strcat(responseText,' Correctly');
            else
                responseText = strcat(responseText,' Incorrectly');
            end
            
            if (trialIndex < numTrials-1)
                DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                Screen('TextSize', wPtr, 20);
                DrawFormattedText(wPtr, ['\n\n Step back on both pedals \n\n to go for trial ' num2str(trialIndex +1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
                Screen('TextSize', wPtr, 15);
                Screen(wPtr, 'Flip',[],1);
                %             WaitSecs(0.3); % REMOVE THESE???????????*****************
                %             KbStrokeWait;
            else
                if (trialIndex == numTrials)
                    DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                    Screen('TextSize', wPtr, 20);
                    DrawFormattedText(wPtr, '\n\n Step back on both pedals to continue', 'center', 670, 0);
                    Screen('TextSize', wPtr, 15);
                    Screen(wPtr, 'Flip',[],1);
                    %                 WaitSecs(0.3);
                    %                 KbStrokeWait;
                else
                    DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                    Screen('TextSize', wPtr, 20);
                    DrawFormattedText(wPtr, ['\n\n Step back on both pedals \n\n to go for trial ' num2str(trialIndex +1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
                    Screen('TextSize', wPtr, 15);
                    Screen(wPtr, 'Flip',[],1);
                    %                 WaitSecs(0.3);
                    %                 KbStrokeWait;
                end
            end
            
            %NOTE FROM KIELAN: In the next section, I've modified it to
            % display
            %response time rather than response time binned, which will be
            %more accurate when in pedals mode
            
            Screen('TextSize', wPtr, 25);
            if (responseTime > timeThreshold + timeThresholdHalfRange)
                if (responseDirection == VideoDirection)
                    %Screen('TextColor', wPtr, [255 0 0]);
                    DrawFormattedText(wPtr,'You took too long but answered correctly!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 30);
                    DrawFormattedText(wPtr,'ACCURATE, ', 'center', 430, Blue);
                    DrawFormattedText(wPtr,['BUT SLOW!!! BE FASTER!!!\n\n Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'], 'center', 465, Red);
                    Screen('TextSize', wPtr, 25);
                    Screen(wPtr, 'Flip');
                    
                    %NOTE FROM KIELAN: TOOK NEXT COUPLE OF LINES OUT OF
                    %BRANCHING STRUCTURE AS THEY APPEAR IN ALL BRANCHES
                    
                    %WaitSecs(0.15);
                    %KbStrokeWait;
                    
                    %Screen('TextColor', wPtr, [0 0 0]);
                else
                    %Screen('TextColor', wPtr, [255 0 0]);
                    DrawFormattedText(wPtr,'You took too long and were wrong!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 30);
                    DrawFormattedText(wPtr,['SLOW AND INACCURATE!!! \n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'] , 'center', 430, Red);
                    Screen('TextSize', wPtr, 25);
                    Screen(wPtr, 'Flip');
                    %WaitSecs(0.15);
                    %KbStrokeWait;
                    %Screen('TextColor', wPtr, [0 0 0]);
                end
            else
                if (responseTime < timeThreshold - timeThresholdHalfRange)
                    if (responseDirection == VideoDirection)
                        DrawFormattedText(wPtr,'Too Fast!!! You answered correctly under the time limit!\n\n You get 2 points!', 'center', 150, Red);
                        DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                        Screen('TextSize', wPtr, 35);
                        DrawFormattedText(wPtr,['TOO FAST BUT ACCURATE! Slow Down! \n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'] , 'center', 430, Blue);
                        Screen('TextSize', wPtr, 25);
                        Screen(wPtr, 'Flip');
                        %WaitSecs(0.15);
                        %KbStrokeWait;
                    else
                        DrawFormattedText(wPtr,'You answered wrong under the time limit! \n\n You get 2 points! ', 'center', 150, Red);
                        DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                        Screen('TextSize', wPtr, 35);
                        DrawFormattedText(wPtr,['TOO FAST! Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'], 'center', 430, Red);
                        DrawFormattedText(wPtr,'AND INACCURATE!!! BE MORE PRECISE!!!', 'center', 540, Red);
                        Screen('TextSize', wPtr, 25);
                        Screen(wPtr, 'Flip');
                        %WaitSecs(0.15);
                        %KbStrokeWait;
                    end
                else
                    if (responseDirection == VideoDirection)
                        DrawFormattedText(wPtr,'Well done!!! You answered correctly in the time limit!\n\n You get 10 points!', 'center', 150, Blue);
                        DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                        Screen('TextSize', wPtr, 35);
                        DrawFormattedText(wPtr,['FAST AND ACCURATE!!! WELL DONE!!!\n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'] , 'center', 430, Green);
                        Screen('TextSize', wPtr, 25);
                        Screen(wPtr, 'Flip');
                        %WaitSecs(0.15);
                        %KbStrokeWait;
                    else
                        DrawFormattedText(wPtr,'You answered wrong in the time limit! \n\n You get 2 points! ', 'center', 150, Red);
                        DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                        Screen('TextSize', wPtr, 35);
                        DrawFormattedText(wPtr,['FAST ENOUGH! Your Time: '  num2str(round(responseTime*1000),5) ', \n\n New Time Range: [' num2str(round((timeThreshold - timeThresholdHalfRange)*1000)) ' : ' num2str(round((timeThreshold + timeThresholdHalfRange)*1000)) '] Milliseconds.'], 'center', 430, Blue);
                        DrawFormattedText(wPtr,'BUT INACCURATE!!! BE MORE PRECISE!!!', 'center', 540, Red);
                        Screen('TextSize', wPtr, 25);
                        Screen(wPtr, 'Flip');
                        %WaitSecs(0.15);
                        %KbStrokeWait;
                    end
                end
            end
            
            %NOTE FROM KIELAN: put them back here, but modified to work in
            %collaboration with pedals if needed
            
            DontMoveOn = 1;
            
            while DontMoveOn == 1
                
                pause(0.1);
                
                [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
                
                if (keyIsDown==1)
                    DontMoveOn = 0;
                end;
                
                if UsePedals == 1
                    if (sum(pedalsInput) == 2) %both pedals down
                        DontMoveOn = 0;
                    end
                end
                
            end
            
            
            %DAQ stuff
            if UsePedals == 1
                s.stop();
            end
            %end of daq stuff
            
            Screen('TextSize', wPtr, 15);
            clear textureIndex PlaybackStart responseTimeflag temp videoName VideoContactPoint VideoDirection VidResized TrialResults textureIndex matrixtemp missedFramesIndices ;
        catch
            savePath = strcat(savePath,ExperimentName,num2str(reactionTimeOKCounter),'ERROR.mat');
            save(savePath,'ResultsPractice');
            Screen('Flip', wPtr);
            DrawFormattedText(wPtr,'Experiment Aborted due to unknown technical error(s)... \n\nTried to save... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, 0, Red);
            Screen(wPtr, 'Flip');
            KbStrokeWait;
            Screen('CloseAll');
        end
        if (abortit ==3)
            if UsePedals == 1
                s.stop();
            end
            break;
            
        end
    end
    %************************************ to redo the dropped frames
    %************************************ to redo the dropped frames
    %************************************ to redo the dropped frames
    %************************************ to redo the dropped frames
    numTrialsToRepeat = size(find(trialsWithDroppedFrames),1);
    %     if (numTrialsToRepeat > 0 && abortit ~=3)
    if (abortit ~=3)
        savePath = strcat(savePath,ExperimentName,num2str(reactionTimeOKCounter),'.mat');
        save(savePath,'ResultsPractice');
        reactionTime = QuestMean(qQuest) + timeThresholdHalfRange;
        Screen(wPtr, 'Flip');
        DrawFormattedText(wPtr, ['There has been ' num2str(numTrialsToRepeat) ' trial(s) with dropped critical frames. \n\n Quest has been updated: ' num2str(QuestCounterUpdated) ' times. \n\n Press any key when you are ready.'], 'center', 300, Red);
        Screen('Flip', wPtr);
        KbStrokeWait;
        %reactionTime = calculateReactionTime(ResultsPractice); % CLCULATING THE REACTION TIME THE OLD METHOD
        %*******************************************************
    else
        savePath = strcat(savePath,ExperimentName,num2str(reactionTimeOKCounter),'ESC.mat');
        save(savePath,'ResultsPractice');
        Screen('Flip', wPtr);
        DrawFormattedText(wPtr,'Experiment Aborted by pressing the ESC key... \n\ndata saved until ESC key pressed... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, 0, Red);
        Screen(wPtr, 'Flip');
        KbStrokeWait;
        Screen('CloseAll');
        
        %DAQ Code
        if UsePedals == 1
            delete (lh)
        end
        %end
        
    end
    tempReactionTimeOK = 'i'; % for invalid input
    while lower(tempReactionTimeOK) ~= 'y' 
        Screen(wPtr, 'Flip');
        reactionTimeOK = GetEchoString(wPtr, ['Your reaction time is: ' num2str(round(reactionTime*1000),4) ' Milliseconds . Is it OK? (Y/N)'], 10,10,Black);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
        if (lower(reactionTimeOK) == 'y')
            Screen(wPtr, 'Flip');
            Screen('TextSize', wPtr, 25);
            DrawFormattedText(wPtr,[' \n\nPractice mode of the experiment done!!! Thank you! \n\n\n Your final score is ' num2str(score) ' out of ' num2str(numTrials*10)  ' \n\n  Press any key to go to the occlusion step!'], 'center', 240, 0);
            Screen('TextSize', wPtr, 15);
            Screen(wPtr, 'Flip');
            KbStrokeWait;
            %clear reactionTimeDataAll;
            reactionTimeOK = 'Y';
            tempReactionTimeOK = 'Y';
        else
            if (lower(reactionTimeOK) == 'n')
                Screen(wPtr, 'Flip');
                DrawFormattedText(wPtr,'Do you want to Repeat the experiment or Manually enter the reaction time? \n ', 'center', 50, Black);
                repeatExperiment = GetEchoString(wPtr,'Press R to repeat the Experiment, M to Enter the reaction time manually. ( R/M)' , 90,90,Black);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
                if (lower(repeatExperiment) == 'r')
                    Screen(wPtr, 'Flip');
                    reactionTimeOKCounter = reactionTimeOKCounter + 1;
                    %timethresholdNew = GetEchoString(wPtr,'Enter a new value for time threshold in Milliseconds. (i.e. 300)' , 50,50,Black); %, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
                    %timeThreshold = timethresholdNew;
                    DrawFormattedText(wPtr,'You will repeat the previous trial (in random order) once more... \n\n Press any key to start...', 'center', 240, Blue);
                    Screen(wPtr, 'Flip');
                    KbStrokeWait;
                    tempReactionTimeOK = 'Y';
                else
                    if (lower(repeatExperiment) == 'm')
                        Screen(wPtr, 'Flip');
                        reactionTime = str2double(GetEchoString(wPtr,'Please enter the reaction time in Milliseconds (i.e. 300): ' , 100,100,Black))/1000;
                        reactionTimeOK = 'Y';
                        tempReactionTimeOK = 'Y';
                    end
                end
            end        
        end
    end
    Screen(wPtr, 'Flip');
end
Screen(wPtr, 'Flip');

%DAQ Code
if UsePedals == 1
    delete (lh)
    daq.reset
end

    function plotInline(src,event)
        
        transfercounter = transfercounter+1;
        
        if(transfercounter > 100000)
            transfercounter = 1;
        end
        
        if min(event.Data(:,1)) > 2.5
            pedalsInput(1) = 1;
        else
            pedalsInput(1) = 0;
            if alreadyRT == false
                alreadyRT = true;
                absolutePedalStart = event.TriggerTime;
                %recentPedals = event.Data;
                %recentPedalsTimes = event.TimeStamps;
                pedalTime = event.TimeStamps(find(event.Data(:,1)<=2.5, 1 ));
                %pedalTime = event.TimeStamps(length(event.TimeStamps));
            end
        end
        
        if min(event.Data(:,2)) > 2.5
            pedalsInput(2) = 1;
        else
            pedalsInput(2) = 0;
            if alreadyRT == false
                alreadyRT = true;
                absolutePedalStart = event.TriggerTime;
                %recentPedals = event.Data;
                %recentPedalsTimes = event.TimeStamps;
                pedalTime = event.TimeStamps(find(event.Data(:,2)<=2.5, 1 ));
                %pedalTime = event.TimeStamps(length(event.TimeStamps));
            end
        end
        
        
        transferTimes(transfercounter) = GetSecs;
        %plot(event.TimeStamps,event.Data)
    end

%DAQ Code WE CAN COMMENT THIS STUFF OUT AFTER PILOTING IS COMPLETE
% if UsePedals == 1
%     plot(diff(transferTimes(1:transfercounter)))
%     figure
%     scatter(FrameRT,AcRT)
%     Params = polyfit(FrameRT,AcRT,1);
%     Fit = polyval(Params,min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1);
%     hold on
%     plot(min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,Fit)
%     plot(min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,'r:')
% end
analyse.transsferTimes = transferTimes;
analyse.FrameRT = FrameRT;
analyse.AcRT = AcRT;
savePathnew = 'C:\TennisVideosGray\Results\Practice\';
savePathnew = strcat(savePathnew,ExperimentName,'analysis.mat');
save(savePathnew,'analyse');


%Daq change - changed this final line to end (from return) due to use of inline
%funtion above
end
