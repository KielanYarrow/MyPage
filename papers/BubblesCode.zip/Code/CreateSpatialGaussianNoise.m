% spatio-Temporal Bubbles
% In this code, a video and a set of frames are fed in. The out put is the
% same video with spatial bubbles on the selescted input frames.


function [movieNoised, finalMask , maskStartCoords] = CreateSpatialGaussianNoise(movieIn, numGaussianCenters, varianceMean ,SorR, framesRange)
%load('/Users/sepehr/Desktop/TennisVideosGray/RIC-32Gray.mat');
%finalVid = Vid;
%numGaussianCenters = 9;
%varianceMean = 8;
%720*1280
% For Serves
if SorR =='S'
    startX = 180 - varianceMean;%261; % 168
    endX = 420 + varianceMean;%460;   % 432
    startY = 380 - varianceMean;%391; % 368
    endY = 700 + varianceMean;%640;   % 712
else% For Returns
    startX = 240 - varianceMean;%261; % 228
    endX = 440 +  varianceMean;%460;  % 452
    startY = 320 - varianceMean ;%391;% 308 
    endY = 760 + varianceMean;%640;   % 772
end
maskStartCoords = [startX, startY];
finalVid = movieIn;
%rng('shuffle');
BubbleExtend = 6 * varianceMean;

movie = finalVid(startX:endX,startY:endY,:); % DEFINING THE MEANINGFUL PART OF THE VIDEO
if nargin < 5
    framesRange = (1:size(movie,3));
end
%framesRange = (1:size(movie,3));
%framesRange = (90:94); % COMMENT THIS LINE

movieNoised = zeros(size(movie,1),size(movie,2),size(movie,3));
tempVid = single(movie);
vHeight = size(movie,1);
vWidth = size(movie,2);
vFrames = size(movie,3); % if ColorVideo, change to 4
%rng('shuffle');
meansWRand = randi([BubbleExtend/2 vWidth-BubbleExtend/2],[numGaussianCenters,1]);
meansHRand = randi([BubbleExtend/2 vHeight-BubbleExtend/2],[numGaussianCenters,1]);
meanRand = [meansHRand meansWRand];
% Create the mask
hMask = fspecial('gaussian',[BubbleExtend BubbleExtend],varianceMean);
hMask = (hMask - min(min(hMask))) / (max(max(hMask)) - min(min(hMask)));
maskFrame = zeros(vHeight,vWidth);

for j = 1 : numGaussianCenters
    tempMask = zeros(vHeight,vWidth);
    centerpoint = meanRand(j,:);
    tempMask( centerpoint(1) - (BubbleExtend/2) + 1 : centerpoint(1) + (BubbleExtend/2),centerpoint(2) - (BubbleExtend/2) + 1 : centerpoint(2) + (BubbleExtend/2)) = hMask;
    tempMasks{j} = tempMask;
    clear tempMask;
end
%Combine masks
tempVal = ones(vHeight,vWidth);
%for i = 1 : vHeight
%for j = 1 : vWidth
for k = 1 : numGaussianCenters
    tempMask = tempMasks{k};
    thisVal = 1 - tempMask;
    tempVal = tempVal.*thisVal;
    clear tempMask;
end
finalMask = 1-tempVal;%1- prod(tempVal(k,:,:));
%finalMask(i,j) = finalVal;
%end
%end

%for i = 1 : vHeight
%for j = 1 : vWidth
%         for k = 1 : numGaussianCenters
%             tempMask = tempMasks{k};
%             tempVal(k) = 1 - tempMask(i,j);
%             clear tempMask;
%         end
%         finalVal = 1- prod(tempVal);
%         finalMask(i,j) = finalVal;
%end
%end

%add final mask to the selected video frames
for i = 1 : size(framesRange,2);
    tempFrame = tempVid(:,:,framesRange(i));
    meanTempFrame = mean(mean(tempFrame));
    tempFramDeducted = tempFrame - meanTempFrame;
    
    tempFrame = (tempFramDeducted .* finalMask) + meanTempFrame;
    %%%
    %tempVid(:,:,framesRange(i)) = tempFrame;
    
    finalVid(1:startX,1:end,framesRange(i)) = meanTempFrame;
    finalVid(endX:end,1:end,framesRange(i)) = meanTempFrame;
    finalVid(1:endX,1:startY,framesRange(i)) = meanTempFrame;
    finalVid(1:endX,endY:end,framesRange(i)) = meanTempFrame;
    
    finalVid(startX:endX,startY:endY,framesRange(i)) = tempFrame;
    clear tempFrame;
end
movieNoised = uint8(finalVid);

return;

