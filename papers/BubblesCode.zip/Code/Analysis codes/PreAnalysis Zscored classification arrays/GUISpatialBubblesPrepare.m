function ResultsExperimentFinal = GUISpatialBubblesPrepare(SelectedFileNames,SelectedVideoNames,filePath)%,numIterations)%,centerOnPosSelected)
% In this function, the filenames and videonames are read, and a single
% file containing all of them is created to be fed to FrameSelection for
% temporal bubbling using bootstrap. 
ResultsExperimentAll = {};
% if ispc
%     filePath = 'C:\TennisVideosGray\Results\Experiment\';
% else
%     %filePath = '/Users/sepehr/Desktop/lab machine jan 17/Results/Experiment/';
%     %filePath = '/Users/sepehr/Desktop/New Results loughborough/Spatial Results/';
%     filePath = '/Users/sepehr/Desktop/Ger Results/Experiment/';
% 
% 
% end
index = 1;
for i = 1 : size(SelectedFileNames,2)
    filePathFull = strcat(filePath, SelectedFileNames{i},'.mat');
    load(filePathFull);
    for j = 1 : size(ResultsExperiment,2)
        if ~isempty(ResultsExperiment{j})            
            ResultsExperimentAll{index} = ResultsExperiment{j};
            index = index + 1;
        end
    end
end
index = 1;
ResultsExperimentFinal = {};
for i = 1 : size(SelectedVideoNames,2)
    tempVidName = SelectedVideoNames{i};
    for j = 1 : size(ResultsExperimentAll,2)
        tempFile = ResultsExperimentAll{j};
        tempFileVidName = tempFile.VideoName(end-13:end-8);
        if strcmp(tempFileVidName,tempVidName)
            ResultsExperimentFinal{index} = ResultsExperimentAll{j};
            index = index + 1;
        end
    end
end
%FrameSelection(ResultsExperimentFinal,numIterations);
end
%
    
      
