function varargout = GUI(varargin)
% Temporal bubbles pre-analysis GUI.
% The GUI will open and let you pre-analyse some temporal bubbles data to
% create a z-scored classification sequence for a particular participant.
% It expects the data to be in the format of our experiments - the data
% files (one per p) contain a cell array, with one cell per trial. Each
% cell is a structure containing several fields documenting that trial,
% most importantly directionCorrect (did they get it right) and
% FinalValMask (the bubbles profile).
%
% The Data files need to be named in a particular format in order for the
% GUI to work out details (e.g. name, expertise condition, sex). Sorry -
% it's particular about how it parses up the file name, and you'll need to do
% some re-coding if you stray from this format. 
%
% When you run the GUI, you need to do the following, in order:
% 1) select a subset of trial types, e.g. just serves
% 2) press the update button
% 3) highlight, from the list of participants' data files, a participant
% 4) click bootstap (once) and wait a while
%
% To work properly, the GUI needs to know where to find several bits of
% data / information, which you must pass as inputs or 
% set manually near the start of this script (lines 90-100):
% 1) cell array of the time zero (contact point)
% information. Note that below this is assumed to come from a mat file
% that needs to contain a variable called
% contactPointsNameSelectFinal so
% you should rename the variable if this in incorrect
% 2) Location of the folder where your results (from each participant) are
% stored
% 3) Location of the folder to which the new (processed) results should be
% written



% GUI MATLAB code for GUI.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI

% Last Modified by GUIDE v2.5 06-Oct-2014 16:12:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @GUI_OpeningFcn, ...
    'gui_OutputFcn',  @GUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

if nargin < 4 || isempty(varargin{1})
    varargin{1} = load('C:\Users\sbbb944\Documents\Work\Sepehr\Bubbles Codes\Bubbles Codes Laptop Kaiserslautern\contactPointsNameSelectFinal.mat');
    varargin{1} = varargin{1}.contactPointsNameSelectFinal;
end
if nargin < 5 || isempty(varargin{2})
    varargin{2} = 'C:\Users\sbbb944\Documents\Work\Sepehr\TennisKL_Results_June2017\Results\Experiment\';
    %varargin{2} = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\';
end
if nargin < 6 || isempty(varargin{3})
    varargin{3} = 'C:\Users\sbbb944\Documents\Work\Sepehr\TennisKL_Results_June2017\Results\';
end

% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
handles.updateListCalled = 0;
handles.numPermutations = 2000;
handles.selectedVideoNames = [];
handles.selectedVideoListChanged = 0;

%LoadFileList(handles); % the main listbox showing all file info,
nameListStructAll = struct;

handles.DataLocation = varargin{2};
handles.WriteLocation = varargin{3};
filesListtemp = dir(fullfile(handles.DataLocation));
%     if ispc
%         filesListtemp = dir(fullfile('C:\Users\sbbb944\Documents\Work\Sepehr\TennisKL_Results_June2017\Results\Experiment'));
%         load('C:\Users\sbbb944\Documents\Work\Sepehr\Bubbles Codes\Bubbles Codes Laptop Kaiserslautern\contactPointsNameSelectFinal.mat');
% 
%     else
%         %filesListtemp = dir(fullfile('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment'));
%         %filesListtemp = dir(fullfile('/Users/sepehr/Desktop/lab machine jan 17/Results/Experiment'));
%         filesListtemp = dir(fullfile('/Users/sepehr/Desktop/Ger Results/Experiment'));
%         load('/Users/sepehr/Desktop/TennisVideosGray/contactPointsNameSelectFinal.mat');
%         % contactPointsNames
%     end
%handles.contactPointsNames = contactPointsNameSelectFinal;

handles.contactPointsNames = varargin{1};

filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;
counter = 1;
for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    tempDate = temp.date;
    tempDatenum = temp.datenum;
    if isempty(strfind(tempName,'.DS_Store'))
        %if (~strcmp(tempName(end-11:end-4), 'analysis'))
        if isempty(strfind(tempName,'analysis'))
            %if (~strcmp(tempName(end-10:end-4), 'Spatial'))
            if isempty(strfind(tempName,'Spatial'))
                %if(isempty(strfind(tempName,'SpatioTemporal')))
                if isempty(strfind(tempName,'SpatioTemporal'))
                    namesList{counter} = tempName(1:end-4);
                    datesList{counter} = tempDate;
                    datesnumList{counter} = tempDatenum;
                    counter = counter + 1;
                end
            end
        end
    end
end

for i =1:size(namesList,2)
    tempName = namesList{i};
    tempUniqueId(i) = i;
    UniqueID = i;
    tempDate = datesList{i};
    counter = 1;
    %tempNameseparate = sscanf(tempName, '%*d %s %d %*s', [1, inf]);
    while (~isempty(str2num(tempName(counter))) || tempName(counter) == '0')
        if (lower(tempName(counter) ~= 'j'))
            counter = counter + 1;
        else 
            break;
        end
    end
    trialDate = tempName(1:counter-1);
    newCounter = counter;
    while (isempty(str2num(tempName(newCounter))) || lower(tempName(newCounter)) =='i' || lower(tempName(newCounter)) =='j')
        if newCounter + 1 < size(tempName,2)
            newCounter = newCounter + 1;
        else
            break;
        end
    end
    trialName = upper(tempName(counter:newCounter-1));
    if (size(trialName,2) < 8)
        spacetemp = blanks(8 - size(trialName,2));
        %trialName = horzcat(trialName,spacetemp);
        trialName = [trialName,spacetemp];
    end
    counter = newCounter;
    while (~isempty(str2num(tempName(counter))) || tempName(counter) == '0')
        if counter + 1 < size(tempName,2)
            counter = counter + 1;
        else
            trialAge = 'N/A';
            break;
        end
    end
    if counter < size(tempName,2)
        trialAge = tempName(newCounter:counter-1);
    end
    trialGender = upper(tempName(counter));
    if strfind(lower(tempName),'serves')
        trialType = 'Services ';
    else
        trialType = 'Forehands';
    end
    if strfind(lower(tempName),'experiment1')
        trialExpertise =  'Beginner';
        trialExpertiseLevel = 1;
    else
        if strfind(lower(tempName),'experiment2')
            trialExpertise =  'Intermediate';
            trialExpertiseLevel = 2;
            
        else if strfind(lower(tempName),'experiment3')
                trialExpertise =  'Expert';
                trialExpertiseLevel = 3;
                
            else
                trialExpertise =  'N/A';
                trialExpertiseLevel = 0;
                
            end
        end
    end
    %
    %     trialDateYear = trialDate(1:4);
    %     if str2num(trialDate(1,5:6)) > 12
    %         trialDateMonth = trialDate(5);
    %     else
    %         trilaDateMonth = trialDate(1,5:6);
    %     end
    trialDateAll = upper(tempDate(1:end-3));
    
    tabSpace = blanks(3);
    %tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
    %nameListStructAll{i} = nameListStruct;
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
end

%[sorted_names,sorted_index] = sortrows({filesList.name}');
%handles.file_names = sorted_names;
handles.nameListStruct = nameListStruct;
handles.fileNames = nameListShow;
handles.uniqueName = namesList;     % this saves the file names before sorting
handles.uniqueID = tempUniqueId;    % this saves the indices of unique file names
%handles.is_dir = [filesList.isdir];
%handles.sorted_index = sorted_index;
%guidata(handles.output,handles)
set(handles.listboxFiles,'String',handles.fileNames);
set(handles.listboxFiles,'Value',[]);
%setappdata(handles.nameListStructAll, 'nameListStruct', handles.nameListStruct)


%LoadVideoList(handles); % the second lsitbox, only showing video names
% if ispc
%     filesListtemp = load('C:\Users\sbbb944\Documents\Work\Sepehr\Bubbles Codes\Bubbles Codes Laptop Kaiserslautern\contactPointsNameSelectFinal.mat');
% else
%     filesListtemp = load('/Users/sepehr/Desktop/TennisVideosGray/contactPointsNameSelectFinal');
% end
% VideoList = filesListtemp.contactPointsNameSelectFinal;
VideoList = varargin{1};

for i = 1 : 64
    temp = VideoList{i};
    videoNames{i} = temp.filename;
end
handles.videoNames = videoNames;
set(handles.listboxVideoNames,'String',handles.videoNames);
set(handles.listboxVideoNames,'Value',[]);


handles.selectedFiles = [];
handles.PlayerOneChecked = 1;
handles.PlayerTwoChecked = 1;
handles.PlayerThreeChecked = 1;
handles.ShotType = '';
handles.MaleSelected = 1;
handles.FemaleSelected = 1;
handles.lineChecked = 1;
handles.crossChecked = 1;


guidata(hObject, handles);

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
guidata(hObject, handles);


% --- Executes on button press in checkboxLine.
function checkboxLine_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxLine (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxLine
handles.lineChecked = get(hObject,'value');
guidata(hObject, handles);

% --- Executes on button press in checkboxCross.
function checkboxCross_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCross (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCross
handles.crossChecked = get(hObject,'value');
guidata(hObject, handles);


% --- Executes when selected object is changed in uipanel1.
function uipanel1_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel1
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
switch get(eventdata.NewValue,'Tag') % Get Tag of selected object.
    case 'ServesSelected'
        handles.ShotType = 'S';
    case 'ReturnsSelected'
        handles.ShotType = 'R';
end
guidata(hObject, handles);
%handles.ShotType = get(hObject,'Value');


% --- Executes on button press in checkboxPlayerOne.
function checkboxPlayerOne_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxPlayerOne (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxPlayerOne
handles.PlayerOneChecked = get(hObject,'value');
guidata(hObject, handles);


% --- Executes on button press in checkboxPlayerTwo.
function checkboxPlayerTwo_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxPlayerTwo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxPlayerTwo
handles.PlayerTwoChecked = get(hObject,'value');
guidata(hObject, handles);


% --- Executes on button press in checkboxPlayerThree.
function checkboxPlayerThree_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxPlayerThree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxPlayerThree
handles.PlayerThreeChecked = get(hObject,'value');
guidata(hObject, handles);


% --- Executes on button press in pushbuttonShowList.
function pushbuttonShowList_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbuttonCalculate.
function pushbuttonCalculate_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonCalculate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function listboxFiles_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxFiles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in listboxFiles.
function listboxFiles_Callback(hObject, eventdata, handles)
% hObject    handle to listboxFiles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxFiles contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxFiles
handles.selectedFiles = get(handles.listboxFiles, 'value');
guidata(hObject, handles);
%handles.nameListShowUpdated(handles.selectedFiles);



% --- Executes on selection change in listboxVideoNames.
function listboxVideoNames_Callback(hObject, eventdata, handles)
% hObject    handle to listboxVideoNames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxVideoNames contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxVideoNames
handles.selectedVideoNames = get(handles.listboxVideoNames, 'value');
handles.selectedVideoListChanged = 1;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function listboxVideoNames_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxVideoNames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ListUpdateButton.
function ListUpdateButton_Callback(hObject, eventdata, handles)
% hObject    handle to ListUpdateButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
contactPointsNames = handles.contactPointsNames;
h = 1;
if (isempty(handles.ShotType))
    errorstring = 'Choose Services or Forehands';
    h = errordlg(errorstring);
end

if(~handles.MaleSelected && ~handles.FemaleSelected)
    errorstring = 'Choose at least one gender';
    h = errordlg(errorstring);
end
if (~handles.lineChecked && ~handles.crossChecked)
    errorstring = 'Choose at least one shot direction';
    h = errordlg(errorstring);
end
if(~handles.PlayerOneChecked && ~handles.PlayerTwoChecked && ~handles.PlayerThreeChecked)
    errorstring = 'Choose at least one player';
    h = errordlg(errorstring);
end
if ( h < 2)
    nameListStruct = struct;
    tabSpace = blanks(3);
    if (handles.updateListCalled == 0)
        Asorted  = handles.nameListStruct;
        handles.updateListCalled = 1;
    else
        Asorted  = handles.nameListStruct;
        
        %Asorted = handles.nameListStructUpdated;
    end
    %nameListShowtemp = handles.fileNames;
    selectedType = lower(handles.ShotType);
    selectedGenderM = handles.MaleSelected;
    selectedGenderF = handles.FemaleSelected;
    if (selectedGenderM + selectedGenderF == 2);
        selectedBothGender = 1;
    else
        selectedBothGender = 0;
    end
    if (selectedType == 'r' || selectedType == 'f')
        selectedType = 'f';
    else
        selectedType = 's';
    end
    index = 1;
    for i = 1 : size(Asorted,2)
        trialType = Asorted(i).Type;
        trialGender = Asorted(i).Gender;
        if (selectedType == lower(trialType(1)))
            if (selectedBothGender || (trialGender == 'M' && selectedGenderM) || (trialGender == 'F' && selectedGenderF))
                trialDateAll = Asorted(i).Date;
                trialName = Asorted(i).Name;
                trialAge = Asorted(i).Age;
                trialExpertise = Asorted(i).Expertise;
                trialExpertiseLevel = Asorted(i).ExpertiseLevel;
                UniqueID = Asorted(i).UniqueID;
                tempName = Asorted(i).FileName;
                datesnumList{index} = Asorted(i).dateNum;
                %nameListStructAll{i} = nameListStruct;
                tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
                nameListShow{index} = tempStr;
                nameListType{index} = trialType;
                clear tempStr;
                nameListStruct(index).Date = trialDateAll;
                nameListStruct(index).Name = trialName;
                nameListStruct(index).Age = trialAge;
                nameListStruct(index).Gender = trialGender;
                nameListStruct(index).Type = trialType;
                nameListStruct(index).Expertise = trialExpertise;
                nameListStruct(index).ExpertiseLevel = trialExpertiseLevel;
                nameListStruct(index).UniqueID = UniqueID;
                nameListStruct(index).FileName = tempName;
                nameListStruct(index).dateNum = datesnumList{index};
                index = index + 1;
            end
        end
    end
    handles.nameListStructUpdated = nameListStruct;
    handles.nameListShowUpdated = nameListShow;
    set(handles.listboxFiles,'String',handles.nameListShowUpdated);
    set(handles.listboxFiles,'Value',[]);
    
    set(handles.CalculateButton,'Enable','on');
    guidata(hObject, handles);
    
    % update the video names list as well here. Only serves or returns.
    if (selectedType == 'f')
        selectedType = 'r';
    else
        selectedType = 's';
    end
    VideoNamesList = handles.videoNames;
    index = 1;
    for i = 1 : 64
        temp = VideoNamesList{i};
        if lower(temp(1)) == selectedType
            videoNamesListUpdated{index} = temp;
            index = index + 1;
        end
    end
    
    if (handles.crossChecked && ~handles.lineChecked)
        index = 1;
        for i = 1 : size(videoNamesListUpdated,2)
            temp = videoNamesListUpdated{i};
            if lower(temp(3)) == 'c'
                videoNamesListUpdatedNew{index} = temp;
                index = index + 1;
            end
        end
        clear videoNamesListUpdated;
        videoNamesListUpdated = videoNamesListUpdatedNew;
    else if (~handles.crossChecked && handles.lineChecked)
            index = 1;
            for i = 1 : size(videoNamesListUpdated,2)
                temp = videoNamesListUpdated{i};
                if lower(temp(3)) == 'l'
                    videoNamesListUpdatedNew{index} = temp;
                    index = index + 1;
                end
            end
            clear videoNamesListUpdated;
            videoNamesListUpdated = videoNamesListUpdatedNew;
        end
    end
    clear videoNamesListUpdatedNew;
    index = 1; % to remove Player TWO videos from the list, as they were used for training.
    for i = 1 : size (videoNamesListUpdated,2)
        temp = videoNamesListUpdated{i};
        for j = 1 : 64
            temp2 = contactPointsNames{j};
            if(strcmp(temp,temp2.filename) && temp2.playeName ~= 4) %2
                videoNamesListUpdatedNew{index} = temp;
                index = index + 1;
                break;
                %nochangeTag = 0;
            end
        end
    end
    clear videoNamesListUpdated;
    videoNamesListUpdated = videoNamesListUpdatedNew;
    clear videoNamesListUpdatedNew;
    %****
    %nochangeTag = 1;
    index = 1;
    if(~handles.PlayerOneChecked)
        % %         for i = 1 : size (videoNamesListUpdated,2)
        % %             temp = videoNamesListUpdated{i};
        % %             for j = 1 : 64
        % %                 temp2 = contactPointsNames{j};
        % %                 if strcmp(temp2.filename, temp)
        % %                     if temp2.playerName == 1
        % % %                         %if (exist('videoNamesListUpdated','var'))
        % % %                         redundantTag = 0;
        % % %                         for k = 1 : size(videoNamesListUpdated,2)
        % % %                             temppp =videoNamesListUpdated{k};
        % % %                             if strcmp(temppp, temp)
        % % %                                 redundantTag = 1;
        % % %                                 break;
        % % %                             end
        % % %                         end
        % % %                         %end
        % % %                         if ~redundantTag
        % %                             videoNamesListUpdatedNew{index} = temp;
        % %                             index = index + 1;
        % %                             %nochangeTag = 0;
        % %                         %end
        % %                     end
        % %                 end
        % %             end
        % %         end
        %     else
        for i = 1 : size (videoNamesListUpdated,2)
            temp = videoNamesListUpdated{i};
            for j = 1 : 64
                temp2 = contactPointsNames{j};
                if(strcmp(temp,temp2.filename) && temp2.playerName ~= 1)
                    videoNamesListUpdatedNew{index} = temp;
                    index = index + 1;
                    break;
                    %nochangeTag = 0;
                end
            end
        end
        clear videoNamesListUpdated;
        videoNamesListUpdated = videoNamesListUpdatedNew;
        clear videoNamesListUpdatedNew;
    end
    %if (~nochangeTag)
    
    %end
    %****
    index = 1;
    if (~handles.PlayerTwoChecked)
        %         for i = 1 : size (VideoNamesList,2)
        %             temp = VideoNamesList{i};
        %             for j = 1 : 64
        %                 temp2 = contactPointsNames{j};
        %                 if strcmp(temp2.filename, temp)
        %                     if temp2.playerName == 4
        %                         videoNamesListUpdated{index} = temp;
        %                         index = index + 1;
        %                     end
        %                 end
        %             end
        %         end
        %   else
        for i = 1 : size (videoNamesListUpdated,2)
            temp = videoNamesListUpdated{i};
            for j = 1 : 64
                temp2 = contactPointsNames{j};
                if(strcmp(temp,temp2.filename) && temp2.playerName ~= 2) %4
                    videoNamesListUpdatedNew{index} = temp;
                    index = index + 1;
                    break;
                    %nochangeTag = 0;
                end
            end
        end
        clear videoNamesListUpdated;
        videoNamesListUpdated = videoNamesListUpdatedNew;
        clear videoNamesListUpdatedNew;
    end
    
    %****
    index = 1;
    if (~handles.PlayerThreeChecked)
        %         for i = 1 : size (VideoNamesList,2)
        %             temp = VideoNamesList{i};
        %             for j = 1 : 64
        %                 temp2 = contactPointsNames{j};
        %                 if strcmp(temp2.filename, temp)
        %                     if temp2.playerName == 3
        %                         videoNamesListUpdated{index} = temp;
        %                         index = index + 1;
        %                     end
        %                 end
        %             end
        %         end
        %    else
        for i = 1 : size (videoNamesListUpdated,2)
            temp = videoNamesListUpdated{i};
            for j = 1 : 64
                temp2 = contactPointsNames{j};
                if(strcmp(temp,temp2.filename) && temp2.playerName ~= 3)
                    videoNamesListUpdatedNew{index} = temp;
                    index = index + 1;
                    break;
                    %nochangeTag = 0;
                end
            end
        end
        clear videoNamesListUpdated;
        videoNamesListUpdated = videoNamesListUpdatedNew;
        clear videoNamesListUpdatedNew;
    end
    
    %****
    handles.videoNamesUpdated = videoNamesListUpdated;
    set(handles.listboxVideoNames,'String',handles.videoNamesUpdated);
    %valsOne = ones(32,1);
    set(handles.listboxVideoNames,'Value',[]);
    %
    %handles.selectedVideoNames = (1:32);
    
    %handles.selectedVideoNames = get(handles.listboxVideoNames, 'value');
    %valsOne = ones(32,1);
    %set(handles.listboxVideoNames,'Value',valsOne);
    %guidata(hObject, handles);
    
    guidata(hObject, handles);
    
end

function numPermutations_Callback(hObject, eventdata, handles)
% hObject    handle to numPermutations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numPermutations as text
%        str2double(get(hObject,'String')) returns contents of numPermutations as a double
handles.numPermutations = str2num(get(hObject,'String'));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function numPermutations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numPermutations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkboxMale.
function checkboxMale_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxMale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxMale
handles.MaleSelected = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkboxFemale.
function checkboxFemale_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxFemale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.FemaleSelected = get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in pushbuttonSelectVids.
function pushbuttonSelectVids_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSelectVids (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h = 1;
if(~handles.PlayerOneChecked && ~handles.PlayerTwoChecked && ~handles.PlayerThreeChecked)
    errorstring = 'Choose at least one player';
    h = errordlg(errorstring);
end
if (isempty(handles.ShotType))
    errorstring = 'Choose Services or Forehands';
    h = errordlg(errorstring);
end
if h < 2
    
end

% Hint: get(hObject,'Value') returns toggle state of checkboxFemale
% function handles = LoadVideoList(handles)
% if ispc
%     filesListtemp = load('c:\TennisVideosGray\contactPointsNameSelectFinal.mat');
% else
%     filesListtemp = load('/Users/sepehr/Desktop/TennisVideosGray/contactPointsNameSelectFinal');
% end
% VideoList = filesListtemp.contactPointsNames;
% for i = 1 : 64
%     temp = VideoList{i};
%     videoNames{i} = temp.filename;
% end
% handles.videoNamesUpdated = videoNames;
% set(handles.listboxVideoNames,'String',handles.videoNamesUpdated);
% set(handles.listboxVideoNames,'Value',[]);
%
% return;
%*************************************************************************
%function handles = LoadFileList(handles)
% nameListStructAll = struct;
% if ispc
%     filesListtemp = dir(fullfile('c:\TennisVideosGray\Results\Experiment'));
% else
%     filesListtemp = dir(fullfile('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment'));
% end
% filesList(1:size(filesListtemp,1)-3) = filesListtemp(4:end);
% clear filesListtemp;
% counter = 1;
% for i = 1 : size(filesList,2)
%     temp = filesList(i);
%     tempName = temp.name;
%     tempDate = temp.date;
%     tempDatenum = temp.datenum;
%     if (~strcmp(tempName(end-11:end-4), 'analysis'))
%         namesList{counter} = tempName(1:end-4);
%         datesList{counter} = tempDate;
%         datesnumList{counter} = tempDatenum;
%         counter = counter + 1;
%     end
% end
%
% for i =1:size(namesList,2)
%     tempName = namesList{i};
%     tempUniqueId(i) = i;
%     UniqueID = i;
%     tempDate = datesList{i};
%     counter = 1;
%     %tempNameseparate = sscanf(tempName, '%*d %s %d %*s', [1, inf]);
%     while (~isempty(str2num(tempName(counter))) || tempName(counter) == '0')
%         counter = counter + 1;
%     end
%     trialDate = tempName(1:counter-1);
%     newCounter = counter;
%     while (isempty(str2num(tempName(newCounter))) || lower(tempName(newCounter)) =='i')
%         if newCounter + 1 < size(tempName,2)
%             newCounter = newCounter + 1;
%         else
%             break;
%         end
%     end
%     trialName = upper(tempName(counter:newCounter-1));
%     if (size(trialName,2) < 8)
%         spacetemp = blanks(8 - size(trialName,2));
%         %trialName = horzcat(trialName,spacetemp);
%         trialName = [trialName,spacetemp];
%     end
%     counter = newCounter;
%     while (~isempty(str2num(tempName(counter))) || tempName(counter) == '0')
%         if counter + 1 < size(tempName,2)
%             counter = counter + 1;
%         else
%             trialAge = 'N/A';
%             break;
%         end
%     end
%     if counter < size(tempName,2)
%         trialAge = tempName(newCounter:counter-1);
%     end
%     trialGender = upper(tempName(counter));
%     if strfind(lower(tempName),'serves')
%         trialType = 'Services ';
%     else
%         trialType = 'Forehands';
%     end
%     if strfind(lower(tempName),'experiment1')
%         trialExpertise =  'Beginner';
%         trialExpertiseLevel = 1;
%     else
%         if strfind(lower(tempName),'experiment2')
%             trialExpertise =  'Intermediate';
%             trialExpertiseLevel = 2;
%
%         else if strfind(lower(tempName),'experiment3')
%                 trialExpertise =  'Expert';
%                 trialExpertiseLevel = 3;
%
%             else
%                 trialExpertise =  'N/A';
%                 trialExpertiseLevel = 0;
%
%             end
%         end
%     end
%     %
%     %     trialDateYear = trialDate(1:4);
%     %     if str2num(trialDate(1,5:6)) > 12
%     %         trialDateMonth = trialDate(5);
%     %     else
%     %         trilaDateMonth = trialDate(1,5:6);
%     %     end
%     trialDateAll = upper(tempDate(1:end-3));
%
%     tabSpace = blanks(3);
%     %tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
%     tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
%     nameListStruct(i).Date = trialDateAll;
%     nameListStruct(i).Name = trialName;
%     nameListStruct(i).Age = trialAge;
%     nameListStruct(i).Gender = trialGender;
%     nameListStruct(i).Type = trialType;
%     nameListStruct(i).Expertise = trialExpertise;
%     nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
%     nameListStruct(i).UniqueID = UniqueID;
%     nameListStruct(i).FileName = tempName;
%     nameListStruct(i).dateNum = datesnumList{i};
%     %nameListStructAll{i} = nameListStruct;
%     nameListShow{i} = tempStr;
%     nameListType{i} = trialType;
%     clear tempStr;
% end

%[sorted_names,sorted_index] = sortrows({filesList.name}');
%handles.file_names = sorted_names;
% handles.nameListStruct = nameListStruct;
% handles.fileNames = nameListShow;
% handles.uniqueName = namesList;     % this saves the file names before sorting
% handles.uniqueID = tempUniqueId;    % this saves the indices of unique file names
% %handles.is_dir = [filesList.isdir];
% %handles.sorted_index = sorted_index;
% guidata(handles.output,handles)
% set(handles.listboxFiles,'String',handles.fileNames);
% set(handles.listboxFiles,'Value',[]);
% %setappdata(handles.nameListStructAll, 'nameListStruct', handles.nameListStruct)
%
%return ; % from LoadFileList()


% --- Executes on button press in SortDate.
function SortDate_Callback(hObject, eventdata, handles)
% hObject    handle to SortDate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%guidata(hObject, handles);
%nameListStructtemp = get(handles.nameListStruct, 'value');
%nameListStructtemp = getappdata(handles.nameListStruct , 'nameListStruct')
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';
% Sort by field "dateNum"
Acell = sortrows(Acell, 10);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);



% --- Executes on button press in SortName.
function SortName_Callback(hObject, eventdata, handles)
% hObject    handle to SortName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';

% Sort by field "Name"
Acell = sortrows(Acell, 2);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);


% --- Executes on button press in SortAge.
function SortAge_Callback(hObject, eventdata, handles)
% hObject    handle to SortAge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';

% Sort by field "Age"
Acell = sortrows(Acell, 3);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);

% --- Executes on button press in SortGender.
function SortGender_Callback(hObject, eventdata, handles)
% hObject    handle to SortGender (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';

% Sort by field "Gender"
Acell = sortrows(Acell, 4);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);

% --- Executes on button press in SortType.
function SortType_Callback(hObject, eventdata, handles)
% hObject    handle to SortType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';

% Sort by field "Type"
Acell = sortrows(Acell, 5);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);

% --- Executes on button press in SortExpertise.
function SortExpertise_Callback(hObject, eventdata, handles)
% hObject    handle to SortExpertise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.updateListCalled
    nameListStructtemp = handles.nameListStructUpdated;
else
    nameListStructtemp = handles.nameListStruct;
end
Afields = fieldnames(nameListStructtemp);
Acell = struct2cell(nameListStructtemp);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);
Acell = Acell';

% Sort by field "Expertise"
Acell = sortrows(Acell, 6);
Acell = reshape(Acell', sz);
Asorted = cell2struct(Acell, Afields, 1);

tabSpace = blanks(3);
%tempStr = horzcat(trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace);
for i = 1 : size(Asorted,2)
    trialDateAll = Asorted(i).Date;
    trialName = Asorted(i).Name;
    trialAge = Asorted(i).Age;
    trialGender = Asorted(i).Gender;
    trialType = Asorted(i).Type;
    trialExpertise = Asorted(i).Expertise;
    trialExpertiseLevel = Asorted(i).ExpertiseLevel;
    UniqueID = Asorted(i).UniqueID;
    tempName = Asorted(i).FileName;
    datesnumList{i} = Asorted(i).dateNum;
    %nameListStructAll{i} = nameListStruct;
    tempStr = [trialDateAll, tabSpace, trialName, tabSpace, trialAge, tabSpace, trialGender, tabSpace, trialType, tabSpace,trialExpertise];
    nameListShow{i} = tempStr;
    nameListType{i} = trialType;
    clear tempStr;
    nameListStruct(i).Date = trialDateAll;
    nameListStruct(i).Name = trialName;
    nameListStruct(i).Age = trialAge;
    nameListStruct(i).Gender = trialGender;
    nameListStruct(i).Type = trialType;
    nameListStruct(i).Expertise = trialExpertise;
    nameListStruct(i).ExpertiseLevel = trialExpertiseLevel;
    nameListStruct(i).UniqueID = UniqueID;
    nameListStruct(i).FileName = tempName;
    nameListStruct(i).dateNum = datesnumList{i};
end
handles.nameListStructUpdated = nameListStruct;
%handles.nameListShow = nameListShow;
%set(handles.listboxFiles,'String',handles.nameListShow);
handles.nameListShowUpdated = nameListShow;
set(handles.listboxFiles,'String',handles.nameListShowUpdated);
set(handles.listboxFiles,'Value',[]);
guidata(hObject, handles);

% --- Executes on button press in ResetListButton.
function ResetListButton_Callback(hObject, eventdata, handles)
% hObject    handle to ResetListButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.listboxFiles,'String',handles.fileNames);
set(handles.listboxFiles,'Value',[]);
set(handles.CalculateButton,'Enable','off');
set(handles.listboxVideoNames,'String',handles.videoNames);

guidata(hObject, handles);


% --- Executes on button press in CalculateButton.
function CalculateButton_Callback(hObject, eventdata, handles)
% hObject    handle to CalculateButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (isempty(handles.selectedFiles))
    temp = handles.nameListStructUpdated;
    for i = 1 : size(handles.nameListStructUpdated,2)
        temp2 = temp(i);
        SelectedFileNames{i} = temp2.FileName;
    end
else
    temp = handles.nameListStructUpdated;
    for i = 1 : size(handles.selectedFiles,2)
        temp2 = temp(handles.selectedFiles(i));
        SelectedFileNames{i} = temp2.FileName;
    end
end
if (isempty(handles.selectedVideoNames))
    SelectedVideoNames = handles.videoNamesUpdated;
else
    for i = 1 : size(handles.selectedVideoNames,2)
        SelectedVideoNames(i) = handles.videoNamesUpdated(handles.selectedVideoNames(i));
    end
end
numIterations = handles.numPermutations;
tic;
ResultsExperimentFinal = GUITemporalBubblesPrepare(SelectedFileNames,SelectedVideoNames,handles.DataLocation);%,numIterations);
% % % load('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/SimulateTemporalServes10B.mat');
% % % ResultsExperimentFinal = ResultsExperiment;
vidName = SelectedVideoNames{1};
if strfind(lower(vidName(1)),'s')
        trialType = 'Services ';
    else
        trialType = 'Forehands';
end
TemporalBootstrap(ResultsExperimentFinal,numIterations,trialType,SelectedFileNames,handles.WriteLocation)
toc
