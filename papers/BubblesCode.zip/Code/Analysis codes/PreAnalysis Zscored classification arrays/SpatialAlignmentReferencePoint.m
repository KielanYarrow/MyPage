% In this file we find the ball contact point in different videos, and
% overlap them.
function alignedMasksReferencePoint = SpatialAlignmentReferencePoint(SelectedVideoNames,Masks, ReferencePoint,PosInfo)

%load('/Users/sepehr/Dropbox/Bubbles Codes/PosInfo.mat');
varianceMean = 12;
%shortListVideoNames = unique(SelectedVideoNames);
%for i = 1 : size(shortListVideoNames,2)
for i = 1 : size(SelectedVideoNames,2)
    temp = SelectedVideoNames{i};
    for j = 1 : size(PosInfo,2)
        tempPos = PosInfo{j};
        tempPosViName = tempPos.videoName;
        if temp == tempPosViName
            break;
        end
    end
    switch ReferencePoint
        case 'BR'
            selectedReferencePoint{i} = tempPos.PosBallContact;       
        case 'NO'
            selectedReferencePoint{i} = tempPos.PosNose;       
        case 'NA'
            selectedReferencePoint{i} = tempPos.PosNavel;
        case 'RF'
            selectedReferencePoint{i} = tempPos.PosRightFoot;
        case 'LF'
            selectedReferencePoint{i} = tempPos.PosLeftFoot;
        case 'RW'
            selectedReferencePoint{i} = tempPos.PosRightWrist;
        case 'LW'
            selectedReferencePoint{i} = tempPos.PosLeftWrist;
        case 'RE'
            selectedReferencePoint{i} = tempPos.PosRightElbow;
        case 'LE'
            selectedReferencePoint{i} = tempPos.PosLeftElbow;
        case 'RS'
            selectedReferencePoint{i} = tempPos.PosRightShoulder;
        case 'LS'
            selectedReferencePoint{i} = tempPos.PosLeftShoulder;
    end
end


fullMask = zeros(400*2, 600*2);
tempBigImage = zeros(400*2, 600*2);
for i = 1 : size(selectedReferencePoint,2)
    tempFrame = Masks{i};
    tempPos = selectedReferencePoint{i};
    Pos(1) = tempPos(2) - 161; % this is the pixel difference between starting point of mask and presentation
    Pos(2) = tempPos(1) - 241; % this is the pixel difference between starting point of mask and presentation
    posStartX = 200 + (200 - Pos(1));
    posStartY = 300 + (300 - Pos(2));
    tempBigImage(posStartX:posStartX+399, posStartY:posStartY + 599) = tempFrame;
    alignedMasksReferencePoint{i} = tempBigImage;
    %fullMask = fullMask + tempBigImage;
end




% 
% for i = 1 : size(PosInfo,2)
%     temp = PosInfo{i};
%     videoName = temp.videoName; % find the video name
%     if (videoName(1) == 'R')
%         %videoName = strcat('/Users/sepehr/Desktop/TennisVideosGray/',videoName,'Gray.mat');
%         frameName = strcat('/Users/sepehr/Dropbox/Bubbles Codes/Frames/contactFrame',videoName,'.jpg');
%         tempImage = imread(frameName);
%         contactFrameReturns{i} = tempImage(161:560,241:840);
%         posR{i} = temp.PosBallContact;
%     end
% end
% for i = 1 : size(PosInfo,2)
%     temp = PosInfo{i};
%     videoName = temp.videoName; % find the video name
%     if (videoName(1) == 'S')
%         frameName = strcat('/Users/sepehr/Dropbox/Bubbles Codes/Frames/contactFrame',videoName,'.jpg');
%         tempImageS = imread(frameName);
%         contactFrameServes{i-24} = tempImageS(161:560,241:840);
%         posS{i-24} = temp.PosBallContact;
%     end
%     %imshow(contactFrame);
% end



% 
% bigImageServes = zeros(400*2, 600*2);
% tempBigImageServes = zeros(400*2, 600*2);
% for i = 1 : 24
%     tempFrame = contactFrameServes{i};
%     tempPos = posS{i};
%     Pos(1) = tempPos(2) - 161;
%     Pos(2) = tempPos(1) - 241;
%     posStartX = 200 + (200 - Pos(1));
%     posStartY = 300 + (300 - Pos(2));
%     tempBigImageServes(posStartX:posStartX+399, posStartY:posStartY + 599) = tempFrame;
%     bigImageServes = bigImageServes + tempBigImageServes;
% end
% bigImageServes = uint8(bigImageServes / 24);


% 
% bigImageReturns = zeros(400*2, 600*2);
% tempBigImageReturns = zeros(400*2, 600*2);
% for i = 1 : 24
%     tempFrame = contactFrameReturns{i};
%     tempPos = posR{i};
%     Pos(1) = tempPos(2) - 161;
%     Pos(2) = tempPos(1) - 241;
%     posStartX = 200 + (200 - Pos(1));
%     posStartY = 300 + (300 - Pos(2));
%     tempBigImageReturns(posStartX:posStartX+399, posStartY:posStartY + 599) = tempFrame;
%     bigImageReturns = bigImageReturns + tempBigImageReturns;
% end
% bigImageReturns = uint8(bigImageReturns / 24);
end
% 
% temp = zeros(600,800);
% for i = 1 : size(BGFinal,1)
%     temp = temp + double(reshape(BGFinal(i,:,:),size(BGFinal,2),size(BGFinal,3)));
% end
% imshow(uint8(reshape(temp,size(temp,2),size(temp,3)) / size(BGFinal,1)));
% temp = temp / size(BGFinal,2);
% imshow(uint8(temp));
