% In this file, the bootstrap is performed on aligned spatial masks
function SpatialBootstrapCentralizedMasks(AlignedMasks, ReferenceImage,ResultsExperiment,numIterations,SelectedFileNames,PathName)
% PathName = '/Users/sepehr/Desktop/Ger Analysis/';

%load('/Users/sepehr/Desktop/sianSpatialServesCentralizedMask.mat');
%load('/Users/sepehr/Desktop/files/SianReturnsSpatialContralized.mat');
%load('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/20148121540Sian24FExperimentServesSpatio.mat');
%load('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/20148121540Sian24FExperimentReturnsSpatio.mat');
rng('shuffle');
ZScoreThreshold = 1.96;
AimedPercental = 95; % number between 0 and 100: 95%
%numIterations = 2000; % for test purposes. Reset to 2000
numTrials =size(ResultsExperiment,2);
numCorrect = 0;
numWrong = 0;
for i = 1 : numTrials
    temp = ResultsExperiment{i};
    if (temp.directionCorrect)
        numCorrect = numCorrect + 1;
    else
        numWrong = numWrong +1;
    end
    clear temp;
end
%**********
% finding effective regions:
temp2 = AlignedMasks{1};
temp = zeros(size(temp2));
for i = 1 : size(AlignedMasks,2)
    tempFrame = AlignedMasks{i};
    temp = tempFrame + temp;
end
[lowerTemp2, higherTemp2] = find(temp);
tempHlower2 = min(min(lowerTemp2));
tempHhigher2 = max(max(lowerTemp2));
tempWlower2 = min(min(higherTemp2));
tempWhigher2 = max(max(higherTemp2));

%********
backupAigendMasks = AlignedMasks;
for i = 1 : size(AlignedMasks,2)
    tempp =  AlignedMasks{i};
    NewAlignedMasks{i} = tempp(tempHlower2-5:tempHhigher2+5, tempWlower2-5:tempWhigher2+5);
end


temp = NewAlignedMasks{1};
vectorSize = size(temp);
MasksFinal = zeros(numIterations, vectorSize(1), vectorSize(2));
for i = 1 : numIterations
    MaskTemp = zeros(vectorSize(1),vectorSize(2));
    randomIndices = randperm(numTrials);
    for j = 1 : numCorrect
        temp = NewAlignedMasks{randomIndices(j)};
        MaskTemp = MaskTemp + temp;
    end
    for k = numCorrect+1 : numTrials
        temp = NewAlignedMasks{randomIndices(k)};
        MaskTemp = MaskTemp - temp;
    end
    MaskTemp = MaskTemp / numTrials;
    MasksFinal(i,:,:) = MaskTemp;
    clear MaskTemp temp;
end

MeanMasks = mean(MasksFinal,1);
MeanMasks = reshape(MeanMasks,size(MeanMasks,2),size(MeanMasks,3));
StdMasks = std(MasksFinal,1);
StdMasks = reshape(StdMasks,size(StdMasks,2),size(StdMasks,3));

MasksFinalMeanStd = zeros(numIterations, vectorSize(1),vectorSize(2));
ZscoresFinal = zeros(numIterations, vectorSize(1),vectorSize(2));
ZscoresFinalLables = zeros(numIterations, vectorSize(1),vectorSize(2));
ZscoresFinalSums = zeros(numIterations, vectorSize(1),vectorSize(2));
MaxDist = zeros(1,numIterations);
for i = 1 : numIterations
    MaskTemp = zeros(vectorSize(1),vectorSize(2));
    %rng('shuffle');
    randomIndices = randperm(numTrials);
    for j = 1 : numCorrect
        temp = NewAlignedMasks{randomIndices(j)};
        MaskTemp = MaskTemp + temp;
    end
    for k = numCorrect+1 : numTrials
        temp = NewAlignedMasks{randomIndices(k)};
        MaskTemp = MaskTemp - temp;
    end
    MaskTemp = MaskTemp / numTrials;
    MaskTemp = MaskTemp - MeanMasks;
    MaskTemp = MaskTemp ./ StdMasks;
    MaskTemp(isnan(MaskTemp)) = 0;
    MasksFinalMeanStd(i,:,:) = MaskTemp;
    % Find Clsuters for each presentation and find the abs(MAX)
    ZScores = zeros(vectorSize(1),vectorSize(2));
    ZScoresLabels = zeros(vectorSize(1),vectorSize(2));
    ZScoresSums = zeros(vectorSize(1),vectorSize(2));
    
    tempBox = zeros( vectorSize(1),vectorSize(2));
    tempBox2 = zeros( vectorSize(1),vectorSize(2));
    
    for l = 1 : vectorSize(1)
        for m = 1 : vectorSize(2)
            if MaskTemp(l,m) > ZScoreThreshold
                tempBox(l,m) = 1;
            end
        end
    end
    cc = bwconncomp(tempBox, 4); % FOUR neighborhood, can be changed to 8
    for n = 1 : cc.NumObjects
        pixelList = cc.PixelIdxList{n};
        tempBox2(pixelList) = sum(MaskTemp(pixelList));
    end
    tempBox2 = reshape(tempBox2, vectorSize(1),vectorSize(2));
    
    ZscoresFinal(i,:,:) = MaskTemp; % DO WE NEED TO SAVE THESE? IF NOT CLEAR THEM
    ZscoresFinalLables(i,:,:) = tempBox;
    ZscoresFinalSums(i,:,:) = tempBox2;
    clear MaskTemp tempBox tempBox2 cc;
    MaxDist(i) = max(max(ZscoresFinalSums(i,:,:)));
    %MaxDist(i) = max(max(tempBox2(:,:)));
end

PercentileVal = prctile(MaxDist,AimedPercental);
%hist(MaxDist,30);
% Now use real responses
MaskTemp = zeros(vectorSize(1),vectorSize(2));
for i = 1 : numTrials
    temp = ResultsExperiment{i};
    if (temp.directionCorrect)
        MaskTemp = MaskTemp + NewAlignedMasks{i};
    else
        MaskTemp = MaskTemp - NewAlignedMasks{i};
    end
    clear temp;
end

MaskTemp = MaskTemp / numTrials;
MaskTemp = MaskTemp - MeanMasks;
MaskZScored = MaskTemp ./ StdMasks;

MaskZScored(isnan(MaskZScored)) = 0;
MaskZScoredFinal = zeros(600,800);
MaskZScoredFinal(tempHlower2-5:tempHhigher2+5, tempWlower2-5:tempWhigher2+5) = MaskZScored; 

MaskTemp = MaskZScored;
tempBox = zeros( vectorSize(1),vectorSize(2));
tempBox2 = zeros( vectorSize(1),vectorSize(2));

for l = 1 : vectorSize(1)
    for m = 1 : vectorSize(2)
        if MaskTemp(l,m) > ZScoreThreshold
            tempBox(l,m) = 1;
        end
    end
end
cc = bwconncomp(tempBox, 4); % FOUR neighborhood, can be changed to 8
for n = 1 : cc.NumObjects
    pixelList = cc.PixelIdxList{n};
    tempBox2(pixelList) = sum(MaskTemp(pixelList));
end
tempBox2 = reshape(tempBox2, vectorSize(1),vectorSize(2));
tempBox3 = zeros(vectorSize(1), vectorSize(2));
for i = 1 : vectorSize(1)
    for j = 1 : vectorSize(2)
        if tempBox2(i,j) > PercentileVal
            tempBox3(i,j) = tempBox2(i,j);
        else
            if tempBox2(i,j) > 0
                tempBox3 (i,j) = 0.1;
            else
                tempBox3 (i,j) = 0.005;
            end
        end
    end
end
SpatialBubblesMask = zeros(600,800);
SpatialBubblesMask(tempHlower2-5:tempHhigher2+5, tempWlower2-5:tempWhigher2+5) = tempBox3; 
ReferenceImageFinal = zeros(600,800);
temp2 = ReferenceImageFinal;
for i = 1 : size(AlignedMasks,2)
    temp2 = ReferenceImage{i};
    ReferenceImageFinal = ReferenceImageFinal + temp2;
end
ReferenceImageFinal = uint8(ReferenceImageFinal/384);
figure, imshow(ReferenceImageFinal, 'InitialMag', 'fit');
red = cat(3, ones(size(ReferenceImageFinal)),zeros(size(ReferenceImageFinal)), zeros(size(ReferenceImageFinal)));
hold on
h = imshow(red);
hold off
set(h, 'AlphaData', SpatialBubblesMask);
  

BootstrapSpatial.PercentileVal = PercentileVal;
BootstrapSpatial.MaskZScored = MaskZScored;
BootstrapSpatial.MaskZScoredFinal = MaskZScoredFinal; % the aligned version in a 600*800 box
BootstrapSpatial.SpatialBubblesMask = SpatialBubblesMask;
BootstrapSpatial.ReferenceImageFinal = ReferenceImageFinal;

% if ispc
%     [FileName, PathName] = uiputfile('ChooseFileName.mat','Save Profile Z-Score, Percentile and Significance Values','C:\TennisVideosGray\Analysis\');
% else
%     [FileName, PathName] = uiputfile('ChooseFileName.mat','Save Profile Z-Score, Percentile and Significance Values','/users/sepehr/desktop/');  
% end
% if (FileName)
%     filePath = strcat(PathName, FileName);
%     save(filePath,'BootstrapSpatial');
% end

figNameSave = char(strcat(PathName,SelectedFileNames,'.fig'));
savefig(figNameSave);
close all;
%filePath = char(strcat(PathName,fileType, SelectedFileNames,'.mat'));
filePath = char(strcat(PathName, SelectedFileNames,'.mat'));
save(filePath,'BootstrapSpatial');



% meanResponsetime = zeros(1,numTrials);
% for i = 1 : numTrials
%     temp = ResultsExperiment{i};
%     meanResponsetime(i) = temp.responseTime;
%     clear temp;
% end
%*********************************************
% a = [0:1:100];
% b = prctile(MaxDist,a);
% b = PercentileVal;
% figure
% plot([0,121],[b,b],'g-');
% hold on
% plot(MaskZScored,'b:');
% hold on
% plot(ZScoresSums,'r--');
% axis([0 121 -50 50]);
% legend('Significance Values','ZScored Values','Max Values');
% xlabel('Frame Number');
% ylabel('Significance');
% title('Temporal Bubbles');
%grid on

%meanResponsetime = mean(meanResponsetime); % / numTrials;
end