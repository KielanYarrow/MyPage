% Frames selction for temporal bubble stage
% In this code, we find the key frames using statistical analysis of
% participants' responses.
%load('/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/2014851647Sian24fExperimentReturns.mat');

function TemporalBootstrap(ResultsExperiment,numIterations,fileType,SelectedFileNames,PathName)
%PathName = '/users/sepehr/desktop/New Temporal Bootstrap Results/';
%PathName = 'C:\Users\sbbb944\Documents\Work\Sepehr\TennisKL_Results_June2017\Results';
ZScoreThreshold = 1.96;
AimedPercental = 95; % number between 0 and 100: 95%
%numIterations = 2000;
numTrials =size(ResultsExperiment,2);
numCorrect = 0;
numWrong = 0;
for i = 1 : numTrials
    temp = ResultsExperiment{i};
    if (temp.directionCorrect)
        numCorrect = numCorrect + 1;
    else
        numWrong = numWrong +1;
    end
    clear temp;
end
temp = ResultsExperiment{1};
VectorSize = size(temp.FinalValMask);
rng('shuffle');
MasksFinal = zeros(numIterations, VectorSize(2));
for i = 1 : numIterations
    MaskTemp = zeros(VectorSize);
    randomIndices = randperm(numTrials);
    for j = 1 : numCorrect
        temp = ResultsExperiment{randomIndices(j)};
        MaskTemp = MaskTemp + double(temp.FinalValMask);
    end
    for k = numCorrect+1 : numTrials
        temp = ResultsExperiment{randomIndices(k)};
        MaskTemp = MaskTemp - double(temp.FinalValMask);
    end
    MaskTemp = MaskTemp / numTrials;
    MasksFinal(i,:) = MaskTemp;
    clear MaskTemp temp;
end

MeanMasks = mean(MasksFinal,1);
StdMasks = std(MasksFinal,1);

MasksFinalMeanStd = zeros(numIterations, VectorSize(2));
ZscoresFinal = zeros(numIterations, VectorSize(2));
ZscoresFinalLables = zeros(numIterations, VectorSize(2));
ZscoresFinalSums = zeros(numIterations, VectorSize(2));
for i = 1 : numIterations
    MaskTemp = zeros(VectorSize);
    rng('shuffle');
    randomIndices = randperm(numTrials);
    for j = 1 : numCorrect
        temp = ResultsExperiment{randomIndices(j)};
        MaskTemp = MaskTemp + temp.FinalValMask;
    end
    for k = numCorrect+1 : numTrials
        temp = ResultsExperiment{randomIndices(k)};
        MaskTemp = MaskTemp - temp.FinalValMask;
    end
    MaskTemp = MaskTemp / numTrials;
    MaskTemp = MaskTemp - MeanMasks;
    MaskTemp = MaskTemp ./ StdMasks;
    MasksFinalMeanStd(i,:) = MaskTemp;
    % Find Clsuters for each presentation and find the abs(MAX)
    ZScores = zeros(VectorSize);
    ZScoresLabels = zeros(VectorSize);
    ZScoresSums = zeros(VectorSize);
    l = 1;
    breaktag = 0;
    while l <= VectorSize(2)
        sum = 0;
        if (MaskTemp(l) > ZScoreThreshold)
            while ( MaskTemp(l) > ZScoreThreshold)
                ZScores(l) = MaskTemp(l);
                ZScoresLabels(l) = 1;
                sum = sum + MaskTemp(l);
                ZScoresSums(l) = sum;
                if (l < VectorSize(2))
                    l = l+1;
                else
                    breaktag = 1;
                    break;
                end
            end
        else if (abs(MaskTemp(l)) > ZScoreThreshold)
                while (abs(MaskTemp(l)) > ZScoreThreshold)
                    ZScores(l) = MaskTemp(l);
                    ZScoresLabels(l) = -1;
                    sum = sum + MaskTemp(l);
                    ZScoresSums(l) = sum;
                    if (l < VectorSize(2))
                        l = l+1;
                    else
                        breaktag = 1;
                        break;
                    end
                end
            else
                l = l+1;
            end
        end
        if (breaktag)
            l = l+1;
            breaktag =0;
        end
    end
    ZscoresFinal(i,:) = ZScores;
    ZscoresFinalLables(i,:) = ZScoresLabels;
    ZscoresFinalSums(i,:) = ZScoresSums;
    clear MaskTemp temp ;
end
MaxDist = zeros(1,numIterations);
for i = 1 : numIterations
    tempSums = ZscoresFinalSums(i,:);
    tempMax = max(ZscoresFinalSums(i,:));
    tempMin = min(ZscoresFinalSums(i,:));
    %     if (tempMin < 0)
    %         if (abs(tempMin) > tempMax)
    %             MaxDist(i) = tempMin;
    %         else
    %             MaxDist(i) = tempMax;
    %         end
    %     else
    %         MaxDist(i) = tempMax;
    %     end
    MaxDist(i) = max(abs(tempMin),tempMax);
end
PercentileVal = prctile(MaxDist,AimedPercental);
hist(MaxDist,30);
% Now use real responses
MaskTemp = zeros(VectorSize);
for i = 1 : numTrials
    temp = ResultsExperiment{i};
    if (temp.directionCorrect)
        MaskTemp = MaskTemp + temp.FinalValMask;
    else
        MaskTemp = MaskTemp - temp.FinalValMask;
    end
    clear temp;
end

MaskTemp = MaskTemp / numTrials;
MaskTemp = MaskTemp - MeanMasks;
MaskZScored = MaskTemp ./ StdMasks;

MaskTemp = MaskZScored;
ZScores = zeros(VectorSize);
ZScoresLabels = zeros(VectorSize);
ZScoresSums = zeros(VectorSize);
l = 1;
breaktag = 0;
while l <= VectorSize(2)
    sum = 0;
    if (MaskTemp(l) > ZScoreThreshold)
        while ( MaskTemp(l) > ZScoreThreshold)
            ZScores(l) = MaskTemp(l);
            ZScoresLabels(l) = 1;
            sum = sum + MaskTemp(l);
            ZScoresSums(l) = sum;
            if (l < VectorSize(2))
                l = l+1;
            else
                breaktag = 1;
                break;
            end
        end
    else if (abs(MaskTemp(l)) > ZScoreThreshold)
            while (abs(MaskTemp(l)) > ZScoreThreshold)
                ZScores(l) = MaskTemp(l);
                ZScoresLabels(l) = -1;
                sum = sum + MaskTemp(l);
                ZScoresSums(l) = sum;
                if (l < VectorSize(2))
                    l = l+1;
                else
                    breaktag = 1;
                    break;
                end
            end
        else
            l = l+1;
        end
    end
    if (breaktag)
        l = l+1;
        breaktag =0;
    end
end

for i = 1 : size(MaskTemp,2)
    tempMax = max(ZscoresFinalSums(i,:));
    tempMin = min(ZscoresFinalSums(i,:));
    %     if (tempMin < 0)
    %         if (abs(tempMin) > tempMax)
    %             MaxDist(i) = tempMin;
    %         else
    %             MaxDist(i) = tempMax;
    %         end
    %     else
    %         MaxDist(i) = tempMax;
    %     end
    MaxDist(i) = max(abs(tempMin),tempMax);
    
end

% a = [0:1:100];
% b = prctile(MaxDist,a);
b = PercentileVal;
figure
plot([0,121],[b,b],'g-');
hold on
plot(MaskZScored,'b:');
hold on
plot(ZScoresSums,'r--');
axis([0 121 -50 50]);
legend('Significance Values','ZScored Values','Max Values');
xlabel('Frame Number');
ylabel('Significance');
title('Temporal Bubbles');
%grid on
% % meanResponsetime = zeros(1,numTrials);
% % for i = 1 : numTrials
% %     temp = ResultsExperiment{i};
% %     meanResponsetime(i) = temp.responseTime;
% %     clear temp;
% % end
BootstrapTemporal.PercentileVal = PercentileVal;
BootstrapTemporal.MaskZScored = MaskZScored;
BootstrapTemporal.ZScoresSums = ZScoresSums;
BootstrapTemporal.MaxDist = MaxDist;
% uiputfile(FilterSpec,DialogTitle,DefaultName)
%[file,path] = uiputfile('animinit.m','Save file name');
% % % if ispc
% % %     [FileName, PathName] = uiputfile('ChooseFileName.mat','Save Profile Z-Score, Percentile and Significance Values','C:\TennisVideosGray\Analysis\');
% % % else
% % %     [FileName, PathName] = uiputfile('ChooseFileName.mat','Save Profile Z-Score, Percentile and Significance Values','/users/sepehr/desktop/');
% % % end
% % % if (FileName)
% % %     filePath = strcat(PathName, FileName);
% % %     save(filePath,'BootstrapTemporal');
% % % end



%figNameSave = char(strcat(PathName,fileType,SelectedFileNames,'.fig'));
figNameSave = char(strcat(PathName,SelectedFileNames,'.fig'));
savefig(figNameSave);
close all;
%filePath = char(strcat(PathName,fileType, SelectedFileNames,'.mat'));
filePath = char(strcat(PathName, SelectedFileNames,'.mat'));
save(filePath,'BootstrapTemporal');


% uiputfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
%           '*.*','All Files' },'Save Image',...
%           'C:\Work\newfile.jpg')

end
%meanResponsetime = mean(meanResponsetime); % / numTrials;