% In this function the spatial masks and background images are alligend
% according to the selected reference point. the output is a cell
% containing 384 alligned masks and the overlapped reference image. 
function [alignedMasksFinal, ReferenceImageFinal] = SpatialMasksAlignment(ResultsExperiment,ReferencePoint,PosInfo,PicLocation)
% first zeros are added around the mask, to make it 400 by 600 ( using the
% coordinates system)
%then the videos are normalized around the selected reference point
%then the masks are aligned around the selected reference point
temp = ResultsExperiment{1};
trialType = temp.Type;
clear temp;
for i = 1 : size(ResultsExperiment,2)
    emptryMask = zeros(400,600);
    if trialType == 'R'
        temp = ResultsExperiment{i};
        tempMask = temp.FinalValMask;
        emptryMask(67:291,67:531) = tempMask;
        extendedMasks{i} = emptryMask;
        %SelectedVideoNames{i} = temp.VideoName(21:26);
        SelectedVideoNames{i} = temp.VideoName(end-13:end-8);

    else
        temp = ResultsExperiment{i};
        tempMask = temp.FinalValMask;
        emptryMask(7:271,127:471) = tempMask;
        extendedMasks{i} = emptryMask;
        SelectedVideoNames{i} = temp.VideoName(end-13:end-8);
    end
end

AlignedMasks = SpatialAlignmentReferencePoint(SelectedVideoNames,extendedMasks, ReferencePoint, PosInfo);
%AlignedMasks = SpatialAlignmentReferencePointFrameSixty(SelectedVideoNames,extendedMasks, ReferencePoint);

%%%%%%%%
for i = 1 : size(SelectedVideoNames,2)
    videoName = SelectedVideoNames{i}; % find the video name
    %if ~strcmp(videoName,'RIL-61') && ~strcmp(videoName,'RIL-63') && ~strcmp(videoName,'RIL-66')
%         if ispc
%             frameName = strcat('C:\TennisVideosGray\Frames\contactFrame',videoName,'.jpg');
%         else
%             frameName = strcat('/Users/sepehr/Dropbox/Bubbles Codes/Frames/contactFrame',videoName,'.jpg');
%         end
        frameName = strcat(PicLocation,'contactFrame',videoName,'.jpg');

        tempImage = imread(frameName);
        frameImages{i} = tempImage(161:560,241:840);
    %end
end

ReferenceImage = SpatialAlignmentReferencePoint(SelectedVideoNames,frameImages, ReferencePoint,PosInfo);
%ReferenceImage = SpatialAlignmentReferencePointFrameSixty(SelectedVideoNames,frameImages, ReferencePoint);



temp2 = ReferenceImage{1};
temp = zeros(size(temp2));
for i = 1 : size(ReferenceImage,2)
    tempFrame = ReferenceImage{i};
    temp = tempFrame + temp;
end
[lowerTemp, higherTemp] = find(temp);
tempHlower = min(min(lowerTemp));
tempHhigher = max(max(lowerTemp));
tempWlower = min(min(higherTemp));
tempWhigher = max(max(higherTemp));
tempHlength = tempHhigher - tempHlower;
tempWlength = tempWhigher - tempWlower;
tempHmean = uint8(tempHlower + tempHlength /2);
tempWmean = uint8(tempWlower + tempWlength / 2);
startingPointH = round((600 - tempHlength) / 2);
startingPointW = round((800 - tempWlength) / 2);
%fullMask = uint8(fullMask / 24);

for i = 1 : size(AlignedMasks,2)
    tempReferencePoint = ReferenceImage{i};
    tempFinal = zeros(600,800);
    tempFinal(startingPointH : startingPointH + tempHlength - 1 , startingPointW : startingPointW + tempWlength - 1 ) = tempReferencePoint (tempHlower : tempHhigher-1 ,tempWlower : tempWhigher - 1); 
    ReferenceImageFinal{i} = tempFinal;
end

% 
% temp2 = ReferenceImage{1};
% temp = zeros(size(temp2));
% for i = 1 : size(ReferenceImage,2)
%     tempFrame = ReferenceImage{i};
%     temp = tempFrame + temp;
% end
% [lowerTemp2, higherTemp2] = find(temp);
% tempHlower2 = min(min(lowerTemp2));
% tempHhigher2 = max(max(lowerTemp2));
% tempWlower2 = min(min(higherTemp2));
% tempWhigher2 = max(max(higherTemp2));
% tempHmean2 = uint8((tempHlower2 + tempHhigher2) /2);
% tempWmean2 = uint8((tempWlower2 + tempWhigher2) / 2);
% tempHlength2 = tempHhigher2 - tempHlower2;
% tempWlength2 = tempWhigher2 - tempWlower2;
% startingPointH2 = round((600 - tempHlength2) / 2);
% startingPointW2 = round((800 - tempWlength2) / 2);
% %fullMask = uint8(fullMask / 24);

for i = 1 : size(AlignedMasks,2)
    tempReferencePoint = AlignedMasks{i};
    tempFinal = zeros(600,800);
    tempFinal(startingPointH : startingPointH + tempHlength - 1 , startingPointW : startingPointW + tempWlength - 1 ) = tempReferencePoint (tempHlower : tempHhigher-1 ,tempWlower : tempWhigher - 1); 

    alignedMasksFinal{i} = tempFinal;
end

end







