%Script to implement permutation cluster/pixel test for temporal classification sequences 
%which have been obtained from two groups of participants.
%Identifies regions of difference between the groups (equivalent to independent-sample
%t-test). Marks up only signifant regions, but provides p
%values for all clusters (significant or not).

% Note on data -
% Each participant's data should be in a .mat file, with all .mat files in
% a single folder (for which you must provide the path, below). Within the mat file, the classification sequence is
% currently assumed to be stored in one field of a particular structure: BootstrapTemporal.MaskZScored
% (but this could be changed below if you've called it something different)

% Note on clustering - 
% Cluster distribution based on largest absolute cluster on each
% permutation, so only the positive tail is relevant. Use 5% cut for
% two-tailed (approximately, you can divide exact p by 2 or use 10% cut for
% one-tailed).

% One more note -
% Commenting here is less complete than for the permutationVsZero script,
% look there for some further explanation alongside code.

groupLevel = '1'; %This can be used to pull out just a subset of the data in the folder
%based on whether there is a particular number at a particular position
%in the file name (see below).

numIterations = 1999; %Number of permutations used to form null distribution
AimedPercental = 95; % Point on distribution considered significant
ttestP = 0.05; % data points are considered part of a cluster when they exceed
%some arbitrary level of significance, set here (two-tailed)
ZScoreThreshold = 0; %alternative cluster threshold, now used only for categorising 
%clusters as positive or negative

storyboard = 1;
% Set an image file to display a timeline of video frames along the top of
% the results figure
if storyboard
    BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ServesBGTemporal.png');
    %BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ReturnsBGTemporal.png');
end

%Must indicate WHERE THE DATA CAN BE FOUND here: 

filePath = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\Temporal\Bootstrap Results\Serves\All\Mat Files\';
%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Serves/All/Mat Files/';
%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Returns/All/All Participants/';

filesListtemp = dir(fullfile(filePath));
filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

counter = 1;
%Create a list of file names, with those in group 1 first, then those in
%group 2 aftewards
namesList = {};
for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))
        if strcmp(tempName(end-2:end),'mat') % rule out non mat files
            if ~(strcmp(tempName(end-4), groupLevel)) % Pick out files of just one group, based on file name 
            %if ~isempty(strfind(tempName,'FAST10')) 
                namesList{counter} = tempName(1:end-4);            
                counter = counter + 1;
            end
        end
    end
end

numGroupOne = counter - 1;

for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))
        if strcmp(tempName(end-2:end),'mat') % rule out non mat files
            if (strcmp(tempName(end-4), groupLevel)) % Pick out files of a different group, based on file name
            %if  ~isempty(strfind(tempName,'SLOW10'))
                namesList{counter} = tempName(1:end-4);            
                counter = counter + 1;
            end
        end
    end
end

numGroupTwo = counter - numGroupOne - 1;

for i = 1 : size(namesList,2)
    temp = namesList{i};
    tempPath = strcat(filePath,temp,'.mat');
    load(tempPath);
    masksFinal(i,:) = BootstrapTemporal.MaskZScored; %Load in each participant's classification sequence
end

rng('shuffle');
for j = 1 : numIterations
    indices1 = randperm(size(masksFinal,1));
    index = 0;
    
    for i = 1 : numGroupOne
        temp1 = masksFinal(indices1(i),:);
        masksFinalTossed1(i,:) = temp1;        
        index = index + 1;
    end
    for i = 1 : numGroupTwo
        temp2 = masksFinal(indices1(index),:);
        masksFinalTossed2(i,:) = temp2;
        index = index + 1;
    end
    
    [h,p,ci,stats] = ttest2(masksFinalTossed1,masksFinalTossed2,'Alpha',ttestP);
    
    ttestResults(j,:) = stats.tstat;
    ttestSignificance(j,:) = h;
    ttestResultsFinal(j,:) = ttestResults(j,:) .* ttestSignificance(j,:);
    
    ExtremeVal(j) = max(abs(ttestResults(j,:))); %record single most extreme t value 
    
end

maxVal = zeros(numIterations,1);
minVal = zeros(numIterations,1);

for i = 1 : numIterations
    for j = 1 : size(ttestResults,2)
        tempMaxVal = 0;
        tempMinVal = 0;
        index = j;
        while ttestSignificance(i,index) > 0
            if ttestResultsFinal(i,index) > ZScoreThreshold
                tempMaxVal = tempMaxVal + ttestResultsFinal(i,index); 
                index = index + 1;
                if index > size(ttestResults,2)
                    break;
                end
            elseif ttestResultsFinal(i,index) < -ZScoreThreshold
                tempMinVal = tempMinVal + ttestResultsFinal(i,index);
                index = index + 1;
                if index > size(ttestResults,2)
                    break;
                end
            end
        end
        if tempMaxVal > maxVal(i)
           maxVal(i) = tempMaxVal;
        end
        if tempMinVal < minVal(i)
           minVal(i) = tempMinVal;
        end
    end
end

maxValFinal = zeros(numIterations,1); %Keeping most extreme cluster
for i = 1 : numIterations
    if maxVal(i) > abs(minVal(i))
        maxValFinal(i) = maxVal(i);
    else
        maxValFinal(i) = abs(minVal(i));
    end
end

PercentileVal = prctile(maxValFinal,AimedPercental);

PercentileValPixel = prctile(ExtremeVal,AimedPercental);

% NOW THE REAL DATA
for i = 1 : numGroupOne
    temp = masksFinal(i,:);
    masksFinalUnTossed1(i,:) = temp;
end
for i = numGroupOne + 1 : numGroupOne + numGroupTwo
    temp = masksFinal(i,:);
    masksFinalUnTossed2(i-numGroupOne,:) = temp;
end
[h,p,ci,stats] = ttest2(masksFinalUnTossed1,masksFinalUnTossed2,'Alpha',ttestP);
ttestResultsUnMask = stats.tstat;
ttestSignificanceUnMask = h;
ttestResultsUnMaskFinal = ttestResultsUnMask .* ttestSignificanceUnMask;

maxValsFinal = zeros(1,size(ttestResultsUnMask,2));
minValsFinal = zeros(1,size(ttestResultsUnMask,2));
index = 1;
while index < size(ttestResultsUnMask,2)
        tempMaxVal = 0;
        tempMinVal = 0;
%index = j;
        while ttestSignificanceUnMask(index) > 0
            if ttestResultsUnMaskFinal(index) > ZScoreThreshold
                tempMaxVal = tempMaxVal + ttestResultsUnMaskFinal(index); 
                maxValsFinal(index) = tempMaxVal;
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            elseif ttestResultsUnMaskFinal(index) < -ZScoreThreshold
                tempMinVal = tempMinVal + ttestResultsUnMaskFinal(index); 
                minValsFinal(index) = tempMinVal;
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            end            
        end
        index = index + 1;

end

ValFinal = zeros(size(ttestResultsUnMask,2),1);
for i = 1 : size(ttestResultsUnMask,2)
    if maxValsFinal(i) > abs(minValsFinal(i))
        ValFinal(i) = maxValsFinal(i);
    else
        ValFinal(i) = abs(minValsFinal(i));
    end
end


%**********CALCULATE P-VALUE
j = 1;
index = 1;
maxValsforPercentile = [];

while index <= size(ValFinal,1)
    tempVal = 0;
    while abs(ValFinal(index)) > ZScoreThreshold
        tempVal = ValFinal(index);
        index = index + 1;
        if index > size(ValFinal,1)
            break;
        end;
    end
    if abs(tempVal) > 0 
       %if (tempVal > PercentileVal) % uncommenting this
       %condition here considers only the significant clusters for
       %p-Value calculation. 
           maxValsforPercentile(j) = ValFinal(index - 1);
           j = j+1;
       %else
           index = index + 1;
       %end
    else
        index = index + 1;
    end
end

for i = 1 : size(maxValsforPercentile,2) %for each cluster in the data
    pValue(i) = (sum(maxValFinal>maxValsforPercentile(i))+1)./(numIterations+1);
end

%***************************
ValFinal = ValFinal';

maxValsFinal2 = zeros(size(ValFinal));
maxValsFinal3 = (ttestResultsUnMask > PercentileValPixel); % true/false on pixel test

for i = 1 : size(ValFinal,1)
    if ValFinal(1,i) > PercentileVal
        maxValsFinal2(1,i) = 1;        
        tempindex = i-1;
        while tempindex > 1
            if abs(ValFinal(1,tempindex)) > 0
                maxValsFinal2(1,tempindex) = 1;
                           
            else
                break;
            end
            tempindex = tempindex - 1;
        end    
    end
end

averageGroup1 = mean(masksFinalUnTossed1);
averageGroup2 = mean(masksFinalUnTossed2);
theDiff = averageGroup1 - averageGroup2;
tt = theDiff;
tempA = (std(masksFinalUnTossed1).^2 ) / size(masksFinalUnTossed1,1);
tempB = (std(masksFinalUnTossed2).^2 ) / size(masksFinalUnTossed2,1);
ttt = sqrt(tempA + tempB);
ttt = ttt * tinv(1-(ttestP/2),numGroupTwo + numGroupOne -2);

figure

if storyboard %Add a timeline of video shots if one has been loaded
    
    subplot(5,1,1)
    imshow(BGImage);

    subplot(5,1,[2,3])
    
else
    
    subplot(2,1,1)

end

plot(averageGroup1)
hold on
plot(averageGroup2)
axis([-5 126 min(min([min(averageGroup1) min(averageGroup2)]))-1 max([max(averageGroup1) max(averageGroup2)])+1]);
legend('Group 1','Group 2');
xlabel('Frame Number');
ylabel('Classification sequence intensity');
title('Both groups');

if storyboard
    
    subplot(5,1,[4,5])
    
else
    
    subplot(2,1,2)
    
end


errorbar(tt,ttt);
hold on
plot(maxValsFinal3,'y--');% show significant pixels
plot(maxValsFinal2,'r--');% show significant clusters 
axis([-5 126 min(min(theDiff))-1 max(max(theDiff))+1]);
legend('Mean Z-Scored Classification Profile difference','Pixel Significance','Clusters Significance');
xlabel('Frame Number');
ylabel('Classification sequence intensity');
title('Permutation test Results');


% Save some key stuff with a sensible name. Change the name of this for
% each analysis to avoid overwriting data.

ServesG1vG2.meanClassificationSequence = tt;
ServesG1vG2.CIonSequence = ttt;
ServesG1vG2.clusterSig = maxValsFinal2;
ServesG1vG2.pixelSig = maxValsFinal3;
ServesG1vG2.eachClusterP = pValue;
ServesG1vG2.clustersIntegral = ValFinal;
ServesG1vG2.clusterNullDist = sort(maxValFinal);
ServesG1vG2.pixelNullDist = sort(ExtremeVal);
ServesG1vG2.AllParticipantsClassificationSequences = masksFinal;
ServesG1vG2.eachClusterSize = maxValsforPercentile;

%clear up the workspace

clear AimedPercental BootstrapTemporal ci counter ExtremeVal filePath ...
    filesList groupLevel h i index irrelevant j masksFinal masksFinalTossed1 ...
    masksFinalUnTossed1 maxVal maxValFinal maxValsFinal maxValsFinal2 maxValsFinal3 ...
    maxValsforPercentile maxValUnBiased minVal minValsFinal numIterations p ...
    PercentileVal PercentileValPixel pValue pValueindex stats storyboard temp ...
    temp1 temp2 tempA tempB theDiff tempindex tempMaxVal tempMinVal tempName tempPath tempVal tempzeroMatrix ...
    tt ttestP ttestResults ttestResultsUnMask ttestSignificance  ...
    ttt ValFinal ZScoreThreshold averageGroup1 averageGroup2 indices1 ...
    masksFinalTossed2 masksFinalUnTossed2 ttestResultsFinal ttestResultsUnMaskFinal ttestSignificanceUnMask


