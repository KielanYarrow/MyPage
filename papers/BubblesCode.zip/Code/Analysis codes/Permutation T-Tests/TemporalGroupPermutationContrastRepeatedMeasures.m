%Script to implement permutation cluster/pixel test for temporal classification sequences 
%which have been obtained from one groups of participants in two different conditions.
%Identifies regions of difference between the conditions (equivalent to paired-sample
%t-test). Marks up only signifant regions, but provides p
%values for all clusters (significant or not).

% Note on data -
% Each participant's data should be in a .mat file, with all .mat files in
% two separate folders (for which you must provide the paths, below). Within the mat file, the classification sequence is
% currently assumed to be stored in one field of a particular structure: BootstrapTemporal.MaskZScored
% (but this could be changed below if you've called it something different)

% Note on clustering - 
% Cluster distribution based on largest absolute cluster on each
% permutation, so only the positive tail is relevant. Use 5% cut for
% two-tailed (approximately, you can divide exact p by 2 or use 10% cut for
% one-tailed).

% One more note -
% Commenting here is less complete than for the permutationVsZero script,
% look there for some further explanation alongside code.

numIterations = 1999; %Number of permutations used to form null distribution
AimedPercental = 95; % Point on distribution considered significant
ttestP = 0.05; % data points are considered part of a cluster when they exceed
%some arbitrary level of significance, set here (two-tailed)
ZScoreThreshold = 0; %alternative cluster threshold, now used only for categorising 
%clusters as positive or negative

storyboard = 1;
% Set an image file to display a timeline of video frames along the top of
% the results figure
if storyboard
    %BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ServesBGTemporal.png');
    BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ReturnsBGTemporal.png');
end

%Must indicate WHERE THE DATA CAN BE FOUND here: 

%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Returns/';
filePath = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\Temporal\Bootstrap Results\Returns\'; %Lines/All Participants/';
c1 = 'Player 1\Mat Files\';
c2 = 'Player 3\Mat Files\';

%Condition 1
filesListtemp = dir(fullfile(strcat(filePath,c1))); %*******

filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

namesList = {};
counter = 1;
for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))        
        if ~isempty(strfind(tempName,'mat')) %check it's a .mat file
            namesList{counter} = tempName(1:end-4);
            
            counter = counter + 1;
        end
    end
end
numGroupOne = counter - 1;

%Condition 2
filesListtemp = dir(fullfile(strcat(filePath,c2))); %********

filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))         
        if ~isempty(strfind(tempName,'mat')) %check it's a .mat file
            namesList{counter} = tempName(1:end-4);
            
            counter = counter + 1;
        end
    end
end
numGroupTwo = counter - numGroupOne - 1;

if numGroupOne ~= numGroupTwo
    error('Conditions have different numbers of files / data points')
end

for i = 1 : numGroupOne %********************************************************************
    temp = namesList{i};
    tempPath = strcat(filePath,c1,temp,'.mat');
    load(tempPath);
    masksFinal(i,:) = BootstrapTemporal.MaskZScored;
end
for i = 1 : numGroupTwo
    temp = namesList{i + numGroupOne};
    tempPath = strcat(filePath,c2,temp,'.mat');
    load(tempPath);
    masksFinal(i + numGroupOne,:) = BootstrapTemporal.MaskZScored;
end
masksFinalSub = masksFinal(1:numGroupOne,:) - masksFinal(numGroupOne+1:end,:);

rng('shuffle');

for j = 1 : numIterations
    for i = 1 : size(masksFinalSub,1)
        temp = masksFinalSub(i,:);
        if rand(1,1) < 0.5
            temp = -temp;
        end
        masksFinalTossed(i,:) = temp;
    end
    [h,p,ci,stats] = ttest(masksFinalTossed,zeros(size(masksFinalTossed,1),size(masksFinalTossed,2)),'Alpha',ttestP);%,'Tail','right','Alpha',0.05,'Vartype','unequal');
    ttestResults(j,:) = stats.tstat;
    ttestSignificance(j,:) = h;
    ttestResultsFinal(j,:) = ttestResults(j,:) .* ttestSignificance(j,:);
    ExtremeVal(j) = max(abs(ttestResults(j,:))); %record single most extreme t value 
end

maxVal = zeros(numIterations,1);
minVal = zeros(numIterations,1);

for i = 1 : numIterations
    for j = 1 : size(ttestResults,2)
        tempMaxVal = 0;
        tempMinVal = 0;
        index = j;
        while ttestSignificance(i,index) > 0
            if ttestResults(i,index) > ZScoreThreshold
                tempMaxVal = tempMaxVal + ttestResults(i,index); 
                index = index + 1;
                if index > size(ttestResults,2)
                    break;
                end
            elseif ttestResults(i,index) < -ZScoreThreshold
                tempMinVal = tempMinVal + ttestResults(i,index);
                index = index + 1;
                if index > size(ttestResults,2)
                    break;
                end
            end
        end
        if tempMaxVal > maxVal(i)
           maxVal(i) = tempMaxVal;
        end
        if tempMinVal < minVal(i)
           minVal(i) = tempMinVal;
        end
    end
end

maxValFinal = zeros(numIterations,1);
for i = 1 : numIterations
    if maxVal(i) > abs(minVal(i))
        maxValFinal(i) = maxVal(i);
    else
        maxValFinal(i) = abs(minVal(i));
    end
end

PercentileVal = prctile(maxValFinal,AimedPercental);

PercentileValPixel = prctile(ExtremeVal,AimedPercental);

for i = 1 : numGroupOne
    temp = masksFinal(i,:);
    masksFinalUnTossed1(i,:) = temp;
end
for i = numGroupOne + 1 : numGroupOne + numGroupTwo
    temp = masksFinal(i,:);
    masksFinalUnTossed2(i-numGroupOne,:) = temp;
end
masksFinalUnTossed = masksFinalUnTossed1 - masksFinalUnTossed2;
[h,p,ci,stats] = ttest(masksFinalUnTossed, zeros(size(masksFinalUnTossed,1),size(masksFinalUnTossed,2)),'Alpha',ttestP);
ttestResultsUnMask = stats.tstat;
ttestSignificanceUnMask = h;
ttestResultsUnMaskFinal = ttestResultsUnMask .* ttestSignificanceUnMask;

maxValsFinal = zeros(1,size(ttestResultsUnMask,2));
minValsFinal = zeros(1,size(ttestResultsUnMask,2));
index = 1;
while index < size(ttestResultsUnMask,2)
        tempMaxVal = 0;
        tempMinVal = 0;
%index = j;
        while ttestSignificanceUnMask(index) > 0
            if ttestResultsUnMaskFinal(index) > ZScoreThreshold
                tempMaxVal = tempMaxVal + ttestResultsUnMaskFinal(index); 
                maxValsFinal(index) = tempMaxVal;
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            elseif ttestResultsUnMaskFinal(index) < -ZScoreThreshold
                tempMinVal = tempMinVal + ttestResultsUnMaskFinal(index); 
                minValsFinal(index) = tempMinVal;
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            end
        end
        index = index + 1;
end

ValFinal = zeros(size(ttestResultsUnMask,2),1);
for i = 1 : size(ttestResultsUnMask,2)
    if maxValsFinal(i) > abs(minValsFinal(i))
        ValFinal(i) = maxValsFinal(i);
    else
        ValFinal(i) = abs(minValsFinal(i));
    end
end

%**********CALCULATE P-VALUE
j = 1;
index = 1;
maxValsforPercentile = [];

while index <= size(ValFinal,1)
    tempVal = 0;
    while abs(ValFinal(index)) > 0
        tempVal = ValFinal(index);
        index = index + 1;
        if index > size(ValFinal,1)
            break;
        end;
    end
    if abs(tempVal) > 0
       %if (tempVal > PercentileVal || tempVal < PercentileValNeg) % uncommenting this
       %condition here considers only the significant clusters for 
       %p-Value calculation. 
           maxValsforPercentile(j) = ValFinal(index - 1);
           j = j+1;
       %else
           index = index + 1;
       %end
    else
        index = index + 1;
    end
end

for i = 1 : size(maxValsforPercentile,2) %for each cluster in the data
    pValue(i) = (sum(maxValFinal>maxValsforPercentile(i))+1)./(numIterations+1);
end
%*****

ValFinal = ValFinal';
maxValsFinal2 = zeros(size(ValFinal));
maxValsFinal3 = (ttestResultsUnMask > PercentileValPixel); % true/false on pixel test

for i = 1 : size(ValFinal,1)
    if ValFinal(1,i) > PercentileVal
        maxValsFinal2(1,i) = 1;        
        tempindex = i-1;
        while tempindex > 1
            if abs(ValFinal(1,tempindex)) > 0
                maxValsFinal2(1,tempindex) = 1;
                           
            else
                break;
            end
            tempindex = tempindex - 1;
        end    
    end
end


theDiff = masksFinalUnTossed1 - masksFinalUnTossed2;
averageGroup1 = mean(masksFinalUnTossed1);
averageGroup2 = mean(masksFinalUnTossed2);

tt =  mean(theDiff);
ttt = (std(theDiff)) ./ sqrt(size(theDiff,1));
ttt = ttt * tinv(1-(ttestP/2),size(theDiff,1)-1);

figure

if storyboard %Add a timeline of video shots if one has been loaded
    
    subplot(5,1,1)
    imshow(BGImage);

    subplot(5,1,[2,3])
    
else
    
    subplot(2,1,1)

end

plot(averageGroup1)
hold on
plot(averageGroup2)
axis([-5 126 min(min([min(averageGroup1) min(averageGroup2)]))-1 max([max(averageGroup1) max(averageGroup2)])+1]);
legend('Condition 1','Condition 2');
xlabel('Frame Number');
ylabel('Classification sequence intensity');
title('Both conditions');

if storyboard
    
    subplot(5,1,[4,5])
    
else
    
    subplot(2,1,2)
    
end


errorbar(tt,ttt);
hold on
plot(maxValsFinal3,'y--');% show significant pixels
plot(maxValsFinal2,'r--');% show significant clusters 
axis([-5 126 min(min(theDiff))-1 max(max(theDiff))+1]);
legend('Mean Z-Scored Classification Profile difference','Pixel Significance','Clusters Significance');
xlabel('Frame Number');
ylabel('Classification sequence intensity');
title('Permutation test Results');


% Save some key stuff with a sensible name. Change the name of this for
% each analysis to avoid overwriting data.

ReturnsC1vC2.meanClassificationSequence = tt;
ReturnsC1vC2.CIonSequence = ttt;
ReturnsC1vC2.clusterSig = maxValsFinal2;
ReturnsC1vC2.pixelSig = maxValsFinal3;
ReturnsC1vC2.eachClusterP = pValue;
ReturnsC1vC2.clustersIntegral = ValFinal;
ReturnsC1vC2.clusterNullDist = sort(maxValFinal);
ReturnsC1vC2.pixelNullDist = sort(ExtremeVal);
ReturnsC1vC2.AllParticipantsClassificationSequences = masksFinalUnTossed;
ReturnsC1vC2.eachClusterSize = maxValsforPercentile;

%clear up the workspace

clear AimedPercental BootstrapTemporal ci counter ExtremeVal filePath ...
    filesList groupLevel h i index irrelevant j masksFinal masksFinalTossed1 ...
    masksFinalUnTossed1 maxVal maxValFinal maxValsFinal maxValsFinal2 maxValsFinal3 ...
    maxValsforPercentile maxValUnBiased minVal minValsFinal numIterations p ...
    PercentileVal PercentileValPixel pValue pValueindex stats storyboard temp ...
    temp1 temp2 tempA tempB theDiff tempindex tempMaxVal tempMinVal tempName tempPath tempVal tempzeroMatrix ...
    tt ttestP ttestResults ttestResultsUnMask ttestSignificance  ...
    ttt ValFinal ZScoreThreshold averageGroup1 averageGroup2 indices1 ...
    masksFinalTossed masksFinalUnTossed ttestResultsFinal ttestResultsUnMaskFinal ttestSignificanceUnMask ...
    c1 c2 

