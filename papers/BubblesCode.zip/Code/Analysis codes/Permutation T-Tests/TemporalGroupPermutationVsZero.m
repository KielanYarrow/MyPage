
%Script to implement permutation cluster/pixel test for temporal classification sequences 
%which have been obtained from a group of participants.
%Identifies regions of significant information (equivalent to one-sample
%t-test vs. 0). Marks up only signifant positive regions, but provides p
%values for all clusters (positive or negative, significant or not).

% Note on data -
% Each participant's data should be in a .mat file, with all .mat files in
% a single folder (for which you must provide the path, below). Within the mat file, the classification sequence is
% currently assumed to be stored in one field of a particular structure: BootstrapTemporal.MaskZScored
% (but this could be changed below if you've called it something different)

% Note on clustering - 
% Cluster distribution based on largest absolute cluster on each
% permutation, so only the positive tail is relevant. Use 5% cut for
% two-tailed (approximately, you can divide exact p by 2 or use 10% cut for
% one-tailed).

groupLevel = '1'; %This can be used to pull out just a subset of the data in the folder
%based on whether there is a particular number at a particular position
%in the file name (see below).

numIterations = 1999; %Number of permutations used to form null distribution
AimedPercental = 95; % Point on distribution considered significant
ttestP = 0.05; % data points are considered part of a cluster when they exceed
%some arbitrary level of significance, set here (two-tailed)
ZScoreThreshold = 0; %alternative cluster threshold, now used only for categorising 
%clusters as positive or negative

storyboard = 1;
% Set an image file to display a timeline of video frames along the top of
% the results figure
if storyboard
    BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ServesBGTemporal.png');
    %BGImage = imread('C:\Users\sbbb944\Documents\Work\Sepehr\E123\ReturnsBGTemporal.png');
end

%Must indicate WHERE THE DATA CAN BE FOUND here:

%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Returns/All/Mat Files/';
%filePath = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\Temporal\Bootstrap Results\Returns\All\Mat Files\';
filePath = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\Temporal\Bootstrap Results\Serves\All\Mat Files\';
%filePath = '/Users/sepehr/Dropbox/New Data UptoBCPoint/Temporal/Serves/';
%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Serves/All/All Participants/';
%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Serves/Player 3/Mat Files/';

%find files in results folder
filesListtemp = dir(fullfile(filePath));
%throw away weird "." and ".." bits of list
filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

%Create list of names of relevant files
namesList = {};
counter = 1;
for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;    
    if ~strcmp(tempName,'.DS_Store') %don't include Mac info files
        %One of these lines (and the corresponding end statement) CAN BE UNCOMMENTED FOR when e.g. group
        %expertise is considered (assuming this is indicated in the file
        %names, e.g. by a number at the end, or the inclusion of a string)
        %if (strcmp(tempName(end-4), groupLevel)) % for experts group add ~. 
        %if ~isempty(strfind(tempName,'Level2')) ||  ~isempty(strfind(tempName,'Level3'))
        if ~isempty(strfind(tempName,'mat')) %check it's a .mat file
            namesList{counter} = tempName(1:end-4); %name minus file extension            
            counter = counter + 1;
        end
        %end
    end
end

for i = 1 : size(namesList,2) %for each participant's data
    temp = namesList{i};
    tempPath = strcat(filePath,temp,'.mat');
    load(tempPath); %load it in
    masksFinal(i,:) = BootstrapTemporal.MaskZScored; %get classfication sequence
end
            %IF YOUR CLASSIFICATION SEQUENCE DATA IS STORED IN A VARIABLE WITH A DIFFERENT NAME
            %YOU NEED TO PUT IT HERE ^^^^^
            
%prepare storage for pixels
ExtremeVal = zeros(numIterations,1);

%Now repeatedly permute the data to establish null distributions
rng('shuffle');
for j = 1 : numIterations
    for i = 1 : size(masksFinal,1)
        temp = masksFinal(i,:);
        if rand(1,1) < 0.5
            temp = -temp;
        end
        masksFinalTossed(i,:) = temp;
    end
    %t-test vs. zero at each time point
    tempzeroMatrix = zeros(size(masksFinalTossed));
    [h,p,ci,stats] = ttest(masksFinalTossed,tempzeroMatrix,'Alpha',ttestP);
    ttestResults(j,:) = stats.tstat; %record vector of t-stats for this iteration
    ttestSignificance(j,:) = h; %and whether they were significant
    ExtremeVal(j) = max(abs(ttestResults(j,:))); %record single most extreme t value
end

%Now prepare storage for clusters
maxVal = zeros(numIterations,1);
minVal = zeros(numIterations,1);

for i = 1 : numIterations
    for j = 1 : size(ttestResults,2) %starting from each time point
        tempMaxVal = 0;
        tempMinVal = 0;
        index = j;
        %look for a contiguous region... 
        while ttestSignificance(i,index) > 0 %where each point exceeds the cluster threshold
            if ttestResults(i,index) > ZScoreThreshold %if it's a positive cluster
                tempMaxVal = tempMaxVal + ttestResults(i,index); % increment the total score for this cluster                
                index = index + 1;
                if index > size(ttestResults,2) %escape if we've reached the final time point
                    break;
                end
            elseif ttestResults(i,index) < -ZScoreThreshold %(same steps for a negative cluster)
                tempMinVal = tempMinVal + ttestResults(i,index);
                index = index + 1;
                if index > size(ttestResults,2)
                    break;
                end
            end
        end
        if tempMaxVal > maxVal(i) %keep it if it's the biggest cluster score so far
           maxVal(i) = tempMaxVal;
        end
        if tempMinVal < minVal(i) %or the most extreme negative cluster score so far
           minVal(i) = tempMinVal;
        end
    end
end

maxValFinal = zeros(numIterations,1);

for i = 1 : numIterations %keep only the most extreme value, positive or negative, for the null distribution of clusters
    if maxVal(i) > abs(minVal(i))
        maxValFinal(i) = maxVal(i);
    else
        maxValFinal(i) = abs(minVal(i));
    end
end

%find the critical value (cluster score) from the null distribution
PercentileVal = prctile(maxValFinal,AimedPercental);
%find the critical value (pixel score) from the null distribution
PixelPercentileVal = prctile(ExtremeVal,AimedPercental);

for i = 1 : size(masksFinal,1) %Overly complex and pointless name change for unpermuted data
    temp = masksFinal(i,:);
    masksFinalUnTossed(i,:) = temp;
end

%Apply the same process that was applied to permuted data to find clusters
%in the real data
tempzeroMatrix = zeros(size(masksFinalUnTossed));
[h,p,ci,stats] = ttest(masksFinalUnTossed,tempzeroMatrix,'Alpha',ttestP);
ttestResultsUnMask = stats.tstat;
ttestSignificanceUnMask = h;
maxValUnBiased = 0;
maxValsFinal = zeros(1,size(ttestResultsUnMask,2));
minValsFinal = zeros(1,size(ttestResultsUnMask,2));

index = 1;
while index < size(ttestResultsUnMask,2) %starting from each time point
        tempMaxVal = 0;
        tempMinVal = 0;
        %find any continguous cluster
        while ttestSignificanceUnMask(index) > 0
            if ttestResultsUnMask(index) > ZScoreThreshold
                tempMaxVal = tempMaxVal + ttestResultsUnMask(index);                 
                maxValsFinal(index) = tempMaxVal; %integrate to keep track of cluster size
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            elseif ttestResultsUnMask(index) < -ZScoreThreshold
                tempMinVal = tempMinVal + ttestResultsUnMask(index);                 
                minValsFinal(index) = tempMinVal;
                index = index + 1;
                if index > size(ttestResultsUnMask,2)
                    break;
                end
            end
        end
        index = index + 1;

end

tt =  mean(masksFinalUnTossed); % mean classification profile
ttt = (std(masksFinalUnTossed)) ./ (sqrt(size(masksFinalUnTossed,1))); % Standard error
ttt = ttt * tinv(1-(ttestP/2),size(masksFinalUnTossed,1)-1); % ttt: 95% confidence interval. Used for display as sanity check

maxValsFinal2 = zeros(size(maxValsFinal)); %used for true/false on cluster test
 
maxValsFinal3 = (ttestResultsUnMask > PixelPercentileVal); % true/false on pixel test

for i = 1 : size(maxValsFinal,2) %For each time point
    if maxValsFinal(1,i) > PercentileVal %check if it forms part of a significant POSITIVE cluster
        maxValsFinal2(1,i) = 1; %set a marker accordingly        
        tempindex = i-1;
        while tempindex > 1 %Then walk backwards towards the start of the cluster, setting markers as we go
            if abs(maxValsFinal(1,tempindex)) > 0
                maxValsFinal2(1,tempindex) = 1;                          
            else
                break;
            end
            tempindex = tempindex - 1;
        end
    end  
end

ValFinal = zeros(size(ttestResultsUnMask,2),1); %overly complex way of finding absolute integrated cluster scores
for i = 1 : size(ttestResultsUnMask,2)
    if maxValsFinal(i) > abs(minValsFinal(i))
        ValFinal(i) = maxValsFinal(i);
    else
        ValFinal(i) = abs(minValsFinal(i));
    end
end


% Method for finding exact P. find how many entries are bigger than critical value
%( say 10 are bigger) and the P value is 10/2000. if 0, then
% 1/2000. 

%**********CALCULATE P-VALUE of each cluster (in chronological order)

j = 1;
index = 1;
maxValsforPercentile = [];
while index <= size(ValFinal,1)
    tempVal = 0;
    while abs(ValFinal(index)) > 0 %if in a cluster
        tempVal = ValFinal(index); %walk through to record maximum integrated value, which = cluster score
        index = index + 1;
        if index > size(ValFinal,1)
            break;
        end;
    end
    if abs(tempVal) > 0
       %if tempVal > PercentileVal % uncommenting this
       %condition here considers only the significant clusters for
       %p-Value calculation. 
           maxValsforPercentile(j) = ValFinal(index - 1); %not sure why we didn't use tempVal, but same result
           j = j+1;
       %else
           index = index + 1;
       %end
    else
        index = index + 1;
    end
end

for i = 1 : size(maxValsforPercentile,2) %for each cluster in the data
    pValue(i) = (sum(maxValFinal>maxValsforPercentile(i))+1)./(numIterations+1);
end

%**********************

figure

if storyboard %Add a timeline of video shots if one has been loaded
    
    subplot(3,1,1)
    imshow(BGImage);
    
    subplot(3,1,[2,3])
    
end

errorbar(tt,ttt); %plot mean classification sequence and error bars

hold on
plot(maxValsFinal3,'y--'); %add pixel significance
plot(maxValsFinal2,'r--'); %and cluster significance

axis([-5 size(masksFinal,2)+6 min(min(tt))-1 max(max(tt))+1]);
legend('Mean Z-Scored Classification Profile','Pixel Significance','Clusters Significance');
xlabel('Frame Number');
ylabel('Classification sequence intensity');
title('Permutation test Results');

% Save some key stuff with a sensible name. Change the name of this for
% each analysis to avoid overwriting data.

ServesAll.meanClassificationSequence = tt;
ServesAll.CIonSequence = ttt;
ServesAll.clusterSig = maxValsFinal2;
ServesAll.pixelSig = maxValsFinal3;
ServesAll.eachClusterP = pValue;
ServesAll.clustersIntegral = ValFinal;
ServesAll.clusterNullDist = sort(maxValFinal);
ServesAll.pixelNullDist = sort(ExtremeVal);
ServesAll.AllParticipantsClassificationSequences = masksFinal;
ServesAll.eachClusterSize = maxValsforPercentile;

%clear up the workspace

clear AimedPercental BootstrapTemporal ci counter ExtremeVal filePath ...
    filesList groupLevel h i index irrelevant j masksFinal masksFinalTossed ...
    masksFinalUnTossed maxVal maxValFinal maxValsFinal maxValsFinal2 maxValsFinal3 ...
    maxValsforPercentile maxValUnBiased minVal minValsFinal numIterations p ...
    PercentileVal PixelPercentileVal pValue pValueindex stats storyboard ...
    temp tempindex tempMaxVal tempMinVal tempName tempPath tempVal tempzeroMatrix ...
    tt ttestP ttestResults ttestResultsUnMask ttestSignificance ttestSignificanceUnMask ...
    ttt ValFinal ZScoreThreshold
