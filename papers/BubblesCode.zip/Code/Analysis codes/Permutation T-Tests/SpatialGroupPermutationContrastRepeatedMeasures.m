%Script to implement permutation cluster/pixel test for spatial classification images 
%which have been obtained from one groups of participants in two different conditions.
%Identifies regions of difference between the conditions (equivalent to paired-sample
%t-test). Marks up only signifant regions, but provides p
%values for all clusters (significant or not).

% Note on data -
% Each participant's data should be in a .mat file, with all .mat files in
% two separate folders (for which you must provide the paths, below). Within the mat file, the classification sequence is
% currently assumed to be stored in one field of a particular structure: BootstrapSpatial.MaskZScoredFinal
% (but this could be changed below if you've called it something different)
% There is also assumed to be a second field called
% BootstrapSpatial.ReferenceImageFinal, which holds a background image (for
% example the video at the particular frame for which spatial normalisation
% has been applied - ball contact in our tennis examples). However, you can
% override this using the MyBackground program constant.

%An issue specific to this script - depending on what subsets of trials you
%are comparing, they may have been subjected to different spatial
%renormalisation. If so, you may need to introduce a spatial correction
%(see line 128+ below for an example)

% Note on clustering - 
% Cluster distribution based on largest absolute cluster on each
% permutation, so only the positive tail is relevant. Use 5% cut for
% two-tailed (approximately, you can divide exact p by 2 or use 10% cut (so 
% set AimedPercental to 90) for
% one-tailed).

% One more note -
% Commenting here is less complete than for the permutationVsZero script,
% look there for some further explanation alongside code.

numIterations = 99; %Number of permutations used to form null distribution
AimedPercental = 95; % Point on distribution considered significant
ttestP = 0.05; % data points are considered part of a cluster when they exceed
%some arbitrary level of significance, set here (two-tailed)

MyBackground = 0; %set to 1 and change file path below to set your own background image
%for the graphical outputs. Make sure whatever image you pick is the right
%size though. This is quite tricky if the visual reference frame is being
%adjusted on each trial!

impath = ''; %if you  leave this empty (and set MyBackground to 1) a black background is used


if MyBackground
    impath = ''; %if you  leave this empty (and set MyBackground to 1) a black background is used
    if ~isempty(impath)
        BGFinal = imread(Impath);
    end
end

%Must indicate WHERE THE DATA CAN BE FOUND here:

%filePath = '/Users/sepehr/Desktop/Final Results/Temporal/Bootstrap Results/Returns/';
filePath = 'C:\Users\sbbb944\Documents\Work\Sepehr\E123\Spatial\Bootstrap Results\Serves\'; %Lines/All Participants/';
c1 = 'Lines\Mat Files\';
c2 = 'Crosses\Mat Files\';

%Condition 1
filesListtemp = dir(fullfile(strcat(filePath,c1))); %*******

filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

namesList = {};
counter = 1;
for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))        
        if ~isempty(strfind(tempName,'mat')) %check it's a .mat file
            namesList{counter} = tempName(1:end-4);
            
            counter = counter + 1;
        end
    end
end
numGroupOne = counter - 1;

%Condition 2
filesListtemp = dir(fullfile(strcat(filePath,c2))); %********

filesList(1:size(filesListtemp,1)-2) = filesListtemp(3:end);
clear filesListtemp;

for i = 1 : size(filesList,2)
    temp = filesList(i);
    tempName = temp.name;
    
    if isempty(strfind(tempName,'.DS_Store'))         
        if ~isempty(strfind(tempName,'mat')) %check it's a .mat file
            namesList{counter} = tempName(1:end-4);
            
            counter = counter + 1;
        end
    end
end
numGroupTwo = counter - numGroupOne - 1;

if numGroupOne ~= numGroupTwo
    error('Conditions have different numbers of files / data points')
end

for i = 1 : numGroupOne %now load in mat files and extract relevant data
    temp = namesList{i};
    tempPath = strcat(filePath,c1,temp,'.mat');    
    load(tempPath);
    masksFinal(i,:,:) = BootstrapSpatial.MaskZScoredFinal;    
    
    if MyBackground %depending on user-defined options, either stick with a defined background, set a black background,
        %or load a background from the participant's data structure
        if isempty(Impath)
           BGFinal(i,:,:) = zeros(size(masksFinal(i,:,:),1),size(masksFinal(i,:,:),2)); 
        end
    else
        BGFinal(i,:,:) = BootstrapSpatial.ReferenceImageFinal;
    end
end

for i = 1 : numGroupTwo %now load in mat files and extract relevant data
    temp = namesList{i + numGroupOne};
    tempPath = strcat(filePath,c2,temp,'.mat');    
    load(tempPath);
    
    %**************************************
%******DO THIS ONLY FOR LINES VS CROSSES -> the reason, is in line 63 in SpatialMasksAlignment
%IF SERVES:    

    BootstrapSpatial.MaskZScoredFinal = circshift(BootstrapSpatial.MaskZScoredFinal,-1,1); % first dimension
    BootstrapSpatial.MaskZScoredFinal = circshift(BootstrapSpatial.MaskZScoredFinal,-5,2); % second dimension
    BootstrapSpatial.ReferenceImageFinal    = circshift(BootstrapSpatial.ReferenceImageFinal,-1,1);
    BootstrapSpatial.ReferenceImageFinal    = circshift(BootstrapSpatial.ReferenceImageFinal,-5,2);
    
% IF RETURNS:

%     BootstrapSpatial.MaskZScoredFinal = circshift(BootstrapSpatial.MaskZScoredFinal,4,1); % first dimension
%     BootstrapSpatial.MaskZScoredFinal = circshift(BootstrapSpatial.MaskZScoredFinal,-10,2); % second dimension
%     BootstrapSpatial.ReferenceImageFinal    = circshift(BootstrapSpatial.ReferenceImageFinal,4,1);
%     BootstrapSpatial.ReferenceImageFinal    = circshift(BootstrapSpatial.ReferenceImageFinal,-10,2);

    
    %*************************************** % for other tests, simply
    %comment all out. 
        
    masksFinal(i + numGroupOne,:,:) = BootstrapSpatial.MaskZScoredFinal;    
    
    if MyBackground %depending on user-defined options, either stick with a defined background, set a black background,
        %or load a background from the participant's data structure
        if isempty(Impath)
           BGFinal(i + numGroupOne,:,:) = zeros(size(masksFinal(i + numGroupOne,:,:),1),size(masksFinal(i + numGroupOne,:,:),2)); 
        end
    else
        BGFinal(i + numGroupOne,:,:) = BootstrapSpatial.ReferenceImageFinal;
    end
    
end

%Prepare storage for extreme values used in cluster test
maxVal = zeros(numIterations,1);
minVal = zeros(numIterations,1);

%prepare storage for pixels
ExtremeVal = zeros(numIterations,1);

masksFinal = masksFinal(1:numGroupOne,:,:) - masksFinal(numGroupOne+1:end,:,:);

rng('shuffle');

%Now repeatedly permute the data to establish null distributions
for j = 1 : numIterations
    tic
    for i = 1 : size(masksFinal,1)
        temp = masksFinal(i,:,:);
        temp = reshape(temp,size(masksFinal,2),size(masksFinal,3));
        if rand(1,1) < 0.5
            temp = -temp;
        end
        masksFinalTossed(i,:,:) = temp;
    end
    
     if size(masksFinalTossed,1) ==1 % normally we will need more than one participant in each group. This is just to avoid an error.
         masksFinalTossed(2,:,:) = masksFinalTossed(1,:,:);
     end
     
    %t-test vs. 0
    [h,p,ci,stats] = ttest(masksFinalTossed,0,'Alpha',ttestP);
    ttestResults(:,:) = reshape(stats.tstat,size(masksFinal,2),size(masksFinal,3));
    ttestSignificance(:,:) = reshape(h, size(masksFinal,2),size(masksFinal,3));
    
    ttestSignificance(isnan(ttestSignificance)) = 0;
    ttestResults(isnan(ttestResults)) = 0;
    ttestResultsTemp = ttestResults .* ttestSignificance;

    tempBox = ttestResultsTemp(:,:);
    tempBox2 = zeros(1,1);
    %find contiguous regions that exceed cluster threshold
    cc = bwconncomp(tempBox, 4);
    
    for n = 1 : cc.NumObjects %for each cluster
        pixelList = cc.PixelIdxList{n};        
        tempBox2(n) = sum(tempBox(pixelList)); %sum t values
    end
    maxVal(j) = max(tempBox2); %biggest positive cluster
    minVal(j) = min(tempBox2); %negative
    
    ExtremeVal(j) = max(max(abs(ttestResults)));

    clear pixelList tempBox2 cc ttestResultsTemp;
    if j < 5
        timePerPermIteration(j) = toc
    end
end

maxValFinal = zeros(numIterations,1);
for i = 1 : numIterations
    if maxVal(i) > abs(minVal(i))
        maxValFinal(i) = maxVal(i);
    else
        maxValFinal(i) = abs(minVal(i));
    end
end

PercentileVal = prctile(maxValFinal,AimedPercental);
PixelPercentileVal = prctile(ExtremeVal,AimedPercental);

[h,p,ci,stats] = ttest(masksFinal,0,'Alpha',ttestP);

ttestResultsReal = reshape(stats.tstat,size(masksFinal,2),size(masksFinal,3));
ttestSignificanceReal = reshape(h, size(masksFinal,2),size(masksFinal,3));
ttestResultsReal(isnan(ttestResultsReal)) = 0;
ttestSignificanceReal(isnan(ttestSignificanceReal)) = 0;
ttestResultsRealTemp = ttestResultsReal .* ttestSignificanceReal;

tempBox = ttestResultsRealTemp(:,:);
cc = bwconncomp(tempBox, 4);
tempBox2 = zeros(size(ttestResultsReal,1),size(ttestResultsReal,2));

for n = 1 : cc.NumObjects
    pixelList = cc.PixelIdxList{n};    
    tempBox2(pixelList) = sum(tempBox(pixelList));     
    maxValsforPercentile(n) = sum(tempBox(pixelList)); %sum t values
    clear pixelList;
end

tt =  mean(masksFinal); %mean classification image
tt = reshape(tt,size(masksFinal,2),size(masksFinal,3));

stdmaskFinal = std(masksFinal); %sd, used to create confidence intervals
stdmaskFinal = reshape(stdmaskFinal,size(masksFinal,2),size(masksFinal,3));
ttt = stdmaskFinal ./ (sqrt(size(masksFinal,1))); %standard error
ttt = ttt * tinv(1-(ttestP/2),size(masksFinal,1)-1); %CI

% %***************
tempBox3 = zeros(size(ttestResultsReal,1),size(ttestResultsReal,2)); %image used to denote significance
for i = 1 : size(ttestResultsReal,1)
    for j = 1 : size(ttestResultsReal,2)
        if abs(tempBox2(i,j)) > PercentileVal %for ANY significant clusters
            tempBox3(i,j) = 1.0; %mark significant clusters
        else
            if tempBox2(i,j) ~= 0
                tempBox3 (i,j) = 0.2; %use this to mark non-sig clusters. It will be a transparency value, low = transparent.            
            end
        end
    end
end

SpatialBubblesMask = tempBox3;
ReferenceImageFinal = zeros(600,800);

%**********CALCULATE P-VALUE

for n = 1 : cc.NumObjects %for each cluster in the data
    pValue(n) = (sum(maxValFinal>abs(maxValsforPercentile(n)))+1)./(numIterations+1); %find exact p
end

%Then record exact cluster p values on an image
tempBox6 = single(zeros(1,size(tempBox2,1)*size(tempBox2,2)));
for i = 1 : cc.NumObjects
    tempBox6(find(tempBox2 == maxValsforPercentile(i))) = pValue(i);
end
pValuesOnAllImage = reshape(tempBox6,size(tempBox2,1), size(tempBox2,2)); 

%Finally, mark signifcant regions from pixel test
PixelSig = (ttestResultsReal > PixelPercentileVal); % true/false on pixel test

% show the figures and results

doubleCheck = 1;

temp = tt./ttt; %Normalise units to be a proportion of the confidence interval, so +1 (or -1) represents the cluster threshold

figure

if doubleCheck
        
    subplot(1,2,1)

    imshow(temp,'DisplayRange',[-1 1],'InitialMag', 'fit'), colorbar;

    title('double check with normalised difference image, c1 - c2');   

    subplot(1,2,2)
    
end

hold on

if MyBackground
    if isempty(impath)
        BGFinalMean = mean(BGFinal);
    else
        BGFinalMean = BGFinal;
    end
else
    BGFinalMean = mean(BGFinal);
end
    
ReferenceImageFinal = reshape(BGFinalMean,size(BGFinalMean,2),size(BGFinalMean,3));
ReferenceImageFinal = uint8(ReferenceImageFinal);
imshow(ReferenceImageFinal, 'InitialMag', 'fit');
title('Results from cluster permutation test');
red = cat(3, ones(size(ReferenceImageFinal)),zeros(size(ReferenceImageFinal)), zeros(size(ReferenceImageFinal)));
hold on
h = imshow(red);
set(h, 'AlphaData', SpatialBubblesMask);
yellow = cat(3, ones(size(ReferenceImageFinal)),ones(size(ReferenceImageFinal)), zeros(size(ReferenceImageFinal)));
%Here I'm adding this  filter to the previous  red one
%will leave pixel regions yellow 
h = imshow(yellow);
set(h, 'AlphaData', double(PixelSig));

hold off

figure

%Generate a surface plot in 3d
% high = max(max(temp));
% low = min(min(temp));

%Uncomment this next line in order to only plot values reaching cluster
%threshold
%temp = temp .* (abs(temp)>1);

lowx=(0*temp);
hold on
[y,x] = size(ReferenceImageFinal);
x = repmat([1:x],y,1);
y = repmat([-1:-1:-y]',1,size(x,2));
colormap('gray')
surface(x,y,lowx,ReferenceImageFinal,'EdgeColor','none'); %'FaceColor','texturemap','CDataMapping','direct'
surface(x,y,temp,red,'FaceAlpha',0.2,'LineStyle','none','FaceColor','interp');
axis on
view(-35,45)
zlabel('Mean difference image. +/-1 = cluster threshold')

SpatialServesC1vsC2.meanDifferenceImage = tt;
SpatialServesC1vsC2.CIonImage = ttt;
SpatialServesC1vsC2.clusterSigOnImage = pValuesOnAllImage;
SpatialServesC1vsC2.pixelSigOnImage = PixelSig;
SpatialServesC1vsC2.eachClusterP = pValue;
SpatialServesC1vsC2.clustersSumOnImage = tempBox2;
SpatialServesC1vsC2.clusterNullDist = sort(maxValFinal);
SpatialServesC1vsC2.pixelNullDist = sort(ExtremeVal);
SpatialServesC1vsC2.AllParticipantsDifferenceSequences = masksFinal;
SpatialServesC1vsC2.eachClusterSize = maxValsforPercentile;
SpatialServesC1vsC2.ReferenceImageFinal = ReferenceImageFinal;

clear BGFinal BGFinalMean BootstrapSpatial cc ci counter ExtremeVal ...
    groupLevel h i j masksFinal masksFinalTossed1 maxVal maxValFinal ...
    maxValsforPercentile minVal MyBackground n namesList numIterations ...
    p PercentileVal pixelList PixelPercentileVal PixelSig pValue  ...
    pValuesOnAllImage red ReferenceImageFinal SpatialBubblesMask ...
    stats stdmaskFinal temp temp1 temp2 tempA tempB tempBox tempBox3 tempBox2 ...
    tempBox6 tempName tempPath timePerPermIteration tt ttestP ttestResults ...
    ttestResultsReal ttestResultsRealTemp ttestSignificance ttestSignificanceReal ...
    ttt yellow x y impath lowx index indices1 masksFinalTossed2 ...
    masksFinalUnTossed1 masksFinalUnTossed2 theDiff doubleCheck


