% This is the main function which provides the structure for the whole
% experiments and practice trials.
%*******(This is the Pedal Version.********
%*******Timings for keybaord version are different.)********
numTrialsPractice = 100; % CHANGE TO 100 FOR THE REAL EXPERIMENT
timeThreshold = 0.4; % time threshold to start with, in Seconds
Var = 3;
maxNumGaussians = 20; %******************** change to (standard: 20)
numGaussianCenters = 5;
numPlayersExperimentMode = 3;
numDirectionsExperimentMode = 2;
numShotsPerPlayerExperimentMode = 4;
numRepeatesPerPlayerExperimentMode = 16; % 16; % CHANGE TO 16 for the real experiment
datetime = clock; % using the date in the file name to avoid overriding similar names and different dates
numFramesBeforeBC = 96; % number of frames to display before ball contact point
numFramesAfterBC = 24; % number of frames to display after ball contact point
ResultsPractice = cell(1,numTrialsPractice);
numTrialsExperiment = numPlayersExperimentMode*numDirectionsExperimentMode*numShotsPerPlayerExperimentMode*numRepeatesPerPlayerExperimentMode; %3 main players. * 2 directions, * 5 examples per player. = 30 stimuli. Each stimuli to be repeated 10 times. = 300 trials in a block. To be randomized in terms of presentation order.
numTrialsDelta = 50; % CHANGE TO 50 FOR REAL EXPERIMENT
ResultsPracticeDelta = cell(1,numTrialsDelta);
BetaValue = 1;
DeltaServes = 0.1;
DeltaReturns = 0.1;
%
% %********************** delete these after Beta calculation
% numTrialsExperiment = 500;
% %**********************

ResultsExperiment = cell(1,numTrialsExperiment);
Blue = [0, 0, 255];
Red = [230, 0, 0];
Green = [0, 255, 0];
White = [255, 255, 255];
Black = [0, 0, 0];
Gray = [125, 125, 125];
PracticePlayerIndex = 4; % Using player D (4) for practice mode
ExperimentPlayerIndices = [1,2,3]; % Using other players for experiment mode THE CURRENT CODE supports 3 players here. If more are needed, the experimentstep code shall be modified by adding loops for 4th player
practicePlayerPercentage = 0.4;

vidResHS = 161; % Video Resolution to show, Height Start point: 161:560,241:840
vidResHE = 560;
vidResWS = 241;
vidResWE = 840;

format long;
screenNumbers=Screen('Screens');
if (numel(screenNumbers) ==1)
    screens = 0;
else
    screens = 1; % using the second monitor
    screens2 = 0; % to get the main screen in case of using two monitors to avoid time losses.
end
[wPtr,rect]=Screen('OpenWindow',screens, Gray, []);
Screen('TextSize', wPtr, 15);
%Screen('TextColor', wPtr, Blue);
HideCursor(wPtr);

%
% if numel(screenNumbers) > 1 % we open an empty screen to avoid OS time consumtion on the main screen
%     Screen('Preference', 'SkipSyncTests', 1); % if on Macbook Retina Display
%     [wPtr2,rect2]=Screen('OpenWindow',screens2, White, []);
%     %Screen('Preference', 'Verbosity', 1);
%     Screen('Flip', wPtr2);
%     %Screen('Close',wPtr2); % for test purposes.
% end

%HideCursor;


monitorFlipInterval=Screen('GetFlipInterval', wPtr);
FrameRate = 1/monitorFlipInterval;
Screen('TextColor', wPtr, Black);

theParticipantName = GetEchoString(wPtr, 'Please Enter Your Initials: ', 150, 100);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
Screen(wPtr, 'Flip');
%Screen('TextColor', wPtr, Red);
theParticipantAge = GetEchoString(wPtr, 'Please Enter Your Age: ', 150, 100);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
Screen(wPtr, 'Flip');
%Screen('TextColor', wPtr, Green);
theParticipantGenderTag = 'I';
while (theParticipantGenderTag == 'I')
    theParticipantGender = GetEchoString(wPtr, 'Please Enter Your Gender (M/F): ', 150, 100);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
    Screen(wPtr, 'Flip');
    if (lower(theParticipantGender) == 'm' || lower(theParticipantGender) == 'f')
        theParticipantGenderTag = 'O';
    end
end
theParticipantExpertiseTag = 'I';
while (theParticipantExpertiseTag == 'I')
    theParticipantExpertisetemp = GetEchoString(wPtr, 'Please Enter Your Expertise Level (1:No Expertise,2:Good Player,3:Expert): ', 150, 100);%, [textColor], [bgColor], [useKbCheck=0], [deviceIndex], [untilTime=inf], [KbCheck args...])
    theParticipantExpertise = uint8(str2double(theParticipantExpertisetemp));
    Screen(wPtr, 'Flip');
    if (theParticipantExpertise == 1 || theParticipantExpertise == 2 || theParticipantExpertise == 3)
        theParticipantExpertiseTag = 'O';
    end
end
%Screen('TextColor', wPtr, Black);
ServiceOrReturnTag = 'I';
while (ServiceOrReturnTag == 'I')
    ServiceOrReturn = GetEchoString(wPtr, 'Please Choose Services or Returns to Start with First (S/R):  ', 150, 100);
    Screen(wPtr, 'Flip');
    if (lower(ServiceOrReturn) == 's' || lower(ServiceOrReturn) == 'r')
        ServiceOrReturnTag = 'O';
    end
end


ExperimentName = strcat(num2str(datetime(1)), num2str(datetime(2)), num2str(datetime(3)), num2str(datetime(4)), num2str(datetime(5)),theParticipantName,theParticipantAge,theParticipantGender);

if (ispc)
    KbName('UnifyKeyNames');
    contactPointsNameSelect = load('C:\TennisVideosGray\contactPointsNameSelectFinal.mat');
    contactPointsNameSelectPractice = load('C:\TennisVideosGray\contactPointsNameSelectFinalPractice.mat');
    PriorityMax = 1;
else
    contactPointsNameSelect = load('/Users/sepehr/Desktop/TennisVideosGray/contactPointsNameSelectFinal.mat');
    PriorityMax = 9;
end

esc=KbName('ESCAPE');
right=KbName('RightArrow');
left=KbName('LeftArrow');


Initialization.numTrialsPractice = numTrialsPractice;
Initialization.numGaussianCenters = numGaussianCenters;
Initialization.maxNumGaussians = maxNumGaussians;
Initialization.Var = Var;
Initialization.numTrialsExperiment = numTrialsExperiment;
Initialization.timeThreshold = timeThreshold;
Initialization.numFramesBeforeBC = numFramesBeforeBC;
Initialization.numFramesAfterBC = numFramesAfterBC;
Initialization.monitorFlipInterval = monitorFlipInterval;
Initialization.FrameRate = FrameRate;
Initialization.esc = esc;
Initialization.right = right;
Initialization.left = left;
Initialization.theParticipantName = theParticipantName;
Initialization.contactPointsNames = contactPointsNameSelect.contactPointsNames;
Initialization.contactPointsNamesPractice = contactPointsNameSelectPractice.contactPointsNameSelectFinalPractice;
Initialization.wPtr = wPtr;
Initialization.ResultsExperiment = ResultsExperiment;
Initialization.ResultsPractice = ResultsPractice;
Initialization.ResultsPracticeDelta = ResultsPracticeDelta;
Initialization.PriorityMax = PriorityMax;
Initialization.numPlayersExperimentMode = numPlayersExperimentMode;
Initialization.numDirectionsExperimentMode = numDirectionsExperimentMode;
Initialization.numShotsPerPlayerExperimentMode = numShotsPerPlayerExperimentMode;
Initialization.numRepeatesPerPlayerExperimentMode = numRepeatesPerPlayerExperimentMode;
Initialization.Red = Red;
Initialization.Blue = Blue;
Initialization.Green = Green;
Initialization.White = White;
Initialization.Black = Black;
Initialization.Gray = Gray;
Initialization.PracticePlayerIndex = PracticePlayerIndex;
Initialization.ExperimentPlayerIndices = ExperimentPlayerIndices;
Initialization.practicePlayerPercentage = practicePlayerPercentage;
Initialization.BetaValue = BetaValue;
Initialization.numTrialsDelta = numTrialsDelta;

Initialization.vidResHS = vidResHS;
Initialization.vidResHE = vidResHE;
Initialization.vidResWS = vidResWS;
Initialization.vidResWE = vidResWE;



if (ServiceOrReturn == 'S' || ServiceOrReturn == 's')
    ExperimentName1 = strcat(ExperimentName,'Practice', num2str(theParticipantExpertise) , 'Serves');
    ExperimentName2 = strcat(ExperimentName,'Experiment',num2str(theParticipantExpertise),'Serves');
    ExperimentName3 = strcat(ExperimentName,'Practice',num2str(theParticipantExpertise),'Returns');
    ExperimentName4 = strcat(ExperimentName,'Experiment',num2str(theParticipantExpertise),'Returns');
    
    [scorePracticeServe, reactionTimeServe] = PracticeTemporal('S', ExperimentName1,Initialization);
    [scorePracticeReturn, reactionTimeReturn] = PracticeTemporal('R',ExperimentName3,Initialization);
    scoreExperimentServe = ExperimentTemporal('S',reactionTimeServe,ExperimentName2,Initialization,DeltaServes);
    scoreExperimentReturn = ExperimentTemporal('R',reactionTimeReturn,ExperimentName4,Initialization,DeltaReturns);
else
    ExperimentName1 = strcat(ExperimentName,'Practice',num2str(theParticipantExpertise),'Returns');
    ExperimentName2 = strcat(ExperimentName,'Experiment',num2str(theParticipantExpertise),'Returns');
    ExperimentName3 = strcat(ExperimentName,'Practice',num2str(theParticipantExpertise),'Serves');
    ExperimentName4 = strcat(ExperimentName,'Experiment',num2str(theParticipantExpertise),'Serves');
    
    [scorePracticeReturn, reactionTimeReturn] = PracticeTemporal('R',ExperimentName1,Initialization);
    [scorePracticeServe, reactionTimeServe] = PracticeTemporal('S',ExperimentName3,Initialization);
    scoreExperimentReturn = ExperimentTemporal('R',reactionTimeReturn,ExperimentName2,Initialization,DeltaReturns);
    scoreExperimentServe = ExperimentTemporal('S',reactionTimeServe,ExperimentName4,Initialization,DeltaServes);
end
score = scorePracticeServe + scoreExperimentServe + scorePracticeReturn + scoreExperimentReturn;
DrawFormattedText(wPtr,['Experiment done!!! Thank you! \n\n (CLOSE MATLAB AND RESTART IT FOR THE NEXT PARTICIPANT) \n\n\n Your final score is ' num2str(score) ' out of ' num2str(numTrialsPractice*20 + numTrialsExperiment*20)  ' \n\n ' num2str((scoreExperimentServe + scoreExperimentReturn) *100 / (numTrialsExperiment*20)) ' % correct. '], 'center', 140, 0);
DrawFormattedText(wPtr,['Your score in Practice Mode is ' num2str(scorePracticeServe + scorePracticeReturn) ' out of ' num2str(numTrialsPractice*20)  '\n\n '], 'center', 340, 0);
DrawFormattedText(wPtr,['Your score in Occlusion Mode is ' num2str(scoreExperimentServe + scoreExperimentReturn) ' out of ' num2str(numTrialsExperiment*20) ' \n\n   Press any key to close the program!'], 'center', 440, 0);

Screen(wPtr, 'Flip');
KbStrokeWait;

Screen('CloseAll');
ShowCursor();

