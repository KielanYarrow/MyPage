index = 20; % for each video find its index in the file. % 20th to check
%videoName = 'RIC-13';
% other input arguments: ServiceOrReturn, framesRange
%if nargin < 5
%    framesRange = (1:size(movie,3)); % might be used for multiple frame
%    ranges
%end
tic;
load('C:\TennisVideosGray\contactPointsNameSelectFinal.mat');
%ServiceOrReturn = 'R'; 
temp = contactPointsNames{index};
videoName = temp.filename;
ServiceOrReturn = videoName(1);
VideoContactPoint = temp.Frame;
numGaussianCenters = 85; 
Var  = 12;
videoNameFull = strcat('C:\TennisVideosGray\',videoName,'Gray.mat');
load(videoNameFull); % the structure name is Vid
%load('/Users/sepehr/Desktop/TennisVideosGray/RIC-01Gray.mat');

load(strcat('C:\TennisVideosGray\Detection\', videoName, '.mat'));

nFrames = size(Vid,3);
nHeight = size(Vid,1);
nWidth = size(Vid,2);
numFramesBeforeBC = 96; % number of frames to display before ball contact point
numFramesAfterBC = 24; % number of frames to display after ball contact point

vidResHS = 161; % Video Resolution to show, Height Start point: 161:560,241:840
vidResHE = 560;
vidResWS = 241;
vidResWE = 840;

VidResized = Vid(vidResHS:vidResHE,vidResWS:vidResWE,:); % to adjust to the screen size resolution
%clear Vid;

startPoint = VideoContactPoint - numFramesBeforeBC; % 1000ms/20 frames before Ball Contact point.
relativeContactPoint = numFramesBeforeBC;
if( startPoint < 1)
    startPoint =1;
    relativeContactPoint = VideoContactPoint;
end
endPoint = VideoContactPoint + numFramesAfterBC;
if ( endPoint > nFrames)
    endPoint = nFrames;
end
VidNonNoised = VidResized; % back up
framesRange = (1:(endPoint - startPoint + 1)); % you can define
%framesRange like:
%[67,68,69,70,71,72,73,74,75,76,87,88,89,90,91,92,93,94,95,96,97]; (order
%is not important. it does not need to be sorted
%framesRange = [67,68,69,70,71,72,73,74,75,76,87,88,89,90,91,92,93,94,95,96,97];
maskFrameDuration = 21;
[VidNoised, FinalValMask] = CreateSpatioTemporalGaussianNoiseFast(Vid(:,:,startPoint:endPoint), numGaussianCenters, Var , upper(ServiceOrReturn), DetectedObjects,startPoint,framesRange,maskFrameDuration);
toc
%[VidNosied, FinalValMask] = CreateSpatioTemporalGaussianNoise(VidResized(:,:,startPoint:endPoint), numGuassianCenters, Var, upper(ServiceOrReturn));
implay(VidNoised);
Vid = VidNoised;
