function score = ExperimentSpatial(ServiceOrReturn,reactionTime, ExperimentName,Initialization,DeltaValue)
% We will use a set of videos for Services and Returns respectively.
% in this stage, there will be bubbles added to reduce visibility.
% the goal is they respond as accurate as possible in their time limit. for a
% start 5 bubbles. Every three times they manage to respond inside the deadline and get it right,
% we lower the num of bubbles by -1 ( On the other hand, every time they miss
% or get it wrong, we raise the number of bubbles by 3
% here are some initializations:

d = daq.getDevices;
if isempty(d)
    UsePedals = 0;
else
    UsePedals = 1;
end

if UsePedals == 1
    daq.reset
    s = daq.createSession('ni');
    s.addAnalogInputChannel('dev1',0:1,'Voltage'); %use 0:1 for two channel, etc.
    s.Rate = 100000;
    %s.DurationInSeconds = 5;
    s.NotifyWhenDataAvailableExceeds = 2 .* round(Initialization.monitorFlipInterval.*s.Rate); %1667;
    s.IsContinuous = true;
    
    lh = s.addlistener('DataAvailable',@plotInline);
    prepare(s);
    
    absolutePedalStart = 0;
    pedalTime = 0;
    transferTimes = zeros(100000,1);
    transfercounter = 0;
    
end
pedalsInput = ones(1,2);

% end DAQ initialisation

timeThreshold = reactionTime;
numFramesBeforeBC = Initialization.numFramesBeforeBC;
numFramesAfterBC = Initialization.numFramesAfterBC;
monitorFlipInterval = Initialization.monitorFlipInterval;
maxNumGaussians = Initialization.maxNumGaussians;
FrameRate = Initialization.FrameRate;
esc = Initialization.esc;
right = Initialization.right;
left = Initialization.left;
theParticipantName = Initialization.theParticipantName;
contactPointsNames = Initialization.contactPointsNames; %Cell
%contactPointsNames = contactPointsNameSelect.contactPointsNames;
wPtr = Initialization.wPtr;
ResultsExperiment = Initialization.ResultsExperiment; %Cell
PriorityMax = Initialization.PriorityMax;
numGaussianCenters = Initialization.numGaussianCenters;
Var = Initialization.Var;
numPlayers = Initialization.numPlayersExperimentMode;
numDirections = Initialization.numDirectionsExperimentMode;
numShotsPerPlayer = Initialization.numShotsPerPlayerExperimentMode;
numRepeatesPerPlayer = Initialization.numRepeatesPerPlayerExperimentMode;
numTrials = Initialization.numTrialsExperiment;
Blue = Initialization.Blue;
Red = Initialization.Red;
Green = Initialization.Green;
White = Initialization.White;
Black = Initialization.Black;
Gray = Initialization.Gray;
vidResHS = Initialization.vidResHS;
vidResHE = Initialization.vidResHE;
vidResWS = Initialization.vidResWS;
vidResWE = Initialization.vidResWE;
ExperimentPlayerIndices = Initialization.ExperimentPlayerIndices;
BetaValue = Initialization.BetaValue;

qQuest = QuestCreateNormal(log(10),5,(3 - DeltaValue) / 4,BetaValue,DeltaValue,0.5,0.1,4);

maxPossibleScore = 10* numTrials;
%*********%*********%*********%*********
%*********%*********%*********
%*********
%numTrials = 15; % for test purposes:

%*********%*********%*********%*********
%*********%*********%*********%*********
%*********%*********%*********%*********
gaussianCounter = 0;
score = 0; % a score to encourage the participants for better responses.
numMissedFrame = 0;

if (ServiceOrReturn == 'S' || ServiceOrReturn == 's')
    ExperimentMode = 'Services';
else
    ExperimentMode = 'Returns';
end


DrawFormattedText(wPtr, ['Hi ' theParticipantName '! \n\n Welcome to the Spatial Occlusion step of the experiment! \n\n You will be shown ' num2str(numTrials) ' occluded videos of ' ExperimentMode '. \n\n AS FAST AS YOU CAN, \n\n\nPress the LEFT ARROW KEY if you think the shot is LINE (towards your left side) or  \n\n Press the RIGHT ARROW KEY if you think it is a CROSS shot (towards your right side). \n\n\n Each time you answer correctly in the time limit (' num2str(round(timeThreshold*1000),5) ' Milliseconds)\n\n , you gain 10 points. If you answer wrong in the time limit, you gain 2 points.\n\n If you answer correctly/wrong out of the time limit, you lose 5 points. \n\n\n  Try to maximize your score!!!! \n\n\n IF YOU MISS THE TIME LIMIT IN A TRIAL, IT WILL BE REPEATED IN THE END. \n\n Press any key when you are ready! '], 'center', 150, 0);
oldtime = Screen(wPtr, 'Flip');
KbStrokeWait;
%HideCursor;

rng('shuffle');

% here we find the proper videos and pre-process them.
services = zeros(1,size(contactPointsNames,2));
trainingIndex = zeros(1,size(contactPointsNames,2));
DirectionsAll = zeros(1,size(contactPointsNames,2)); % 1 for Line, 2 for Cross
% first find the Services / Returns :
% then find the player 2 for training:
directions = zeros(1,size(contactPointsNames,2));
for i = 1 : size(contactPointsNames,2)
    temp = contactPointsNames{i};
    if (temp.filename(1) == ServiceOrReturn) % finding the service/return shots
        services(i) = 1;
        if (temp.playerName == ExperimentPlayerIndices(1)) % finding player A for test set
            trainingIndex(i) = 1;
        else if (temp.playerName == ExperimentPlayerIndices(2)) % finding player B for test set
                trainingIndex(i) = 2;
            else if (temp.playerName == ExperimentPlayerIndices(3)) % finding player C for test set
                    trainingIndex(i) = 3;
                end
            end
        end
        if (temp.filename(3) == 'L') % finding the directions
            directions(i) = 1;
        else
            directions(i) = 2;
        end
    end
end
clear temp;
directionsLine = find(directions == 1); % directionsLine saves the indices of Line shots
directionsCross = find(directions == 2); % directionsLine saves the indices of Cross shots
namesIndices1 = find(trainingIndex == ExperimentPlayerIndices(1)); % namesIndices saves the indecis of Player A Serving.
namesIndices2 = find(trainingIndex == ExperimentPlayerIndices(2)); % namesIndices saves the indecis of Player C Serving.
namesIndices3 = find(trainingIndex == ExperimentPlayerIndices(3)); % namesIndices saves the indecis of Player D Serving.

for i = 1 : size(namesIndices1,2)
    for j = 1 : size(directionsLine,2)
        if (namesIndices1(i) == directionsLine(j))
            Player1Linestemp(i) = directionsLine(j);
        end
    end
end
Player1Linesindices = find(Player1Linestemp);
Player1Lines = Player1Linestemp(Player1Linesindices);
clear Player1Linesindices Player1Linestemp;
for i = 1 : size(namesIndices1,2)
    for j = 1 : size(directionsCross,2)
        if (namesIndices1(i) == directionsCross(j))
            Player1Crossestemp(i) = directionsCross(j);
        end
    end
end
Player1Crossesindices = find(Player1Crossestemp);
Player1Crosses = Player1Crossestemp(Player1Crossesindices);
DirectionsAll(Player1Lines) = 1;
DirectionsAll(Player1Crosses) = 2;

clear Player1Crossesindices Player1Crossestemp;
%**********************************************
for i = 1 : size(namesIndices2,2)
    for j = 1 : size(directionsLine,2)
        if (namesIndices2(i) == directionsLine(j))
            Player2Linestemp(i) = directionsLine(j);
        end
    end
end
Player2Linesindices = find(Player2Linestemp);
Player2Lines = Player2Linestemp(Player2Linesindices);
clear Player2Linesindices Player2Linestemp;
for i = 1 : size(namesIndices2,2)
    for j = 1 : size(directionsCross,2)
        if (namesIndices2(i) == directionsCross(j))
            Player2Crossestemp(i) = directionsCross(j);
        end
    end
end
Player2Crossesindices = find(Player2Crossestemp);
Player2Crosses = Player2Crossestemp(Player2Crossesindices);
DirectionsAll(Player2Lines) = 1;
DirectionsAll(Player2Crosses) = 2;

clear Player2Crossesindices Player2Crossestemp;
%**********************************************
for i = 1 : size(namesIndices3,2)
    for j = 1 : size(directionsLine,2)
        if (namesIndices3(i) == directionsLine(j))
            Player3Linestemp(i) = directionsLine(j);
        end
    end
end
Player3Linesindices = find(Player3Linestemp);
Player3Lines = Player3Linestemp(Player3Linesindices);
clear Player4Linesindices Player4Linestemp;
for i = 1 : size(namesIndices3,2)
    for j = 1 : size(directionsCross,2)
        if (namesIndices3(i) == directionsCross(j))
            Player3Crossestemp(i) = directionsCross(j);
        end
    end
end
Player3Crossesindices = find(Player3Crossestemp);
Player3Crosses = Player3Crossestemp(Player3Crossesindices);
DirectionsAll(Player3Lines) = 1;
DirectionsAll(Player3Crosses) = 2;

clear Player3Crossesindices Player3Crossestemp;
%**********************************************
%Now randomly select 5 videos from each player for each direction.
indicesList = zeros(1,numPlayers*numDirections*numShotsPerPlayer);
indicesList1L = zeros(1,numShotsPerPlayer);
indicesList1C = zeros(1,numShotsPerPlayer);
indicesList2L = zeros(1,numShotsPerPlayer);
indicesList2C = zeros(1,numShotsPerPlayer);
indicesList3L = zeros(1,numShotsPerPlayer);
indicesList3C = zeros(1,numShotsPerPlayer);

if (size(Player1Lines,2)>numShotsPerPlayer-1)
    indicesList1L = Player1Lines(randperm(size(Player1Lines,2),numShotsPerPlayer));
else
    indicesList1L = Player1Lines(randperm(size(Player1Lines,2)));
    while (size(indicesList1L,2)< numShotsPerPlayer)
        temp = Player1Lines(randperm(size(Player1Lines,2),1));
        indicesList1L = [indicesList1L temp];
    end
end
clear temp;
if (size(Player1Crosses,2)>numShotsPerPlayer-1)
    indicesList1C = Player1Crosses(randperm(size(Player1Crosses,2),numShotsPerPlayer));
else
    indicesList1C = Player1Crosses(randperm(size(Player1Crosses,2)));
    while (size(indicesList1C,2)< numShotsPerPlayer)
        temp = Player1Crosses(randperm(size(Player1Crosses,2),1));
        indicesList1C = [indicesList1C temp];
    end
end
clear temp;
%*****************
if (size(Player2Lines,2)>numShotsPerPlayer-1)
    indicesList2L = Player2Lines(randperm(size(Player2Lines,2),numShotsPerPlayer));
else
    indicesList2L = Player2Lines(randperm(size(Player2Lines,2)));
    while (size(indicesList2L,2)< numShotsPerPlayer)
        temp = Player2Lines(randperm(size(Player2Lines,2),1));
        indicesList2L = [indicesList2L temp];
    end
end
clear temp;
if (size(Player2Crosses,2)>numShotsPerPlayer-1)
    indicesList2C = Player2Crosses(randperm(size(Player2Crosses,2),numShotsPerPlayer));
else
    indicesList2C = Player2Crosses(randperm(size(Player2Crosses,2)));
    while (size(indicesList2C,2)< numShotsPerPlayer)
        temp = Player2Crosses(randperm(size(Player2Crosses,2),1));
        indicesList2C = [indicesList2C temp];
    end
end
clear temp;
%*****************
if (size(Player3Lines,2)>numShotsPerPlayer-1)
    indicesList3L = Player3Lines(randperm(size(Player3Lines,2),numShotsPerPlayer));
else
    indicesList3L = Player3Lines(randperm(size(Player3Lines,2)));
    while (size(indicesList3L,2)< numShotsPerPlayer)
        temp = Player3Lines(randperm(size(Player3Lines,2),1));
        indicesList3L = [indicesList3L temp];
    end
end
clear temp;
if (size(Player3Crosses,2)>numShotsPerPlayer-1)
    indicesList3C = Player3Crosses(randperm(size(Player3Crosses,2),numShotsPerPlayer));
else
    indicesList3C = Player3Crosses(randperm(size(Player3Crosses,2)));
    while (size(indicesList3C,2)< numShotsPerPlayer)
        temp = Player3Crosses(randperm(size(Player3Crosses,2),1));
        indicesList3C = [indicesList3C temp];
    end
end
clear temp;
indicesList = [indicesList1L indicesList1C indicesList2L indicesList2C indicesList3L indicesList3C];

trialRepeat = zeros(1,numTrials);

randNums = randperm(size(indicesList,2)); % Create the indices in random order
BBKron = ones(1,int8(floor(numTrials/size(randNums,2))));
trialRepeatTemp = kron(randNums,BBKron); % Expand the matrix to the size needed

leftOver = size(trialRepeat,2) - size(trialRepeatTemp,2);
trialRepeat(1:size(trialRepeatTemp,2)) = trialRepeatTemp;
trialRepeat(size(trialRepeatTemp,2)+1:size(trialRepeatTemp,2)+leftOver) = randperm(size(indicesList,2),leftOver);
idx = randperm(length(trialRepeat));
xperm = trialRepeat(idx);
trialRepeatFinal = xperm;
droppedIndicestoRepeat = 1;
trialsWithDroppedFrames = zeros(numTrials,1);
slowIndicestoRepeat = 1;
trialsWithLateResponses = zeros(numTrials,1);

%trialRepeatFinal = ceil(randperm(numTrials) / size(indices,2)); This works
%only with predefined numbers i.e. fixed numebr of trials, etc.

numGaussianCenters = round(exp(QuestQuantile(qQuest)));
if numGaussianCenters < 1
    numGaussianCenters  = 1;
end
trialIndex = 1;
while trialIndex <= numTrials % Number of trials
    if trialIndex == 51 % at 50th trial we want to make sure the numGaussias is reasonable
        sumNumGaussians = 0;
        for jjindex = 41 : 50
            tempnumGaussians = ResultsExperiment{jjindex};
            sumNumGaussians = sumNumGaussians + tempnumGaussians.numGaussians;
            clear tempnumGaussians;
        end
        if ((sumNumGaussians > (maxNumGaussians*9)) && (timeThreshold < 0.600)) %180 %600
            timeThreshold = timeThreshold + 0.05;
            Screen(wPtr, 'Flip');
            DrawFormattedText(wPtr,['It seems the time limit is too low for you. Added 50ms. \n\n New time limit:' num2str(timeThreshold) '. \n\n Press any key to continue '], 'center', 240, Blue);
            Screen(wPtr, 'Flip');
            KbStrokeWait;
            clear qQuest;
            qQuest = QuestCreateNormal(log(10),5,(3 - DeltaValue) / 4,BetaValue,DeltaValue,0.5,0.1,4);
            numGaussianCenters = round(exp(QuestQuantile(qQuest)));
            if numGaussianCenters < 1
                numGaussianCenters  = 1;
            end
            trialIndex = trialIndex - 50;
            score = 0;
        end
    end
    index = indicesList(trialRepeatFinal(trialIndex));
    temp = contactPointsNames{index};
    videoName = temp.filename; % find the video name
    VideoContactPoint = temp.Frame; % find the ball contact point frame
    VideoDirection = temp.filename(3); % find the direction of the serv L for Line, C for Cross
    if (ispc)
        videoName = strcat('C:\TennisVideosGray\',videoName,'Gray.mat');
        savePath = 'C:\TennisVideosGray\Results\Experiment\';
    else
        videoName = strcat('/Users/sepehr/Desktop/TennisVideosGray/',videoName,'Gray.mat');
        savePath = '/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/';
    end
    load(videoName); % the structure name is Vid
    nFrames = size(Vid,3);
    nHeight = size(Vid,1);
    nWidth = size(Vid,2);
    VidResized = Vid(vidResHS:vidResHE,vidResWS:vidResWE,:); % to adjust to the screen size resolution
    %clear Vid;
    
    startPoint = VideoContactPoint - numFramesBeforeBC; % 1000ms/20 frames before Ball Contact point.
    relativeContactPoint = numFramesBeforeBC;
    if( startPoint < 1)
        startPoint =1;
        relativeContactPoint = VideoContactPoint;
    end
    endPoint = VideoContactPoint + numFramesAfterBC;
    if ( endPoint > nFrames)
        endPoint = nFrames;
    end
    VidNonNoised = VidResized;
    [VidNoised, FinalValMask, maskStartCoords] = CreateSpatialGaussianNoise(Vid(:,:,startPoint:endPoint), numGaussianCenters, Var , upper(ServiceOrReturn));
    
    
    Vid = VidNoised(vidResHS:vidResHE,vidResWS:vidResWE,:);
    clear VidNosied;
    timeFramematrix = zeros(121,2);
    j = 1;
    abortit = 0;
    Screen('Close');
    for kkkk = j : relativeContactPoint + numFramesAfterBC
        textureIndex(kkkk) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk)); %
    end
    if (relativeContactPoint + numFramesAfterBC + 1 > nFrames)
        textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk)); %
    else
        textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk+1)); %
    end
    matrixtemp = zeros(numFramesBeforeBC + numFramesAfterBC,1);
    matrixtempIndex = relativeContactPoint - numFramesBeforeBC;
    
    
    %    for j = 1 : nFrames
    %Frame = Vid(:,:,i); %720*1280 H,W
    % 'rect(3:4)' shows the screen size by W,H
    %         textureIndex=Screen('MakeTexture', wPtr, Vid(:,:,j)); %
    %         Screen('DrawTexture', wPtr, textureIndex);
    %         Screen(wPtr, 'Flip'); % if you comment this line, you'll see the code is capable of 540fps.
    %    end
    
    %Another section of code relating to the DAQ
    if UsePedals == 1
        %alreadyRT = false;
        alreadyRT = true;
        s.startBackground();
    end
    %pedalsInput = ones(1,2); % assumes feet are back on the pedals
    
    %end DAQ section
    
    
    
    DontMoveOn = 1;
    
    while DontMoveOn == 1
        
        pause(0.1);
        
        [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
        
        if (keyIsDown==1)
            DontMoveOn = 0;
        end;
        
        if UsePedals == 1
            if (sum(pedalsInput) == 2) %both pedals down
                DontMoveOn = 0;
            end
        end
        
    end
    
    
    %Another section of code relating to the DAQ
    if UsePedals == 1
        alreadyRT = false;
        %s.startBackground();
    end
    
    try
        Priority(PriorityMax);
        responseFrameFlag = 0; % for saving responsing frame
        vbltime = Screen('Flip', wPtr);
        PlaybackStart = GetSecs;
        
        Screen('DrawTexture', wPtr, textureIndex(j));
        
        while (abortit<1)
            vbltime = Screen('Flip', wPtr, vbltime+(0.5* monitorFlipInterval),2);
            [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
            matrixtemp(j) = vbltime;
            Screen('DrawTexture', wPtr, textureIndex(j+1));
            if (j ==  relativeContactPoint)
                contactTimeFlag = GetSecs;
                %Another section of code relating to the DAQ
                if UsePedals == 1
                    timeZero = now;
                end
                %end DAQ section
            end
            
            if (keyIsDown==1 && keyCode(esc))
                abortit=3; % ESC key is pressed
                break;
            end;
            %NEXT LINE MODIFIED TO WORK WITH DAQ
            if (((keyIsDown==1 && keyCode(right)) || ((pedalsInput(2) == 0) && (pedalsInput(1) == 1))))
                % Save time selecting as Cross detection
                responseTimeflag = GetSecs;
                responseDirection = 'C';
                responseFrameFlag = responseFrameFlag+j;
                if (j < relativeContactPoint)
                    jtemp = j;
                    for k = jtemp :relativeContactPoint
                        vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                        if (j+1==relativeContactPoint)
                            contactTimeFlag = GetSecs;
                            %Another section of code relating to the DAQ
                            if UsePedals == 1
                                timeZero = now;
                            end
                            %end DAQ section
                            
                        end
                        Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                        matrixtemp(j +1) = vbltime;
                        j = j+1;
                    end
                end
                abortit = 1; % RIGHT Arrow Key is Pressed
            end;
            %NEXT LINE MODIFIED TO WORK WITH DAQ
            if (((keyIsDown==1 && keyCode(left)) || ((pedalsInput(1) == 0) && (pedalsInput(2) == 1)) ))
                % Save time selecting as Line detection
                responseTimeflag = GetSecs;
                responseDirection = 'L';
                responseFrameFlag = responseFrameFlag+j;
                if (j < relativeContactPoint)
                    
                    jtemp = j;
                    for k = jtemp :relativeContactPoint
                        vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                        if (j+1==relativeContactPoint)
                            contactTimeFlag = GetSecs;
                            
                            %Another section of code relating to the DAQ
                            if UsePedals == 1
                                timeZero = now;
                            end
                            %end DAQ section
                        end
                        Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                        matrixtemp(j +1) = vbltime;
                        j = j+1;
                    end
                end
                abortit = 2; % LEFT Arrow Key is Pressed
            end;
            
            if (j < (endPoint - startPoint-1))% to show up to 24 frames after ball contact
                j = j+1;
            elseif (abortit == 0) %no response yet
                responseFrameFlag = responseFrameFlag + 1;
            end
            
            
        end;
        Priority(0);
        if (abortit ==3)
            break;
        end
        
        vblstimes = diff(matrixtemp); % confirm it works when response is before contact
        endofvblstimes = j-1 ;
        if (endofvblstimes > 0)
            vblstimes(endofvblstimes:end) = 0;
        end
        missedFramesIndices = find(vblstimes> 1.5* monitorFlipInterval) + 1;
        numMissedFrames = numel(missedFramesIndices);
        numCriticalMissedFrames = sum(missedFramesIndices > (numFramesAfterBC - (2 * numFramesBeforeBC))); % (120 - 48): 24 frames before and after ball contact point
        
        responseTime = responseTimeflag - contactTimeFlag;
        responseFrame = responseFrameFlag - relativeContactPoint;
        
        %NOTE FROM KIELAN: I've modified this bit!
        responseTimeBinned = round(responseTime * FrameRate) / FrameRate;
        displayedFrameRate = responseFrame / responseTimeBinned;
        
        %Another section of code relating to the DAQ
        if UsePedals == 1
            FrameRT(trialIndex) = responseTime;
            if (sum(pedalsInput) < 2) %pedal response made on this trial
                responseTime = pedalTime - ((timeZero - absolutePedalStart).*24.*60.*60);
            end
            AcRT(trialIndex) = responseTime;
        end
        %end DAQ
        
        if (responseTimeBinned == 0)
            displayedFrameRate = FrameRate;
        end
        
        
        if (responseTime > timeThreshold)
            respondWithinTimeLine = 0;
            if (responseDirection == VideoDirection)
                score = score -5;
            else
                score = score -5;
            end
        else
            respondWithinTimeLine = 1;
            if (responseDirection == VideoDirection)
                score = score +10;
            else
                score = score + 2;
            end
        end
        
        if (responseDirection == VideoDirection)
            directionCorrect = 1; % if the direction is correct
        else
            directionCorrect = 0;
        end
        
        %save the response:
        TrialResults.directionCorrect = directionCorrect;  % This saves the results from this trial.
        TrialResults.respondWithinTimeLine = respondWithinTimeLine;
        TrialResults.responseTimeBinned =responseTimeBinned;
        TrialResults.responseTime = responseTime;
        TrialResults.respondFrame = responseFrame;
        TrialResults.directionReal = VideoDirection;
        TrialResults.ballContactFrame = VideoContactPoint;
        TrialResults.Type = ServiceOrReturn;
        TrialResults.VideoName = videoName;
        TrialResults.Threshold = timeThreshold;
        TrialResults.score = score;
        TrialResults.missedFramesIndices = missedFramesIndices;
        TrialResults.numMissedFrames = numMissedFrames;
        TrialResults.numCriticalMissedFrames = numCriticalMissedFrames;
        TrialResults.displayedFrameRate = displayedFrameRate;
        TrialResults.numGaussians = numGaussianCenters;
        TrialResults.FinalValMask = FinalValMask;
        TrialResults.maskStartCoords = maskStartCoords;
        ResultsExperiment{trialIndex} = TrialResults;
        
        if (numCriticalMissedFrames > 0) % to repeat the ones with Critical Dropped frames
            trialsWithDroppedFrames(droppedIndicestoRepeat) = trialIndex;
            droppedIndicestoRepeat = droppedIndicestoRepeat + 1;
        end
        
        if (~respondWithinTimeLine) % to repeat the ones with Slow answers
            trialsWithLateResponses(slowIndicestoRepeat) = trialIndex;
            slowIndicestoRepeat = slowIndicestoRepeat + 1;
        end
        
        Screen(wPtr, 'Flip');
        DrawFormattedText(wPtr,['Previous Number of Masks : ' num2str(numGaussianCenters) '. '], 'center', 240, Blue);
        
        %analyse the response: Use a staircase to optimize the Gaussian number
        if trialIndex > 5 % do not update the quest the first 5 times
            if (respondWithinTimeLine)
                if (directionCorrect)
                    qQuest = QuestUpdate(qQuest,log(numGaussianCenters),1);                
                %
                %                 gaussianCounter = gaussianCounter +1;
                %                 if (gaussianCounter >2)
                %                     numGaussianCenters = numGaussianCenters - 1; % deduct 1
                %                     gaussianCounter = 0;
                %                 end
            else  %
                %numGaussianCenters = numGaussianCenters + 1;  % add 1
                qQuest = QuestUpdate(qQuest,log(numGaussianCenters),0);
                end
            end
            %else %make modifications ONLY if they have responded in time
            %NumGaussianCenters = NumGaussianCenters + 3;  % add 3
        end
    
        
        if (responseDirection == 'L')
            responseText = 'Line';
        else
            responseText = 'Cross';
        end
        if (responseDirection == VideoDirection)
            responseText = strcat(responseText,' Correctly');
        else
            responseText = strcat(responseText,' Incorrectly');
        end
        
        numGaussianCenters = round(exp(QuestQuantile(qQuest)));
        if numGaussianCenters < 1
            numGaussianCenters  = 1;
        end
        if (numGaussianCenters > maxNumGaussians)
            numGaussianCenters = maxNumGaussians;
        end

        DrawFormattedText(wPtr,['Next Number of Masks : ' num2str(numGaussianCenters) '. '], 'center', 260, Blue);
        
        
        if (trialIndex < numTrials-1)
            DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
            Screen('TextSize', wPtr, 20);
            DrawFormattedText(wPtr, ['\n\n Press any key or step back on both pedals \n\n to go for trial ' num2str(trialIndex +1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
            Screen('TextSize', wPtr, 15);
            Screen(wPtr, 'Flip',[],1);
        else
            if (trialIndex == numTrials)
                DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                Screen('TextSize', wPtr, 20);
                DrawFormattedText(wPtr, '\n\n Press any key or step back on both pedals to continue', 'center', 670, 0);
                Screen('TextSize', wPtr, 15);
                Screen(wPtr, 'Flip',[],1);
            else
                DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTimeBinned*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                Screen('TextSize', wPtr, 20);
                DrawFormattedText(wPtr, ['\n\n Press any key or step back on both pedals \n\n to go for trial ' num2str(trialIndex +1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
                Screen('TextSize', wPtr, 15);
                Screen(wPtr, 'Flip',[],1);
            end
        end
        Screen('TextSize', wPtr, 25);
        if (responseTime > timeThreshold)
            if (responseDirection == VideoDirection);
                DrawFormattedText(wPtr,'You took too long but answered correctly!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                Screen('TextSize', wPtr, 25);
                DrawFormattedText(wPtr,'ACCURATE, ', 'center', 430, Blue);
                Screen('TextSize', wPtr, 35);
                DrawFormattedText(wPtr,['BUT SLOW!!! BE FASTER!!!\n\n Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 465, Red);
                Screen('TextSize', wPtr, 25);
                Screen(wPtr, 'Flip');
            else
                DrawFormattedText(wPtr,'You took too long and were wrong!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                Screen('TextSize', wPtr, 30);
                DrawFormattedText(wPtr,['SLOW AND INACCURATE!!! \n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 430, Red);
                Screen('TextSize', wPtr, 25);
                Screen(wPtr, 'Flip');
            end
        else
            if (responseDirection == VideoDirection)
                DrawFormattedText(wPtr,'Well done!!! You answered correctly in the time limit!\n\n You get 10 points!', 'center', 150, Blue);
                DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                Screen('TextSize', wPtr, 35);
                DrawFormattedText(wPtr,['FAST AND ACCURATE!!! WELL DONE!!!\n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 430, Green);
                Screen('TextSize', wPtr, 25);
                Screen(wPtr, 'Flip');
            else
                DrawFormattedText(wPtr,'You answered wrong in the time limit! \n\n You get 2 points! ', 'center', 150, Red);
                DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(trialIndex*10)  ' so far.'], 'center', 640, Black);
                Screen('TextSize', wPtr, 35);
                DrawFormattedText(wPtr,['FAST ENOUGH! Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 430, Blue);
                Screen('TextSize', wPtr, 25);
                DrawFormattedText(wPtr,'BUT INACCURATE!!! BE MORE PRECISE!!!', 'center', 540, Red);
                Screen(wPtr, 'Flip');
            end
        end
        
        %****
        %DAQ stuff
        if UsePedals == 1
            s.stop();
        end
        %end of daq stuff
        
        Screen('TextSize', wPtr, 15);
        clear Vid FinalValMask relativeContactPoint textureIndex PlaybackStart responseTimeflag temp videoName VideoContactPoint VideoDirection VidResized TrialResults textureIndex matrixtemp missedFramesIndices ;
    catch
        savePath = strcat(savePath,ExperimentName,'ERROR.mat');
        save(savePath,'ResultsExperiment');
        Screen('Flip', wPtr);
        DrawFormattedText(wPtr,'Experiment Aborted due to unknown technical error\n\n... Tried to save... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, Red);
        Screen(wPtr, 'Flip');
        KbStrokeWait;
        Screen('CloseAll');
    end
    if (abortit ==3)
        %DAQ stuff
        if UsePedals == 1
            s.stop();
        end
        %end of daq stuff
        savePath = strcat(savePath,ExperimentName,'ESC.mat');
        save(savePath,'ResultsExperiment');
        Screen('Flip', wPtr);
        DrawFormattedText(wPtr,'Experiment Aborted by pressing the ESC key \n\n... data saved until ESC key pressed... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, Red);
        Screen(wPtr, 'Flip');
        KbStrokeWait;
        Screen('CloseAll');
        break;
    end
    trialIndex = trialIndex  + 1 ;
end
%**** LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
numTrialsAll = numTrials;
numTrialsToRepeatDroppedFrames = size(find(trialsWithDroppedFrames),1);
numTrialsToRepeatLateResponse = size(find(trialsWithLateResponses),1);
anyTrialsToRepeat = 0;
[~ , ~, DroppedIndices] = find(trialsWithDroppedFrames);
[~ , ~, LateIndices] = find(trialsWithLateResponses);
allIndicestoRepeatTemp = [LateIndices; DroppedIndices];
allIndicestoRepeat = unique(allIndicestoRepeatTemp);

if (numTrialsToRepeatDroppedFrames > 0 || numTrialsToRepeatLateResponse > 0 && abortit ~= 3)
    anyTrialsToRepeat = 1;
    Screen('TextSize', wPtr, 25);
    Screen('Flip', wPtr);
    DrawFormattedText(wPtr,['There were ' num2str(numTrialsToRepeatDroppedFrames) ' trial(s) with Dropped Frames and \n\n' num2str(numTrialsToRepeatLateResponse) ' trial(s) which you responded late. \n\n A total of ' num2str(size(allIndicestoRepeat,1)) ' need to be repeated...\n\n Press any key to continue...' ] , 'center', 240, Red);
    Screen(wPtr, 'Flip');
    Screen('TextSize', wPtr, 15);
    KbStrokeWait;
end
%Screen('Close',wPtr2); % for test purposes.

while (anyTrialsToRepeat && abortit ~= 3)
    
    numTrials = size(allIndicestoRepeat,1);
    clear allIndicestoRepeatTemp;
    droppedIndicestoRepeat = 1;
    trialsWithDroppedFrames = zeros(numTrials,1);
    slowIndicestoRepeat = 1;
    trialsWithLateResponses = zeros(numTrials,1);
    
    for iii = 1 : numTrials
        temp = ResultsExperiment{allIndicestoRepeat(iii)};
        if (temp.respondWithinTimeLine)
            if (temp.directionCorrect)
                score = score -10;
            else
                score = score -2;
            end
        else
            score = score +5;
        end
        clear temp;
    end
    oldScoreMax = 10*(numTrialsAll - numTrials);
    clear iii;
    for newRepeatIndex = 1 : numTrials % Number of trials
        trialIndex = allIndicestoRepeat(newRepeatIndex);
        index = indicesList(trialRepeatFinal(trialIndex));
        temp = contactPointsNames{index};
        videoName = temp.filename; % find the video name
        VideoContactPoint = temp.Frame; % find the ball contact point frame
        VideoDirection = temp.filename(3); % find the direction of the serv L for Line, C for Cross
        if (ispc)
            videoName = strcat('C:\TennisVideosGray\',videoName,'Gray.mat');
            savePath = 'C:\TennisVideosGray\Results\Experiment\';
        else
            videoName = strcat('/Users/sepehr/Desktop/TennisVideosGray/',videoName,'Gray.mat');
            savePath = '/Users/sepehr/Desktop/TennisVideosGray/Results/Experiment/';
        end
        load(videoName); % the structure name is Vid
        nFrames = size(Vid,3);
        nHeight = size(Vid,1);
        nWidth = size(Vid,2);
        VidResized = Vid(vidResHS:vidResHE,vidResWS:vidResWE,:); % to adjust to the screen size resolution
        %clear Vid;
        
        startPoint = VideoContactPoint - numFramesBeforeBC; % 1000ms/20 frames before Ball Contact point.
        relativeContactPoint = numFramesBeforeBC;
        if( startPoint < 1)
            startPoint =1;
            relativeContactPoint = VideoContactPoint;
        end
        endPoint = VideoContactPoint + numFramesAfterBC;
        if ( endPoint > nFrames)
            endPoint = nFrames;
        end
        VidNonNoised = VidResized;
        
        
        
        % Load previous bubbles profile used for this video
        TrialResults = ResultsExperiment{trialIndex};
        numGaussianCenters = TrialResults.numGaussians;
        finalMask = TrialResults.FinalValMask;
        FinalValMask = finalMask;
        clear TrialResults;
        %        VidNosied = CreateSpatioTemporalGaussianNoise(Vid(:,:,startPoint:endPoint), numGaussianCenters, Var , upper(ServiceOrReturn));
        varianceMean = Var;
        if upper(ServiceOrReturn) =='S'
            startX = 180 - varianceMean;%261;
            endX = 420 + varianceMean;%460;
            startY = 380 - varianceMean;%391;
            endY = 700 + varianceMean;%640;
        else% For Returns
            startX = 240 - varianceMean;%261;
            endX = 440 +  varianceMean;%460;
            startY = 320 - varianceMean ;%391;
            endY = 760 + varianceMean;%640;
        end
        finalVid = Vid(:,:,startPoint:endPoint);
        movie = finalVid(startX:endX,startY:endY,:); % DEFINING THE MEANINGFUL PART OF THE VIDEO
        framesRange = (1:size(finalVid,3));
        tempVid = single(movie);
        clear movie;
        
        for indexG = 1 : size(framesRange,2);
            tempFrame = tempVid(:,:,framesRange(indexG));
            meanTempFrame = mean(mean(tempFrame));
            tempFramDeducted = tempFrame - meanTempFrame;
            
            tempFrame = (tempFramDeducted .* finalMask) + meanTempFrame;
            %%%
            %tempVid(:,:,framesRange(i)) = tempFrame;
            
            finalVid(1:startX,1:end,framesRange(indexG)) = meanTempFrame;
            finalVid(endX:end,1:end,framesRange(indexG)) = meanTempFrame;
            finalVid(1:endX,1:startY,framesRange(indexG)) = meanTempFrame;
            finalVid(1:endX,endY:end,framesRange(indexG)) = meanTempFrame;
            
            finalVid(startX:endX,startY:endY,framesRange(indexG)) = tempFrame;
            clear tempFrame;
        end
        VidNoised = uint8(finalVid);
        Vid = VidNoised(vidResHS:vidResHE,vidResWS:vidResWE,:);
        
        clear VidNosied finalVid tempVid tempFrame meanTempFrame tempFramDeducted;
        timeFramematrix = zeros(121,2);
        j = 1;
        abortit = 0;
        Screen('Close');
        for kkkk = j : relativeContactPoint + numFramesAfterBC
            textureIndex(kkkk) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk)); %
        end
        if (relativeContactPoint + numFramesAfterBC + 1 > nFrames)
            textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk)); %
        else
            textureIndex(kkkk+1) =Screen('MakeTexture', wPtr, Vid(:,:,kkkk+1)); %
        end
        matrixtemp = zeros(numFramesBeforeBC + numFramesAfterBC,1);
        matrixtempIndex = relativeContactPoint - numFramesBeforeBC;
        
        %    for j = 1 : nFrames
        %Frame = Vid(:,:,i); %720*1280 H,W
        % 'rect(3:4)' shows the screen size by W,H
        %         textureIndex=Screen('MakeTexture', wPtr, Vid(:,:,j)); %
        %         Screen('DrawTexture', wPtr, textureIndex);
        %         Screen(wPtr, 'Flip'); % if you comment this line, you'll see the code is capable of 540fps.
        %    end
        
        %Another section of code relating to the DAQ
        if UsePedals == 1
            %alreadyRT = false;
            alreadyRT = true;
            %pause(0.1);
            s.startBackground();
        end
        %pedalsInput = ones(1,2); % assumes feet are back on the pedals
        
        %end DAQ section
        
        
        
        DontMoveOn = 1;
        
        while DontMoveOn == 1
            
            pause(0.1);
            
            [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
            
            if (keyIsDown==1)
                DontMoveOn = 0;
            end;
            
            if UsePedals == 1
                if (sum(pedalsInput) == 2) %both pedals down
                    DontMoveOn = 0;
                end
            end
            
        end
        
        
        %Another section of code relating to the DAQ
        if UsePedals == 1
            alreadyRT = false;
            %s.startBackground();
        end
        
        
        try
            Priority(PriorityMax);
            responseFrameFlag = 0; % for saving responsing frame
            vbltime = Screen('Flip', wPtr);
            PlaybackStart = GetSecs;
            
            Screen('DrawTexture', wPtr, textureIndex(j));
            
            while (abortit<1)
                vbltime = Screen('Flip', wPtr, vbltime+(0.5* monitorFlipInterval),2);
                [keyIsDown,secs,keyCode,deltaSecs] = KbCheck;
                matrixtemp(j) = vbltime;
                Screen('DrawTexture', wPtr, textureIndex(j+1));
                if (j ==  relativeContactPoint)
                    contactTimeFlag = GetSecs;
                    %Another section of code relating to the DAQ
                    if UsePedals == 1
                        timeZero = now;
                    end
                    %end DAQ section
                end
                
                if (keyIsDown==1 && keyCode(esc))
                    abortit=3; % ESC key is pressed
                    break;
                end;
                %NEXT LINE MODIFIED TO WORK WITH DAQ
                if (((keyIsDown==1 && keyCode(right)) || ((pedalsInput(2) == 0) && (pedalsInput(1) == 1))))
                    % Save time selecting as Cross detection
                    responseTimeflag = GetSecs;
                    responseDirection = 'C';
                    responseFrameFlag = responseFrameFlag+j;
                    if (j < relativeContactPoint)
                        jtemp = j;
                        for k = jtemp :relativeContactPoint
                            vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                            if (j+1==relativeContactPoint)
                                contactTimeFlag = GetSecs;
                                %Another section of code relating to the DAQ
                                if UsePedals == 1
                                    timeZero = now;
                                end
                                %end DAQ section
                                
                            end
                            Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                            matrixtemp(j +1) = vbltime;
                            j = j+1;
                        end
                    end
                    abortit = 1; % RIGHT Arrow Key is Pressed
                end;
                %NEXT LINE MODIFIED TO WORK WITH DAQ
                if (((keyIsDown==1 && keyCode(left)) || ((pedalsInput(1) == 0) && (pedalsInput(2) == 1)) ))
                    % Save time selecting as Line detection
                    responseTimeflag = GetSecs;
                    responseDirection = 'L';
                    responseFrameFlag = responseFrameFlag+j;
                    if (j < relativeContactPoint)
                        
                        jtemp = j;
                        for k = jtemp :relativeContactPoint
                            vbltime =Screen(wPtr, 'Flip', vbltime+(0.5* monitorFlipInterval));
                            if (j+1==relativeContactPoint)
                                contactTimeFlag = GetSecs;
                                
                                %Another section of code relating to the DAQ
                                if UsePedals == 1
                                    timeZero = now;
                                end
                                %end DAQ section
                            end
                            Screen('DrawTexture', wPtr, textureIndex(jtemp+1));
                            matrixtemp(j +1) = vbltime;
                            j = j+1;
                        end
                    end
                    abortit = 2; % LEFT Arrow Key is Pressed
                end;
                
                if (j < (endPoint - startPoint-1))% to show up to 24 frames after ball contact
                    j = j+1;
                elseif (abortit == 0) %no response yet
                    responseFrameFlag = responseFrameFlag + 1;
                end
                
                
            end;
            Priority(0);
            if (abortit ==3)
                break;
            end
            
            vblstimes = diff(matrixtemp); % confirm it works when response is before contact
            endofvblstimes = j-1 ;
            if (endofvblstimes > 0)
                vblstimes(endofvblstimes:end) = 0;
            end
            missedFramesIndices = find(vblstimes> 1.5* monitorFlipInterval) + 1;
            numMissedFrames = numel(missedFramesIndices);
            numCriticalMissedFrames = sum(missedFramesIndices > (numFramesAfterBC - (2 * numFramesBeforeBC))); % (120 - 48): 24 frames before and after ball contact point
            
            responseTime = responseTimeflag - contactTimeFlag;
            responseFrame = responseFrameFlag - relativeContactPoint;
            
            responseTimeBinned = round(responseTime * FrameRate) / FrameRate;
            
            displayedFrameRate = responseFrame / responseTimeBinned;
            %Another section of code relating to the DAQ
            if UsePedals == 1
                
                if (sum(pedalsInput) < 2) %pedal response made on this trial
                    responseTime = pedalTime - ((timeZero - absolutePedalStart).*24.*60.*60);
                end
                
            end
            %end DAQ
            
            if (responseTimeBinned == 0)
                displayedFrameRate = FrameRate;
            end
            
            
            if (responseTime > timeThreshold)
                respondWithinTimeLine = 0;
                if (responseDirection == VideoDirection)
                    score = score -5;
                else
                    score = score -5;
                end
            else
                respondWithinTimeLine = 1;
                if (responseDirection == VideoDirection)
                    score = score +10;
                else
                    score = score + 2;
                end
            end
            
            if (responseDirection == VideoDirection)
                directionCorrect = 1; % if the direction is correct
            else
                directionCorrect = 0;
            end
            
            %save the response:
            TrialResults.directionCorrect = directionCorrect;  % This saves the results from this trial.
            TrialResults.respondWithinTimeLine = respondWithinTimeLine;
            TrialResults.responseTimeBinned =responseTimeBinned;
            TrialResults.responseTime = responseTime;
            TrialResults.respondFrame = responseFrame;
            TrialResults.directionReal = VideoDirection;
            TrialResults.ballContactFrame = VideoContactPoint;
            TrialResults.Type = ServiceOrReturn;
            TrialResults.VideoName = videoName;
            TrialResults.Threshold = timeThreshold;
            TrialResults.score = score;
            TrialResults.missedFramesIndices = missedFramesIndices;
            TrialResults.numMissedFrames = numMissedFrames;
            TrialResults.numCriticalMissedFrames = numCriticalMissedFrames;
            TrialResults.displayedFrameRate = displayedFrameRate;
            TrialResults.numGaussians = numGaussianCenters;
            TrialResults.FinalValMask = FinalValMask;
            ResultsExperiment{trialIndex} = TrialResults;
            
            if (numCriticalMissedFrames > 0) % to repeat the ones with Critical Dropped frames
                trialsWithDroppedFrames(droppedIndicestoRepeat) = trialIndex;
                droppedIndicestoRepeat = droppedIndicestoRepeat + 1;
            end
            
            if (~respondWithinTimeLine) % to repeat the ones with Slow answers
                trialsWithLateResponses(slowIndicestoRepeat) = trialIndex;
                slowIndicestoRepeat = slowIndicestoRepeat + 1;
            end
            
            Screen(wPtr, 'Flip');
            DrawFormattedText(wPtr,['Previous Number of Masks : ' num2str(numGaussianCenters) '. '], 'center', 240, Blue);
            
            %analyse the response: Use a staircase to optimize the Gaussian number
            if (respondWithinTimeLine)
                if (directionCorrect)
                    gaussianCounter = gaussianCounter +1;
                    if (gaussianCounter >2)
                        numGaussianCenters = numGaussianCenters - 1; % deduct 1
                        gaussianCounter = 0;
                    end
                else  %
                    numGaussianCenters = numGaussianCenters + 1;  % add 3
                end
                %else %make modifications ONLY if they have responded in time
                %NumGaussianCenters = NumGaussianCenters + 3;  % add 3
            end
%             if (numGaussianCenters > maxNumGaussians)
%                 numGaussianCenters = maxNumGaussians;
%             end
%             if (numGaussianCenters < 1)
%                 numGaussianCenters = 1;
%             end
            if (responseDirection == 'L')
                responseText = 'Line';
            else
                responseText = 'Cross';
            end
            if (responseDirection == VideoDirection)
                responseText = strcat(responseText,' Correctly');
            else
                responseText = strcat(responseText,' Incorrectly');
            end
            
            if (newRepeatIndex < numTrials)
                trialIndextempo = allIndicestoRepeat(newRepeatIndex+1);
                TrialResultstempo = ResultsExperiment{trialIndextempo};
                numGaussianCenterstempo = TrialResultstempo.numGaussians;
                DrawFormattedText(wPtr,['Next Number of Masks : ' num2str(numGaussianCenterstempo) '. '], 'center', 260, Blue);
                clear trialIndextempo TrialResultstempo numGaussianCenterstempo;
            end
            
            
            if (newRepeatIndex < numTrials-1)
                DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTime*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                Screen('TextSize', wPtr, 20);
                DrawFormattedText(wPtr, ['\n\n Press any key or step back on both pedals \n\n to go for trial ' num2str(newRepeatIndex +1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
                Screen('TextSize', wPtr, 15);
                Screen(wPtr, 'Flip',[],1);
            else
                if (newRepeatIndex == numTrials)
                    DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTime*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                    Screen('TextSize', wPtr, 20);
                    DrawFormattedText(wPtr, '\n\n Press any key or step back on both pedals to continue', 'center', 670, 0);
                    Screen('TextSize', wPtr, 15);
                    Screen(wPtr, 'Flip',[],1);
                else
                    DrawFormattedText(wPtr, ['You chose ' responseText ' in: \n\n' num2str(responseTime*1000,5) ' Milliseconds) / (' num2str(responseFrame) ' Frames) (' num2str(round(displayedFrameRate),5) ' fps) \n\n after Ball-Contact Point.'], 'center', 300, 0);
                    Screen('TextSize', wPtr, 20);
                    DrawFormattedText(wPtr, ['\n\n Press any key or step back on both pedals \n\n to go for trial ' num2str(newRepeatIndex + 1) ' out of ' num2str(numTrials) ' when you are ready!'], 'center', 670, 0);
                    Screen('TextSize', wPtr, 15);
                    Screen(wPtr, 'Flip',[],1);
                end
            end
            Screen('TextSize', wPtr, 25);
            if (responseTime > timeThreshold)
                if (responseDirection == VideoDirection)
                    %Screen('TextColor', wPtr, Red);
                    DrawFormattedText(wPtr,'You took too long but answered correctly!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(newRepeatIndex*10+oldScoreMax)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 25);
                    DrawFormattedText(wPtr,'ACCURATE, ', 'center', 430, Blue);
                    Screen('TextSize', wPtr, 35);
                    DrawFormattedText(wPtr,['BUT SLOW!!! BE FASTER!!!\n\n Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 465, Red);
                    Screen('TextSize', wPtr, 25);
                    Screen(wPtr, 'Flip');
                else
                    DrawFormattedText(wPtr,'You took too long and were wrong!!!  \n\n You lose 5 points! ', 'center', 150, Red);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(newRepeatIndex*10+oldScoreMax)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 30);
                    DrawFormattedText(wPtr,['SLOW AND INACCURATE!!! \n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 430, Red);
                    Screen('TextSize', wPtr, 25);
                    Screen(wPtr, 'Flip');
                end
            else
                if (responseDirection == VideoDirection)
                    DrawFormattedText(wPtr,'Well done!!! You answered correctly in the time limit!\n\n You get 10 points!', 'center', 150, Blue);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(newRepeatIndex*10+oldScoreMax)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 35);
                    DrawFormattedText(wPtr,['FAST AND ACCURATE!!! WELL DONE!!!\n\n' ' Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(round(timeThreshold*1000),5) ' Milliseconds.'], 'center', 430, Green);
                    Screen('TextSize', wPtr, 25);
                    Screen(wPtr, 'Flip');
                else
                    DrawFormattedText(wPtr,'You answered wrong in the time limit! \n\n You get 2 points! ', 'center', 150, Red);
                    DrawFormattedText(wPtr,['Your score is ' num2str(score) ' out of ' num2str(newRepeatIndex*10+oldScoreMax)  ' so far.'], 'center', 640, Black);
                    Screen('TextSize', wPtr, 35);
                    DrawFormattedText(wPtr,['FAST ENOUGH! Your Time: '  num2str(round(responseTime*1000),5) ', \n\n Time Limit: ' num2str(timeThreshold*1000) ' Milliseconds.'], 'center', 430, Blue);
                    Screen('TextSize', wPtr, 25);
                    DrawFormattedText(wPtr,'BUT INACCURATE!!! BE MORE PRECISE!!!', 'center', 540, Red);
                    Screen(wPtr, 'Flip');
                end
            end
            
            
            %DAQ stuff
            if UsePedals == 1
                s.stop();
            end
            %end of daq stuff
            
            
            Screen('TextSize', wPtr, 15);
            clear Vid FinalValMask relativeContactPoint textureIndex PlaybackStart responseTimeflag temp videoName VideoContactPoint VideoDirection VidResized TrialResults textureIndex matrixtemp missedFramesIndices ;
        catch
            savePath = strcat(savePath,ExperimentName,'ERROR.mat');
            save(savePath,'ResultsExperiment');
            Screen('Flip', wPtr);
            DrawFormattedText(wPtr,'Experiment Aborted due to unknown technical error\n\n... Tried to save... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, Red);
            Screen(wPtr, 'Flip');
            KbStrokeWait;
            Screen('CloseAll');
        end
        if (abortit ==3)
            if UsePedals == 1
                s.stop();
            end
            savePath = strcat(savePath,ExperimentName,'ESC.mat');
            save(savePath,'ResultsExperiment');
            Screen('Flip', wPtr);
            DrawFormattedText(wPtr,'Experiment Aborted by pressing the ESC key \n\n... data saved until ESC key pressed... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, Red);
            Screen(wPtr, 'Flip');
            KbStrokeWait;
            Screen('CloseAll');
            break;
        end
    end
    if (abortit ==3)
        break;
    end
    
    numTrialsToRepeatDroppedFrames = size(find(trialsWithDroppedFrames),1);
    numTrialsToRepeatLateResponse = size(find(trialsWithLateResponses),1);
    anyTrialsToRepeat = 0;
    [~ , ~, DroppedIndices] = find(trialsWithDroppedFrames);
    [~ , ~, LateIndices] = find(trialsWithLateResponses);
    allIndicestoRepeatTemp = [LateIndices; DroppedIndices];
    allIndicestoRepeat = unique(allIndicestoRepeatTemp);
    
    if (numTrialsToRepeatDroppedFrames > 0 || numTrialsToRepeatLateResponse > 0)
        anyTrialsToRepeat = 1;
        Screen('TextSize', wPtr, 35);
        Screen('Flip', wPtr);
        DrawFormattedText(wPtr,['There were \n\n' num2str(numTrialsToRepeatDroppedFrames) ' trial(s) with Dropped Frames and \n\n' num2str(numTrialsToRepeatLateResponse) ' trial(s) which you responded late. \n\n A total of ' num2str(size(allIndicestoRepeat,1)) ' need to be repeated...\n\n Press any key to continue...' ] , 'center', 240, Red);
        Screen(wPtr, 'Flip');
        Screen('TextSize', wPtr, 15);
        KbStrokeWait;
    end
    
end

%**** END OF LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** END OF LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** END OF LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS
%**** END OF LOOPS FOR REPEATING THE DROPPED FRAMES AND MISSED TIME TRIALS


if(abortit ~=3) % the experiment has not been terminated
    savePath = strcat(savePath,ExperimentName,'.mat');
    save(savePath,'ResultsExperiment');
    %reactionTime = calculateReactionTime(ExperimentOccResults);
    clear ResultsExperiment reactionTimeData reactionTimeDataNew SortedIndices finalIndicesRT SortedVals finalIndicesRT output savePath;
else
    savePath = strcat(savePath,ExperimentName,'ESC.mat');
    save(savePath,'ResultsExperiment');
    Screen('Flip', wPtr);
    DrawFormattedText(wPtr,'Experiment Aborted by pressing the ESC key \n\n... data saved until ESC key pressed... Please Restart...  \n\n  Press any key to close the program!', 'center', 240, Red);
    Screen(wPtr, 'Flip');
    KbStrokeWait;
    Screen('CloseAll');
    
    %DAQ Code
    if UsePedals == 1
        delete (lh)
    end
    %end
end
Screen(wPtr, 'Flip');
Screen('TextSize', wPtr, 25);
DrawFormattedText(wPtr,['Occlusion mode of the experiment done!!! Thank you! \n\n\n Your final score in this occlusion experiment is\n\n ' num2str(score) ' out of ' num2str(maxPossibleScore)  ' \n\n  Press any key to close this step!'], 'center', 240, 0);
Screen('TextSize', wPtr, 15);
Screen(wPtr, 'Flip');
KbStrokeWait;




%DAQ Code
if UsePedals == 1
    delete (lh)
    daq.reset
end

    function plotInline(src,event)
        
        transfercounter = transfercounter+1;
        
        if(transfercounter > 100000)
            transfercounter = 1;
        end
        
        if min(event.Data(:,1)) > 2.5
            pedalsInput(1) = 1;
        else
            pedalsInput(1) = 0;
            if alreadyRT == false
                alreadyRT = true;
                absolutePedalStart = event.TriggerTime;
                %recentPedals = event.Data;
                %recentPedalsTimes = event.TimeStamps;
                pedalTime = event.TimeStamps(find(event.Data(:,1)<=2.5, 1 ));
                %pedalTime = event.TimeStamps(length(event.TimeStamps));
            end
        end
        
        if min(event.Data(:,2)) > 2.5
            pedalsInput(2) = 1;
        else
            pedalsInput(2) = 0;
            if alreadyRT == false
                alreadyRT = true;
                absolutePedalStart = event.TriggerTime;
                %recentPedals = event.Data;
                %recentPedalsTimes = event.TimeStamps;
                pedalTime = event.TimeStamps(find(event.Data(:,2)<=2.5, 1 ));
                %pedalTime = event.TimeStamps(length(event.TimeStamps));
            end
        end
        
        
        transferTimes(transfercounter) = GetSecs;
        %plot(event.TimeStamps,event.Data)
    end

%DAQ Code WE CAN COMMENT THIS STUFF OUT AFTER PILOTING IS COMPLETE
% if UsePedals == 1
%     plot(diff(transferTimes(1:transfercounter)))
%     figure
%     scatter(FrameRT,AcRT)
%     Params = polyfit(FrameRT,AcRT,1);
%     Fit = polyval(Params,min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1);
%     hold on
%     plot(min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,Fit)
%     plot(min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,min(FrameRT) - 0.1:0.01:max(FrameRT)+0.1,'r:')
% end
analyse.transsferTimes = transferTimes;
analyse.FrameRT = FrameRT;
analyse.AcRT = AcRT;
savePathnew = 'C:\TennisVideosGray\Results\Experiment\';
savePathnew = strcat(savePathnew,ExperimentName,'analysis.mat');
save(savePathnew,'analyse');
%Daq change - changed this final line to end (from return) due to use of inline
%funtion above
end
