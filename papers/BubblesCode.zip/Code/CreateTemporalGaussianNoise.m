function [movieNoised, FinalValMask] = CreateTemporalGaussianNoise(movie, NumGaussianCenters, Var)
% In this file, we generate the videos of different Gaussian noises.

%First assign random means
%tic
rng('shuffle');

movieNoised = zeros(size(movie,1),size(movie,2),size(movie,3));
tempVid = single(movie);
nFrames = size(movie,3); % if ColorVideo, change to 4
Meansrand = randi([1 nFrames],[1 NumGaussianCenters]);
sizeunique = size(unique(Meansrand),2);
if (size(Meansrand,2) ~= sizeunique)
    while ((size(Meansrand,2) ~= sizeunique))
        Meansrand = randi([1 nFrames],[1 NumGaussianCenters]);
        sizeunique = size(unique(Meansrand),2);
    end
end
Means = sort(Meansrand);
%Deduct the means from each frame
for i = 1 : nFrames
    tempmean(i) = mean(mean(tempVid(:,:,i)));
    tempDeducted(:,:,i) = tempVid(:,:,i) - tempmean(i);
end
%Create masks
mask = zeros(NumGaussianCenters,nFrames);
for i = 1 : NumGaussianCenters
    CenterMean = Means(i);
    normDist = 1/ (Var * sqrt(2*pi));
    minWidth = CenterMean - 4*Var; % taking 4 standard deviations around the mean
    maxWidth = CenterMean + 4*Var;
    if (minWidth < 1)
        minWidth = 1;
    end
    if (maxWidth > nFrames)
        maxWidth = nFrames;
    end
    for j = minWidth : maxWidth
        mask(i,j) = (1/ (Var * sqrt(2*pi))) * exp(-((j - CenterMean)^2) / (2*Var^2)) / normDist;
    end
end

for j = 1 : NumGaussianCenters
    tempmul(j,:) = 1- mask(j,:);    
end
FinalValMask = 1- prod(tempmul);


% for i = 1 : nFrames
%     for j = 1 : NumGaussianCenters
%         tempmul(j) = 1- mask(j,i);
%     end
%     FinalValMask(i) = 1- prod(tempmul);
% end
for i = 1 :nFrames
    %tempFrameVid(:,:) = tempVid(:,:,i);
    tempFrameVid(:,:) = tempVid(:,:,i) - tempmean(i);
    movieNoised(:,:,i) = uint8((FinalValMask(i) * tempFrameVid) + tempmean(i));
end

%time3 = toc
% combine the masks
%x = 0;
return;